package config;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import config.WebhookResponse;
import handlerservice.MaturityDate;
import handlerservice.MliDoc_Handler_Service;
import handlerservice.OTP_Handler_Service;
import handlerservice.PolicyDetail_Handler_Service;
import handlerservice.PolicyInfo_Handler_Service;
import handlerservice.PolicyPack_Handler_Service;
import handlerservice.PolicyDetail_Service_FundValue;
import handlerservice.PolicyLoanDetail;
import handlerservice.PersonalDetailUpdate;
import handlerservice.AddressDetail;
import common.Commons;
import common.CustomizeDate;
import common.DateValidator;
import config.Facebook;
import config.InnerButton;
import config.InnerData;
import config.Payload;
import common.Adoptionlogs;
import common.RegexMatcher;
import org.springframework.scheduling.annotation.Scheduled;
import common.RemoveSessionId;


@Controller
@RequestMapping("/webhook")
public class ChatBotController {
	
        private static Logger logger = LogManager.getLogger(ChatBotController.class);
	public static ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	public static Map<String, Object> serviceResp = new HashMap<String,Object>();
	public static Map<String, Map> responsecache_onsessionId = new ConcurrentHashMap<String, Map>();
	public static Map<String, String> mapforcashbeforevalidation = new ConcurrentHashMap<String, String>();
	public static Map<String, String> mapforrenewalPayment = new ConcurrentHashMap<String, String>();
	public static Map<String , String> removefromcash = new ConcurrentHashMap<String, String>();
	public static Map<String, String> mobile_email = new ConcurrentHashMap<String, String>();
	
	@Autowired
	OTP_Handler_Service oTP_Handler_Service; 
	@Autowired
	PolicyDetail_Handler_Service policyDetail_Handler_Service; 
	@Autowired
	PolicyInfo_Handler_Service policyInfo_Handler_Service; 
	@Autowired
	MliDoc_Handler_Service mliDoc_Handler_Service;
	@Autowired
	MaturityDate maturityDate;
	@Autowired
	PolicyPack_Handler_Service policyPack_Handler_Service;
	@Autowired
	private PolicyDetail_Service_FundValue policyDetail_Service_FundValue;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	AddressDetail addressDetail;
	@Autowired
	RemoveSessionId removeSessionId;
	@Autowired
	private PolicyLoanDetail policyLoan;
	@Autowired
	private DateValidator dateValidator;
	@Autowired
	PersonalDetailUpdate personalDetailUpdate;
	@Autowired
	RegexMatcher regexMatcher;
	
	
	@Scheduled(cron="0 0/15 * * * ?")
    	public void schedular()
    	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Spring Schedular START ::"+ dtf.format(now));
		removeSessionId.removedSessionIdfromCash(serviceResp, responsecache_onsessionId, mapforcashbeforevalidation, mapforrenewalPayment, removefromcash, mobile_email);
	    	//removeSessionId.removedSessionIdfromCash();
    		System.out.println("Spring Schedular END ::"+ dtf.format(now));
    	}
	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody WebhookResponse webhook(@RequestBody String obj) 
	{
		String speech = null;
		System.out.println("--------------------I am inside the Controller-----------------------------------------------------");
		System.out.println("Size of the CashHashMap:Internal Data Cash: "+ serviceResp.size());
		System.out.println("Size of the CashHashMap: No.of User Enter: "+ responsecache_onsessionId.size());
		System.out.println("Size of the CashHashMap: No.of User Enter: "+ mapforcashbeforevalidation.size());
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
		Facebook<?> fb = new Facebook();
		InnerData innerData= new InnerData();
		InnerButton button = new InnerButton();
		InnerButton button2 = new InnerButton();
		InnerButton button3 = new InnerButton();
		InnerButton button4 = new InnerButton();
		InnerButton button5 = new InnerButton();
		InnerButton button6 = new InnerButton();
		InnerButton button7 = new InnerButton();
		InnerButton button8 = new InnerButton();
		InnerButton button9 = new InnerButton();
		InnerButton button10 = new InnerButton();
		InnerButton button11 = new InnerButton();
		InnerButton button12 = new InnerButton();
		String regex = "^[0-9]{10}$";
		String sessionId="";
		String action="";
		String policy_Number="";
		String resolvedQuery="";
		String pincode="";
		String dob="";
		String newMobileNumber = "";
		String newEmail = "";
		
		try {
			System.out.println("Controller : Webhook : START");
			//System.out.println(obj.toString());
			JSONObject object = new JSONObject(obj.toString());
			sessionId = object.get("sessionId")+"";
			logger.info("Request Session Id :- "+ sessionId);
			action = object.getJSONObject("result").get("action")+"";
			System.out.println("--------------Testing----"+action);
			ObjectMapper mapperObj = new ObjectMapper();
			try{
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery")+"";
			System.out.println("----Resolved Query----"+resolvedQuery);
			}catch(Exception ex)
			{
				resolvedQuery="";
			}
			try{
				policy_Number = object.getJSONObject("result").getJSONObject("parameters").getJSONObject("PolicyNumber").get("Given-PolicyNumber")+"";
			}catch(Exception e)
			{
				policy_Number="";
			}
			try{
				pincode = object.getJSONObject("result").getJSONObject("parameters").get("pin")+"";
				System.out.println("pincode --- testing "+pincode);
			}catch(Exception e)
			{
				pincode="";
			}
			try {
				newMobileNumber = object.getJSONObject("result").getJSONObject("parameters").get("mobile") + "";
				mobile_email.put("newMobileNumber", newMobileNumber);
				System.out.println("newMobileNumber --- testing " + newMobileNumber);
			} catch (Exception e) {
				newMobileNumber = "";
			}
			try {
				newEmail = object.getJSONObject("result").getJSONObject("parameters").get("email") + "";
				mobile_email.put("newEmail", newEmail);
				System.out.println("newEmail --- testing " + newEmail);
			} catch (Exception e) {
				newEmail = "";
			}
			try{
				dob = object.getJSONObject("result").getJSONObject("parameters").get("dob")+"";
				System.out.println("pincode --- testing "+dob);
			}catch(Exception e)
			{
				dob="";
			}
			if(true)
			{
				removefromcash.put(sessionId, dtf.format(now));
				if(!"PolicyNumberValidation".equalsIgnoreCase(action) && !"OTPValidation".equalsIgnoreCase(action)
						&& !"OTP.NotAvailable".equalsIgnoreCase(action) && !"HI".equalsIgnoreCase(action)
				                && !"close.conversation".equalsIgnoreCase(action) && !"dobvalidate".equalsIgnoreCase(action))
				{
					mapforcashbeforevalidation.put(sessionId, action);
				}
			}
			switch(action)
			{
			case "HI":
			case "locateus-pincode.locateus-pincode-yes":
			case "PolicyCTP.PolicyCTP-yes":
			//code added
			case "PolicySurrenderValue.PolicySurrenderValue-yes":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-yes":
			case "PolicyFundValue.PolicyFundValue-yes":
			case "InputMaturity.InputMaturity-yes":
			case "InputPPT.InputPPT-yes":
			case "Policypolicydocument.Policypolicydocument-yes":
			case "PolicyPolicyNumberValidation.PolicyPolicyNumberValidation-yes":
			case "Client-DOB.Client-DOB-yes":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-yes":	
		        case "EmailEntered.EmailEntered-yes.EmailEntered-yes-yes":
			case "UpdateAadhar.UpdateAadhar-yes":
			case "credit.credit-yes-2":
			//
			{
				if("HI".equalsIgnoreCase(action))
				{
					/*StringBuffer sb = new StringBuffer();
					sb.append("<HTML> <title>Test Table</title> <body>");
					sb.append("<table style=\"width:40%\" cellspacing=\"0\" cellpadding=\"0\" border=\"1px\" align=\"center\">");
					sb.append("<tr> <th> A </th> <th>B</th> <th>C</th> <th>D</th> <th>E</th> </tr>");
					sb.append("<tr> <th>1</th> <th>1</th> <th>1</th> <th>1</th> <th>1</th> </tr>");
					sb.append("<tr> <th>2</th> <th>2</th> <th>2</th> <th>2</th> <th>2</th> </tr>");
					sb.append("<tr> <th>3</th> <th>3</th> <th>3</th> <th>3</th> <th>3</th> </tr>");
					sb.append("<tr> <th>4</th> <th>4</th> <th>4</th> <th>4</th> <th>4</th> </tr>");
					sb.append("</table> </body> </html>");
					speech="Hello. I am your Max Life Assistant. If you have Max Life Policy, I can help you with following options.\n\n";
					speech=speech+sb.toString();*/

				   speech="Hello. I am your Max Life Assistant. If you have Max Life Policy, I can help you with following options.";
				}
				else
				{
					speech="I can help you with following on your Policy";
				}
				button.setText("Premium Due");
				button.setPostback("premiumdue");
				innerbuttonlist.add(button);
				
				button2.setText("Policy Term");
				button2.setPostback("maturity and term");
				innerbuttonlist.add(button2);
				
				button3.setText("Policy Pack");
				button3.setPostback("policypack");
				innerbuttonlist.add(button3);
				
				button4.setText("Maturity");
				button4.setPostback("maturity and term");
				innerbuttonlist.add(button4);
				
				button5.setText("Fund Value");
				button5.setPostback("Fundvalue");
				innerbuttonlist.add(button5);
				
				button6.setText("Cash Value");
				button6.setPostback("csv");
				innerbuttonlist.add(button6);
				
				button7.setText("Premium Payment Term");
				button7.setPostback("ppt");
				innerbuttonlist.add(button7);
				
				button8.setText("Renewal Payment Procedure");
				button8.setPostback("renewalpayment");
				innerbuttonlist.add(button8);
				
				button9.setText("Premium Statement");
				button9.setPostback("premiumreceipt");
				innerbuttonlist.add(button9);
				
				button10.setText("Locate Us");
				button10.setPostback("locateus");
				innerbuttonlist.add(button10);
				
				button11.setText("Loan Inquiry");
				button11.setPostback("LoanInquiry");
				innerbuttonlist.add(button11);
				
				button12.setText("Update Personal Details");
				button12.setPostback("UpdatePersonalDetails");
				innerbuttonlist.add(button12);
				
				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				innerData.setFacebook(fb);
			}
			break;
			case "OTP.NotAvailable":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					Map<String, String> orignalData = oTP_Handler_Service.getPolicyOtp(cachePolicyNo, sessionId , 1);
					if (orignalData.get("policyotp")!= null) 
					{
						responsecache_onsessionId.put(sessionId, orignalData);
						speech = orignalData.get("Message");
					}
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
			}
			break;
			case "PolicyNumberValidation":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					String cacheOTP=responsecache_onsessionId.get(sessionId).get("policyotp")+"";
					String proposerName=responsecache_onsessionId.get(sessionId).get("proposerName")+"";
					if (cachePolicyNo!= null && (cachevalidOTP != null && !"".equalsIgnoreCase(cachevalidOTP)))
					{
						if (!(policy_Number.equals(cachePolicyNo)))
						{
							responsecache_onsessionId.clear();
							Map<String, String> orignalData = oTP_Handler_Service.getPolicyOtp(policy_Number, sessionId , 0);
							responsecache_onsessionId.put(sessionId, orignalData);
							speech = orignalData.get("Message");
							WebhookResponse responseObj = new WebhookResponse(speech, speech);
							return responseObj;
						}
					}
					if (!"".equalsIgnoreCase(cachePolicyNo) && cachePolicyNo!= null && cachevalidOTP != null && !cachevalidOTP.equalsIgnoreCase(""))
					{
						speech = "OTP Verification is completed for Policy Number " + cachePolicyNo
								+ ", please tell what you want to know about policy";
					}
					else if (cachePolicyNo!= null) 
					{
						String otp_session="";
						if (!"".equalsIgnoreCase(cacheOTP) && cacheOTP != null)
						{
							otp_session = cacheOTP;
						}
						if (!"".equalsIgnoreCase(otp_session) &&  otp_session != null)
						{
							if (otp_session.equals(policy_Number)) {
								String policyBasePlanIdDesc="";
								String lastPremPmtDt="";
								String actionWithOutHi="";

								Map data = policyInfo_Handler_Service.getPolicyInfo(cachePolicyNo);
								try{
								String Json = mapperObj.writeValueAsString(data);
								JSONObject jsonObject = new JSONObject(Json.toString());
								policyBasePlanIdDesc=jsonObject.getJSONObject("PolicyData").get("policyBasePlanIdDesc")+"";
								lastPremPmtDt=jsonObject.getJSONObject("PolicyData").get("lastPremPmtDt")+"";
								}catch(IOException e){logger.info(e);}
								System.out.println("data----------" + data.toString());
								Map<String, Object> serviceResp = responsecache_onsessionId.get(sessionId);
         							Map<String, String> maturityData = maturityDate.getMaturityDate(cachePolicyNo);
								serviceResp.put("OverAllMaturityCashData", maturityData);
								serviceResp.put("ValidOTP", cachePolicyNo);
                                                                serviceResp.put("lastPremPmtDt", lastPremPmtDt);
								serviceResp.put("PolData", data);
								serviceResp.remove("policyotp");
								responsecache_onsessionId.put(sessionId, serviceResp);
								for(Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet())
								{
									String key = entry.getKey();
									if(key.equalsIgnoreCase(sessionId))
									{
										 action = entry.getValue();
										actionWithOutHi = entry.getValue();
									}

								}
                                                               speech = "Hi " + Commons.toCamelCase(proposerName)
								+ resProp.getString("welcomeUser")+policyBasePlanIdDesc+" "+resProp.getString("welcomeUser1");
								if("".equalsIgnoreCase(actionWithOutHi) || actionWithOutHi.isEmpty())
								{
									//button.setText("Policy Information");
									//button.setPostback("policyinfo");
									//innerbuttonlist.add(button);

									button.setText("Premium Due");
									button.setPostback("premiumdue");
									innerbuttonlist.add(button);

									button2.setText("Policy Term");
									button2.setPostback("maturity and term");
									innerbuttonlist.add(button2);
									
									button3.setText("Policy Pack");
									button3.setPostback("policypack");
									innerbuttonlist.add(button3);

									button4.setText("Maturity");
									button4.setPostback("maturity and term");
									innerbuttonlist.add(button4);

									button5.setText("Fund Value");
									button5.setPostback("Fundvalue");
									innerbuttonlist.add(button5);

									button6.setText("Cash Value");
									button6.setPostback("csv");
									innerbuttonlist.add(button6);

									button7.setText("Premium Payment Term");
									button7.setPostback("ppt");
									innerbuttonlist.add(button7);
									
									button8.setText("Renewal Payment Procedure");
									button8.setPostback("renewalpayment");
									innerbuttonlist.add(button8);
									
									button9.setText("Premium Statement");
									button9.setPostback("premiumreceipt");
									innerbuttonlist.add(button9);
									
									button10.setText("Locate Us");
									button10.setPostback("locateus");
									innerbuttonlist.add(button10);
									
									button11.setText("Loan Inquiry");
									button11.setPostback("LoanInquiry");
									innerbuttonlist.add(button11);

									button12.setText("Update Personal Details");
                                                                        button12.setPostback("UpdatePersonalDetails");
				                                        innerbuttonlist.add(button12);
									
									fb.setButtons(innerbuttonlist);
									fb.setTitle("MLIChatBot");
									fb.setPlatform("API.AI");
									fb.setType("Chatbot");
									fb.setImageUrl("BOT");

									innerData.setFacebook(fb);
								}
                                                        } 
							else {
								speech = resProp.getString("OTPnotmatch");
							}
						} 
						else
						{
							speech = resProp.getString("GenerateOTP");
						}
					}
				}
				else
				{
					logger.info("START :: Request For Generate PolicyOTP");
					Map<String, String> orignalData = oTP_Handler_Service.getPolicyOtp(policy_Number, sessionId , 0);
					if(!orignalData.get("Message").contains("Oops")){
						responsecache_onsessionId.put(sessionId, orignalData);
						logger.info("END :: Request For Generate PolicyOTP :- "+serviceResp);
						speech = orignalData.get("Message");
					}
					else{
						System.out.println("Inside in Oops");
						speech = orignalData.get("Message");
					}
					logger.info("END :: Request For Generate PolicyOTP :- "+serviceResp);
				}
			}
			break;
			case "OTPValidation":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					String cacheOTP=responsecache_onsessionId.get(sessionId).get("policyotp")+"";
					if ("".equalsIgnoreCase(cachePolicyNo)||cachePolicyNo == null)
					{
						speech = resProp.getString("validPolicyMessage");
					}
					else if (!"".equalsIgnoreCase(cachevalidOTP) && cachevalidOTP!= null) 
					{
						speech = "OTP Verification is completed for Policy Number "+ cachePolicyNo
								+ ", please tell what you want to know about policy  OR write reset to start new session";
					} 
					else
					{
						String otp_session = "";
						String OTP_request=object.getJSONObject("result").getJSONObject("parameters").getJSONObject("OTP").get("Provided-OTP")+"";
						otp_session = cacheOTP;
						if (!"".equalsIgnoreCase(otp_session) && otp_session != null) {
							if (otp_session.equals(OTP_request)) 
							{
								speech = "Mr. Arun. What information you want to know about your policy";
								Map data = policyInfo_Handler_Service.getPolicyInfo(cachePolicyNo);
								System.out.println("data----------" + data.toString());

								Map<String, String> serviceResp = responsecache_onsessionId.get(sessionId);
								serviceResp.put("cachevalidOTP", OTP_request);
								serviceResp.remove("policyotp");
								responsecache_onsessionId.put(sessionId, serviceResp);
							} 
							else {
								speech = "OTP did not match.Please provide correct OTP.";
							}
						} else
						{
							speech = "You have not generated OTP.Please provide valid policy to generate OTP";
						}
					}
				} 
				else{
					speech = resProp.getString("validPolicyMessage");
				}
			}
			break;
			default:
			}
			switch(action)
			{
			case "input.CTP":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					Map data =(Map)responsecache_onsessionId.get(sessionId).get("PolData");
					if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo==null )
					{
						speech = resProp.getString("validPolicyMessage");
					} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP== null) 
					{
						speech = resProp.getString("validateOTP").concat(cachePolicyNo);

					} else {
						System.out.println("i am in ctp action 1");
						if (data.get("CTP") == null) 
						{
							speech = ((Map) data.get("ErrorMessage")).get("Message").toString();
						} else 
						{
							System.out.println("i am in ctp action 3");
							Map ctp = (Map) data.get("CTP");
							speech = ctp.get("Message").toString();
						}
					}
					speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
				
			}
			break;
			case "input.Surrender": 
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					System.out.println("InsideInput.surrender");
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					Map data =(Map)responsecache_onsessionId.get(sessionId).get("PolData");
					if ("".equalsIgnoreCase(cachePolicyNo)||cachePolicyNo == null)
					{
						speech = resProp.getString("validPolicyMessage");
					} 
					else if ("".equalsIgnoreCase(cachevalidOTP)||cachevalidOTP== null)
					{
						speech = resProp.getString("validateOTP").concat(cachePolicyNo);
					} 
					else 
					{
						System.out.println("I am in Surrender Value");
						if (data.get("CSV") == null) {
							System.out.println("CSV is null is policy data");
							speech = policyDetail_Handler_Service.getPolicyDetails(data, cachePolicyNo).get("Message").toString();
							System.out.println("Speech is " + speech);
						}
						else{
							speech = ((Map)data.get("CSV")).get("Message").toString();
						}
					}
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "input.Receipt":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
                                        String cashlastPremPmtDt=responsecache_onsessionId.get(sessionId).get("lastPremPmtDt")+"";
					Map data =(Map)responsecache_onsessionId.get(sessionId).get("PolData");

					if ("".equalsIgnoreCase(cachePolicyNo)|| cachePolicyNo == null) 
					{
						speech = resProp.getString("validPolicyMessage");
					} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
						speech = resProp.getString("validateOTP").concat(cachePolicyNo);
					} else {
						speech = mliDoc_Handler_Service.getMliDocService(cachePolicyNo, cashlastPremPmtDt).get("Message");
					}
					
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}	*/			
			}
			break;
			case "input.Fund": 
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					Map data =(Map)responsecache_onsessionId.get(sessionId).get("PolData");
					if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
						speech = resProp.getString("validPolicyMessage");
					} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
						speech = resProp.getString("validateOTP").concat(cachePolicyNo);
					} else {
						if (data.get("FV") == null) {
							speech = ((Map) data.get("ErrorMessage")).get("Message").toString();
						} else {
							Map fv = (Map) data.get("FV");
							if (fv.get("fundValAsonDate") != null) {

								if (fv.get("FVErrorMessage") != null)
									speech = fv.get("FVErrorMessage").toString();
								else {
									String fvdata = fv.get("fundValAsonDate").toString();
									speech = fv.get("Message").toString()+" "+Math.round(Double.parseDouble(fvdata)*100.0)/100.0;
									System.out.println(speech);
									String mir_dv_eff_dt = policyDetail_Service_FundValue.policyDetilfunValue(cachePolicyNo);
									System.out.println("Date retrun from backend ::"+mir_dv_eff_dt);
									String [] arr = speech.split("today");
									String message1 = arr[0];
									String message2 =arr[1];
									speech=message1+" date "+mir_dv_eff_dt+" "+message2;
									speech = speech+". "+resProp.getString("maturity6");
								}
							} else {
								speech = fv.get("Message").toString();
							}
						}
					}
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				} 
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
      			case "Input.Maturity":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cashdata=((Map)responsecache_onsessionId.get(sessionId).get("OverAllMaturityCashData")).get("maturityMessage")+"";
					speech = cashdata;
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "Policy.PremiumPaymentTerm":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String premChngeDtCd=""; String premChngAgeDur=""; String cvgMatXpryDt=""; String cvgIssEffDt="";
					String cvgPlanIdCd=""; String origPlanIdCd="";
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					Map<String, Object> cashdata=(Map)responsecache_onsessionId.get(sessionId).get("OverAllMaturityCashData");
					String maturitycashdata=cashdata.get("MaturityCashData")+"";
					Map<String, Object> resultData = Commons.getGsonData(maturitycashdata);
					String policyNumber = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("policyNum").toString();
					String policyStatusCd = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("policyStatusCd").toString();
					String policyStatusDesc = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("policyStatusDesc").toString();
					String polDueDate = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("polDueDate").toString();
					String billingFreqCd = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("billingFreqCd").toString();
					String billingFreqDesc = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
							.get("BasicDetails")).get("billingFreqDesc").toString();
					List cvgDetails = (List)((Map)((Map) resultData.get("response")).get("responseData")).get("coverageDetailsArray");

					if(cvgDetails!=null && !cvgDetails.isEmpty())
					{
						for(int i=0; i<cvgDetails.size(); i++)
						{
							String cvgNum =((Map) cvgDetails.get(i)).get("cvgNum")+"";
							if("01".equals(cvgNum))
							{
								premChngeDtCd =((Map) cvgDetails.get(i)).get("premChngeDtCd")+"";
								premChngAgeDur =((Map) cvgDetails.get(i)).get("premChngAgeDur")+"";
								cvgMatXpryDt =((Map) cvgDetails.get(i)).get("cvgMatXpryDt")+"";
								cvgIssEffDt =((Map) cvgDetails.get(i)).get("cvgIssEffDt")+"";
								cvgPlanIdCd =((Map) cvgDetails.get(i)).get("cvgPlanIdCd")+"";
								origPlanIdCd =((Map) cvgDetails.get(i)).get("origPlanIdCd")+"";
							}
						}
					}
					if("1".equalsIgnoreCase(policyStatusCd))
					{
						CustomizeDate custdate = new CustomizeDate();
						if(!"A".equalsIgnoreCase(premChngeDtCd))
						{

							int i =custdate.comparetwoDates(polDueDate, cvgMatXpryDt);
							if(i==2)
							{
								speech=resProp.getString("maturity21");
							}
							else	
							{
								int month =custdate.getMonth(cvgMatXpryDt,polDueDate);
								String customizeDate=custdate.subtractMonth(cvgMatXpryDt, billingFreqCd);
								int billingFreqcd=Integer.parseInt(billingFreqCd);
								int PremDueCount1=month/billingFreqcd;
								speech=resProp.getString("maturity22")+" "+cachePolicyNo+" "+resProp.getString("maturity8")
								+" "+Commons.convertDateFormat(customizeDate)+" "+resProp.getString("premium25")+" "+PremDueCount1
								+ " " + billingFreqDesc	+ "premiums to be paid till policy maturity/expiry.";
								//+" "+billingFreqDesc+" "+resProp.getString("premium26");
							}
						}
						else
						{
							String premChngAgeDurYear=custdate.addYear(cvgIssEffDt, premChngAgeDur);
							int ir =custdate.comparetwoDates(polDueDate, premChngAgeDurYear);
							if(ir==2)
							{
								speech = "Thank you, all due premiums have already been paid for the policy.";
								//speech=resProp.getString("maturity21");
							}
							else
							{
								String getYear=custdate.addYear(cvgIssEffDt, premChngAgeDur);
								String customizeDate=custdate.subtractMonth(getYear, billingFreqCd);
								int month =custdate.getMonth(getYear,polDueDate);
								int billingFreqcd=Integer.parseInt(billingFreqCd);
								int PremDueCount2=month/billingFreqcd;
								speech=resProp.getString("maturity22")+" "+cachePolicyNo+" "+resProp.getString("maturity8")
								+" "+Commons.convertDateFormat(customizeDate)
								+" "+resProp.getString("premium25")+" "+PremDueCount2+" "+billingFreqDesc
								+ "premiums to be paid till policy maturity/expiry.";	
								//+" "+resProp.getString("premium26");							
							}
							
						}
					}
					else
					{
						if("3".equalsIgnoreCase(policyStatusCd) || "4".equalsIgnoreCase(policyStatusCd))
						{
						if (cvgPlanIdCd.equalsIgnoreCase(origPlanIdCd))  
						{
							speech="Thank You, all due premiums have already been paid for the policy. ";
									//+ "I can help you with following options on your policy.";
						}else
						{
							speech="The premium payment end date for your policy "
									+ policyNumber+" can not be provided as it is in "+policyStatusDesc+" status. "
									+ "Please call our customer care on 1-860-120-5577 to get more details on the same.";
									//+ " I can help you with following options on your policy.";
						}
						}
						else
						{
							speech="The premium payment end date for your policy "
									+ policyNumber+" can not be provided as it is in "+policyStatusDesc+" status. "
									+ "Please call our customer care on 1-860-120-5577 to get more details on the same.";
									//+ " I can help you with following options on your policy.";
						}
					}
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "Input.PolicyPack":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
					String cachevalidOTP=responsecache_onsessionId.get(sessionId).get("ValidOTP")+"";
					if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null)
					{
						speech = resProp.getString("validPolicyMessage");
					} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
						speech = resProp.getString("validateOTP").concat(cachePolicyNo);
					} else {
						speech = policyPack_Handler_Service.getPolicyPackService(cachePolicyNo).get("Message");
					}
				//code added
				speech=speech+"\n Is there anything else I can help you with?(Yes/No)";
				//
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);
					
					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Premium Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);
					
					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Statement");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "close.conversation":
			{
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					for(Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet())
					{
						String key = entry.getKey();
						if(key.equalsIgnoreCase(sessionId))
						{
							mapforcashbeforevalidation.remove(sessionId);
						}
					}
					responsecache_onsessionId.remove(sessionId);
					logger.info("Session_Id Removed :-" + sessionId);
					speech = "Thank you for contacting Max Life. Have a great day!";
				}
				else{
					speech = "Thank you for contacting Max Life. Have a great day!";
				}
			}
			break;
			case "LocateUs":
			{
				if(true)
				{
					System.out.println("Action Invoded:- Locate Us");
					speech="Please enter 6 digit pin code to help you with the nearest Max Life office.";
				}else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "locateuspincode":
			{
				try{
					System.out.println("Action Invoded:- PinCode");
					RegexMatcher reg = new RegexMatcher();
					String status = reg.regexPatternStatus(pincode);
					if("matched".equalsIgnoreCase(status))
					{
						speech=addressDetail.getAddress(pincode);
						if("".equalsIgnoreCase(speech) || speech.isEmpty())
						{
							speech=" Looks like we don’t have any Max Life office situated near to the PIN code entered by you, "
								+ "<a href='https://bit.ly/2Gc5bLa' target='_blank'> Click Here </a>  to locate nearest office in your city.\n"
								//	+ "Click Here <a href='https://bit.ly/2Gc5bLa' target='_blank'> </a>  to locate nearest office in your city.\n"
									+ " Is there anything else I can help you with?(Yes/No)";
						}
						else
						{
							speech=speech.concat(" Is there anything else I can help you with?(Yes/No)");
						}
					}
					else
					{
						speech="Looks like you have entered incorrect PIN code, please enter valid PIN code.";
					}
					
				}catch(Exception ex)
				{
					System.out.println("Exception occoured in Locateuspincode statement");
				}
			}
			break;
			case "policy.info":
			{
				speech = resProp.getString("policyinformation");
				button.setText("Premium Due");
				button.setPostback("premiumdue");
				innerbuttonlist.add(button);
				
				button2.setText("Policy Term");
				button2.setPostback("maturity and term");
				innerbuttonlist.add(button2);
				
				button4.setText("Maturity");
				button4.setPostback("maturity and term");
				innerbuttonlist.add(button4);
				
				button5.setText("Fund Value");
				button5.setPostback("Fundvalue");
				innerbuttonlist.add(button5);
				
				button6.setText("Cash Value");
				button6.setPostback("csv");
				innerbuttonlist.add(button6);
				
				button7.setText("Premium Payment Term");
				button7.setPostback("ppt");
				innerbuttonlist.add(button7);
				
				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				
				innerData.setFacebook(fb);
                       }
			break;
			case "PolicyCTP.no":
			{
				speech = resProp.getString("PolicyCTP_no");
				
				button.setText("Premium Due");
				button.setPostback("premiumdue");
				innerbuttonlist.add(button);
				
				button2.setText("Policy Term");
				button2.setPostback("maturity and term");
				innerbuttonlist.add(button2);
				
				button4.setText("Maturity");
				button4.setPostback("maturity and term");
				innerbuttonlist.add(button4);
				
				button5.setText("Fund Value");
				button5.setPostback("Fundvalue");
				innerbuttonlist.add(button5);
				
				button6.setText("Cash Value");
				button6.setPostback("csv");
				innerbuttonlist.add(button6);
				
				button7.setText("Premium Payment Term");
				button7.setPostback("ppt");
				innerbuttonlist.add(button7);
				
				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				
				innerData.setFacebook(fb);
				
			}
			break;
			case "RenewalPaymentProcedure":
			{
				System.out.println("Action Invoded:- RenewalPaymentProcedure");
				speech="Please select one of the following options: ";

				button.setText("Pay Online");
				button.setPostback("pay online");
				innerbuttonlist.add(button);

				button2.setText("Direct Debit");
				button2.setPostback("direct debit");
				innerbuttonlist.add(button2);

				button3.setText("CreditCard Standing Instructions");
				button3.setPostback("credit");
				innerbuttonlist.add(button3);

				button4.setText("Other Procedure");
				button4.setPostback("other procedure");
				innerbuttonlist.add(button4);

				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				innerData.setFacebook(fb);
				mapforrenewalPayment.put(sessionId,sessionId);
			}
			break;
			case "LoanInquiry":
			{
				System.out.println("Action Invoded:- LoanInquiry");
				speech="Please select one of the following options: ";

				button.setText("Loan Eligibility Details");
				button.setPostback("loanegigibilitydetails");
				innerbuttonlist.add(button);

				button2.setText("Outstanding Loan Details");
				button2.setPostback("outstandingloandetials");
				innerbuttonlist.add(button2);
				
				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				innerData.setFacebook(fb);
			}
			break;
			case "loanegigibilitydetails":
			{
				
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					speech=" Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
							+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Loan Eligibility Details");
					button.setPostback("loanegigibilitydetails");
					innerbuttonlist.add(button);
					button2.setText("Outstanding Loan Details");
					button2.setPostback("outstandingloandetials");
					innerbuttonlist.add(button2);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "outstandingloandetials":
			{
				
				if(responsecache_onsessionId.containsKey(sessionId))
				{
					speech=" Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
							+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
				}
				else{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Loan Eligibility Details");
					button.setPostback("loanegigibilitydetails");
					innerbuttonlist.add(button);

					button2.setText("Outstanding Loan Details");
					button2.setPostback("outstandingloandetials");
					innerbuttonlist.add(button2);
					
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
			case "dobvalidate":
			{
				if(responsecache_onsessionId.containsKey(sessionId) && mapforcashbeforevalidation.containsKey(sessionId))
				{
					boolean status = dateValidator.isThisDateValid(dob);
					if(status)
					{
						String intent="";
						for(Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet())
						{
							String key = entry.getKey();
							if(key.equalsIgnoreCase(sessionId))
							{
								intent = entry.getValue();
							}
						}
						String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
						//System.out.println(cachePolicyNo);
						//cachePolicyNo="239089980";
						if("loanegigibilitydetails".equalsIgnoreCase(intent))
						{
							String flag1 ="loanegigibilitydetails";
							speech = policyLoan.policyLoanDetail(cachePolicyNo, dob, flag1);
						}
						else
						{
							String flag2 ="outstandingloandetials";
							speech = policyLoan.policyLoanDetail(cachePolicyNo, dob, flag2);
						}
					}
					else
					{
						speech = " Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
								+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
					}
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
				/*if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					button.setText("Loan Eligibility Details");
					button.setPostback("loanegigibilitydetails");
					innerbuttonlist.add(button);

					button2.setText("Outstanding Loan Details");
					button2.setPostback("outstandingloandetials");
					innerbuttonlist.add(button2);
					
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}*/
			}
			break;
					
			case "UpdatePersonalDetails": {
				System.out.println("Action Invoded:- UpdatePersonalDetails");
				speech = "Please select one of the following options: ";

				button.setText("Update Mobile");
				button.setPostback("UpdateMobile");
				innerbuttonlist.add(button);

				button2.setText("Update Email");
				button2.setPostback("UpdateEmail");
				innerbuttonlist.add(button2);

				button3.setText("Update Aadhaar");
				button3.setPostback("UpdateAadhaar");
				innerbuttonlist.add(button3);

				fb.setButtons(innerbuttonlist);
				fb.setTitle("MLIChatBot");
				fb.setPlatform("API.AI");
				fb.setType("Chatbot");
				fb.setImageUrl("BOT");
				innerData.setFacebook(fb);
			}

				break;
					
                              case "UpdateMobile": {
				if (responsecache_onsessionId.containsKey(sessionId)) {
					System.out.println("Action Invoded:- UpdateMobile");
					speech = "Please enter 10 digits mobile number you wish to register with your Max Life policy.";
				}

				else {
					speech = resProp.getString("validPolicyMessage");
				}

				/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					button.setText("Update Mobile");
					button.setPostback("UpdateMobile");
					innerbuttonlist.add(button);

					button2.setText("Update Email");
					button2.setPostback("UpdateEmail");
					innerbuttonlist.add(button2);

					button3.setText("Update Aadhaar");
					button3.setPostback("UpdateAadhaar");
					innerbuttonlist.add(button3);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);

				}*/
			}

				break;

			case "UpdateEmail": {
				if (responsecache_onsessionId.containsKey(sessionId)) {
					System.out.println("Action Invoded:- UpdateEmail");
					speech = "Please enter the email id you wish to register with your Max Life policy.";
				} else {
					speech = resProp.getString("validPolicyMessage");
				}

				/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					button.setText("Update Mobile");
					button.setPostback("UpdateMobile");
					innerbuttonlist.add(button);

					button2.setText("Update Email");
					button2.setPostback("UpdateEmail");
					innerbuttonlist.add(button2);

					button3.setText("Update Aadhaar");
					button3.setPostback("UpdateAadhaar");
					innerbuttonlist.add(button3);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);

				}*/
			}

				break;

			case "UpdateAadhaar": {
				if (responsecache_onsessionId.containsKey(sessionId)) {
					System.out.println("Action Invoded:- UpdateAadhaar");
					speech = " <a href='https://goo.gl/KBHnJN' target='_blank'> click here </a> "
							+ " to link your Aadhaar Number with your Max Life policy.Is there anything else I can help you with? (Yes/No)";
				} else {
					speech = resProp.getString("validPolicyMessage");
				}

				/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					button.setText("Update Mobile");
					button.setPostback("UpdateMobile");
					innerbuttonlist.add(button);

					button2.setText("Update Email");
					button2.setPostback("UpdateEmail");
					innerbuttonlist.add(button2);

					button3.setText("Update Aadhaar");
					button3.setPostback("UpdateAadhaar");
					innerbuttonlist.add(button3);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);

				}*/
			}

				break;

			case "MobileEntered": {
				try {
					if (responsecache_onsessionId.containsKey(sessionId)) {

						String cachePolicyNo = responsecache_onsessionId.get(sessionId).get("PolicyNo") + "";
						//String cachePolicyNo = "701542425";
						System.out.println("newMobileNumber --- testing " + newMobileNumber);
						if (newMobileNumber.matches(regex)) {
							String intent = "MobileNo";

							speech = personalDetailUpdate.getCustomerInfo(cachePolicyNo, intent, newMobileNumber);

							if(speech.contains("There is some communication glitch!"))
							{
								speech="There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
							}
							else
							{						    	
							button.setText("YES");
							button.setPostback("yes");
							innerbuttonlist.add(button);

							button2.setText("NO");
							button2.setPostback("no");
							innerbuttonlist.add(button2);

							fb.setButtons(innerbuttonlist);
							fb.setTitle("MLIChatBot");
							fb.setPlatform("API.AI");
							fb.setType("Chatbot");
							fb.setImageUrl("BOT");
							innerData.setFacebook(fb);
							}
						} else {
							speech = "Looks like the entered mobile number is incorrect, request you to enter correct mobile number.";
						}
					} else {
						speech = resProp.getString("validPolicyMessage");
					}

					/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
							.equalsIgnoreCase(speech)) {
						button.setText("Update Mobile");
						button.setPostback("UpdateMobile");
						innerbuttonlist.add(button);

						button2.setText("Update Email");
						button2.setPostback("UpdateEmail");
						innerbuttonlist.add(button2);

						button3.setText("Update Aadhaar");
						button3.setPostback("UpdateAadhaar");
						innerbuttonlist.add(button3);

						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");
						innerData.setFacebook(fb);

					}*/
				} catch (Exception e) {
					newMobileNumber = "";
				}
			}

				break;
			case "MobileEntered.MobileEntered-yes": {
				if (responsecache_onsessionId.containsKey(sessionId)) {
					System.out.println("Action Invoded:- MobileEntered.MobileEntered-yes");
					String cachePolicyNo = responsecache_onsessionId.get(sessionId).get("PolicyNo") + "";
					//String cachePolicyNo="719845000";
					String cacheMobile=mobile_email.get("newMobileNumber")+"";
					speech = personalDetailUpdate.updateMobile(cachePolicyNo, cacheMobile);
				} else {
					speech = resProp.getString("validPolicyMessage");
				}

				/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					button.setText("Update Mobile");
					button.setPostback("UpdateMobile");
					innerbuttonlist.add(button);

					button2.setText("Update Email");
					button2.setPostback("UpdateEmail");
					innerbuttonlist.add(button2);

					button3.setText("Update Aadhaar");
					button3.setPostback("UpdateAadhaar");
					innerbuttonlist.add(button3);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);

				}*/
			}
				break;
		             case "MobileEntered.MobileEntered-no":
		              {
		    	          speech= "Please enter 10 digits mobile number you wish to register with your Max Life policy.";
		              }
				break;


			case "EmailEntered": {
				try {
					if (responsecache_onsessionId.containsKey(sessionId)) {

						System.out.println("Action Invoded:- EmailEntered");
						//String cachePolicyNo = responsecache_onsessionId.get(sessionId).get("PolicyNo") + "";
						String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
						System.out.println(cachePolicyNo);
                                                //String cachePolicyNo = "701542425";
						boolean result = regexMatcher.isValidEmailAddress(newEmail);

						if (result) {
							String intent = "EmailId";

							speech = personalDetailUpdate.getCustomerInfo(cachePolicyNo, intent, newEmail);

							if(speech.contains("There is some communication glitch!"))
							{
								speech="There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
							}
							else
							{		
							button.setText("YES");
							button.setPostback("yes");
							innerbuttonlist.add(button);

							button2.setText("NO");
							button2.setPostback("no");
							innerbuttonlist.add(button2);

							fb.setButtons(innerbuttonlist);
							fb.setTitle("MLIChatBot");
							fb.setPlatform("API.AI");
							fb.setType("Chatbot");
							fb.setImageUrl("BOT");
							innerData.setFacebook(fb);
							}
						} else {
							speech = "Looks like the entered email id is incorrect, request you to enter correct email id.";
						}
					} else {
						speech = resProp.getString("validPolicyMessage");
					}

					/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
							.equalsIgnoreCase(speech)) {
						button.setText("Update Mobile");
						button.setPostback("UpdateMobile");
						innerbuttonlist.add(button);

						button2.setText("Update Email");
						button2.setPostback("UpdateEmail");
						innerbuttonlist.add(button2);

						button3.setText("Update Aadhaar");
						button3.setPostback("UpdateAadhaar");
						innerbuttonlist.add(button3);

						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");
						innerData.setFacebook(fb);

					}*/
				} catch (Exception e) {
					newEmail = "";
				}
			}

				break;
			case "EmailEntered.EmailEntered-yes": {
				if (responsecache_onsessionId.containsKey(sessionId)) {
					System.out.println("Action Invoded:- EmailEntered.EmailEntered-yes");
					String cachePolicyNo = responsecache_onsessionId.get(sessionId).get("PolicyNo") + "";

					//String cachePolicyNo = "719845000";
					String cacheEmail=mobile_email.get("newEmail")+"";
					System.out.println("cacheEmail"+cacheEmail);
					speech = personalDetailUpdate.updateEmail(cachePolicyNo, cacheEmail);
				} else {
					speech = resProp.getString("validPolicyMessage");
				}

				/*if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					button.setText("Update Mobile");
					button.setPostback("UpdateMobile");
					innerbuttonlist.add(button);

					button2.setText("Update Email");
					button2.setPostback("UpdateEmail");
					innerbuttonlist.add(button2);

					button3.setText("Update Aadhaar");
					button3.setPostback("UpdateAadhaar");
					innerbuttonlist.add(button3);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);

				}*/

			}
				break;
					
                             case "EmailEntered.EmailEntered-no":
			    {
			    	speech="Please enter the email id you wish to register with your Max Life policy.";
			    }
			    
				break;

		
			case "PayOnline":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- PayOnline");
					speech="We have host of online renewal payment options, you can pay renewal payment through Credit Card, EMI on Card, Net Banking, Debit Cards, Wallets /Cash card and UPI. Do you want to pay now ?";
				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "CreditCardStandingInstruction":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- CreditCardStandingInstruction");
					speech= "You simply need to fill up the credit card mandate form and send it to us along with the scanned copy of the front side of your credit card at service.helpdesk@maxlifeinsurance.com. "
						+ "To download the credit card mandate form <a href='https://goo.gl/CSWygD' target='_blank'> click here. </a>  \n Is there anything else I can help you with?(Yes/No)";
						//+ "To download the credit card mandate form click here <a href='https://goo.gl/CSWygD' target='_blank'> https://goo.gl/CSWygD </a> Is there anything else I can help you with?(Yes/No)";
				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "DirectDebit":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- DirectDebit");
					speech="To opt for direct debit facility, please send the duly filled ECS Mandate form along with a cancelled cheque at least 30 days before your next premium due date to us from your registered mail ID to service.helpdesk@maxlifeinsurance.com, "
							+ "alternatively you can submit the same at any of our branch offices. "
							+ "To download the direct debit mandate form "
							+ "<a href='https://goo.gl/htCdWy' target='_blank'> click here </a> Is there anything else I can help you with?(Yes/No)";
							//+ "<a href='https://goo.gl/htCdWy' target='_blank'> https://goo.gl/htCdWy </a> Is there anything else I can help you with?(Yes/No)";
				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "OtherProcedures":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- OtherProcedures");
					speech= "To know more about other payment options, <a href=' https://bit.ly/2fH8ITN' target='_blank'> click here </a> \n"
					//speech= "To know more about other payment options, click here <a href=' https://bit.ly/2fH8ITN' target='_blank'> bit.ly/2fH8ITN </a> \n"
							+ "Is there anything else I can help you with?(Yes/No)";
				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "PayOnline.PayOnline-yes":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- PayOnline.PayOnline-yes");
					speech="<a href='https://bit.ly/1Wis1l9' target='_blank'> Click here </a> to pay your renewal payment \n Is there anything else I can help you with?(Yes/No)";
					//speech="Click here to pay your renewal payment <a href='https://bit.ly/1Wis1l9' target='_blank'> bit.ly/1Wis1l9 </a> \n Is there anything else I can help you with?(Yes/No)";

				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}

			}
			break;
			case "PayOnline.PayOnline-no":
			case "credit.credit-yes":
			case "directdebit.directdebit-yes":
			case "others.others-yes":
			case "PayOnline.PayOnline-yes.PayOnline-yes-yes":
			{
				if(mapforrenewalPayment.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- PayOnline.PayOnline-no");
					System.out.println("Action Invoded:- credit.credit-yes");
					System.out.println("Action Invoded:- others.others-yes");
					System.out.println("Action Invoded:- directdebit.directdebit-yes");
					speech="I can help you with following options on your policy.";

					button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);

					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Policy Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);

					button8.setText("Renewal Payment Procedure");
					button8.setPostback("renewalpayment");
					innerbuttonlist.add(button8);

					button9.setText("Premium Receipt");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);
					
					button10.setText("Locate Us");
					button10.setPostback("locateus");
					innerbuttonlist.add(button10);
					
					button11.setText("Loan Inquiry");
					button11.setPostback("LoanInquiry");
					innerbuttonlist.add(button11);

					button12.setText("Update Personal Details");
                                        button12.setPostback("UpdatePersonalDetails");
				        innerbuttonlist.add(button12);

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}
				else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "chatyes":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-yes":
			{
				speech="Glad to serve you. Have a good Day.";
			}
			break;
			case "chatno":
			case "PolicyCTP.PolicyCTP-no.PolicyCTP-no-no":
			case "PolicySurrenderValue.PolicySurrenderValue-no.PolicySurrenderValue-no-no":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no.PolicyPremiumReceipt-no-no":
			case "PolicyFundValue.PolicyFundValue-no.PolicyFundValue-no-no":
			case "InputMaturity.InputMaturity-no.InputMaturity-no-no":
			case "InputPPT.InputPPT-no.InputPPT-no-no":
			case "Policypolicydocument.Policypolicydocument-no.Policypolicydocument-no-no":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-no":
			case "Client-DOB.Client-DOB-no.Client-DOB-no-no":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no.EmailEntered-yes-no-no":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no.MobileEntered-yes-no-no":	
			case "UpdateAadhar.UpdateAadhar-no.UpdateAadhar-no-no":		
			
			{
				speech="Please share your experience.";
			}
			break;
			case "customerexperience":
			{
				speech="Thank you for your feedback, will work on improving your experience.";
			}
			break;
			case "others.others-no":
			case "credit.credit-no":
			case "directdebit.directdebit-no":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no":
			case "PolicyCTP.PolicyCTP-no":
			//code added
			case "PolicySurrenderValue.PolicySurrenderValue-no":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no":
			case "PolicyFundValue.PolicyFundValue-no":
			case "InputMaturity.InputMaturity-no":
			case "InputPPT.InputPPT-no":
			case "Policypolicydocument.Policypolicydocument-no":
			case "PolicyPolicyNumberValidation.PolicyPolicyNumberValidation-no":
			case "Client-DOB.Client-DOB-no":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no":
			case "UpdateAadhar.UpdateAadhar-no":
			//
			{
				if(mapforrenewalPayment.containsKey(sessionId) || responsecache_onsessionId.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- others.others-no");
					System.out.println("Action Invoded:- credit.credit-no");
					System.out.println("Action Invoded:- directdebit.directdebit-no");
					action="instafeedback";
					System.out.println("Action Invoded:- InstaFeedBack");
					
				}else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "locateus-pincode.locateus-pincode-no":
			{
				action="instafeedback-2";
			}
			break;
			case "main.options":
			{
				speech = resProp.getString("PolicyCTP.PolicyCTP-no");
				speech = "I can help you with following on your Policy";
				if(!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.".equalsIgnoreCase(speech))
				{
					
					
									button.setText("Premium Due");
									button.setPostback("premiumdue");
									innerbuttonlist.add(button);

									button2.setText("Policy Term");
									button2.setPostback("maturity and term");
									innerbuttonlist.add(button2);
									
									button3.setText("Policy Pack");
									button3.setPostback("policypack");
									innerbuttonlist.add(button3);

									button4.setText("Maturity");
									button4.setPostback("maturity and term");
									innerbuttonlist.add(button4);

									button5.setText("Fund Value");
									button5.setPostback("Fundvalue");
									innerbuttonlist.add(button5);

									button6.setText("Cash Value");
									button6.setPostback("csv");
									innerbuttonlist.add(button6);

									button7.setText("Premium Payment Term");
									button7.setPostback("ppt");
									innerbuttonlist.add(button7);
									
									button8.setText("Renewal Payment Procedure");
									button8.setPostback("renewalpayment");
									innerbuttonlist.add(button8);
									
									button9.setText("Premium Statement");
									button9.setPostback("premiumreceipt");
									innerbuttonlist.add(button9);
									
									button10.setText("Locate Us");
									button10.setPostback("locateus");
									innerbuttonlist.add(button10);
									
									button11.setText("Loan Inquiry");
									button11.setPostback("LoanInquiry");
									innerbuttonlist.add(button11);

									button12.setText("Update Personal Details");
                                                                        button12.setPostback("UpdatePersonalDetails");
				                                        innerbuttonlist.add(button12);
					
					
					
					
					/*button.setText("Premium Due");
					button.setPostback("premiumdue");
					innerbuttonlist.add(button);

					button2.setText("Policy Term");
					button2.setPostback("maturity and term");
					innerbuttonlist.add(button2);

					button4.setText("Maturity");
					button4.setPostback("maturity and term");
					innerbuttonlist.add(button4);

					button5.setText("Fund Value");
					button5.setPostback("Fundvalue");
					innerbuttonlist.add(button5);

					button6.setText("Cash Value");
					button6.setPostback("csv");
					innerbuttonlist.add(button6);

					button7.setText("Policy Payment Term");
					button7.setPostback("ppt");
					innerbuttonlist.add(button7);

					button9.setText("Premium Receipt");
					button9.setPostback("premiumreceipt");
					innerbuttonlist.add(button9);

					button3.setText("Policy Pack");
					button3.setPostback("policypack");
					innerbuttonlist.add(button3);*/

					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}
			}
			break;
			default : 
			}
			switch(action)
			{
			case "instafeedback":
			{
				System.out.println("Action Invoded:- InstaFeedBack");
				speech="Thank you for contacting Max Life. Was the chat helpful to you?(Yes/No)";
			}
			break;
			case "instafeedback-2":
			{
				System.out.println("Action Invoded:- InstaFeedBack");
				speech="Thank you for contacting Max Life. Was the chat helpful to you?(Yes/No)";
			}
			break;
			case "feedback.feedback-yes":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no.PayOnline-yes-no-yes":
			case "credit.credit-no.credit-no-yes":
			case "directdebit.directdebit-no.directdebit-no-yes":
			case "others.others-no.others-no-yes":
			case "PolicyCTP.PolicyCTP-no.PolicyCTP-no-yes":
			// code added
			case "PolicySurrenderValue.PolicySurrenderValue-no.PolicySurrenderValue-no-yes":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no.PolicyPremiumReceipt-no-yes":
			case "PolicyFundValue.PolicyFundValue-no.PolicyFundValue-no-yes":
			case "InputMaturity.InputMaturity-no.InputMaturity-no-yes":
			case "InputPPT.InputPPT-no.InputPPT-no-yes":
			case "Policypolicydocument.Policypolicydocument-no.Policypolicydocument-no-yes":
			case "Client-DOB.Client-DOB-no.Client-DOB-no-yes":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no.EmailEntered-yes-no-yes":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no.MobileEntered-yes-no-yes":
			case "UpdateAadhar.UpdateAadhar-no.UpdateAadhar-no-yes":			
			//
			{
				if(mapforrenewalPayment.containsKey(sessionId) || responsecache_onsessionId.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- feedback.feedback-yes");
					instaCallBack(sessionId);
					speech="Glad to serve you. Have a good Day.";
				}else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			case "feedback.feedback-no":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no.PayOnline-yes-no-no":
			case "credit.credit-no.credit-no-no":
			case "directdebit.directdebit-no.directdebit-no-no":
			case "others.others-no.others-no-no":
			{
				if(mapforrenewalPayment.containsKey(sessionId) || responsecache_onsessionId.containsKey(sessionId))
				{
					System.out.println("Action Invoded:- feedback.feedback-no");
					instaCallBack(sessionId);
					speech="Thank you for your feedback, will work on improving your experience.";
				}else
				{
					speech="I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			}
			break;
			default:
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		
		try{
			String dbSessionId=sessionId;
			String dbPolicyNumber="";
			String dbResolvedQuery="";
			if(responsecache_onsessionId.containsKey(sessionId))
			{
				String cachePolicyNo=responsecache_onsessionId.get(sessionId).get("PolicyNo")+"";
				dbPolicyNumber=cachePolicyNo;
			}else
			{
				dbPolicyNumber=policy_Number;
			}
			String dbAction=action;
			
			if("customerexperience".equalsIgnoreCase(action))
			{
			String ResolvedQuery=resolvedQuery.substring(19,(resolvedQuery.length()));
			dbResolvedQuery=ResolvedQuery;
			}
			else
			{
			dbResolvedQuery=resolvedQuery;
			}
			//String dbResolvedQuery=resolvedQuery.substring(19,(resolvedQuery.length()));
			//String dbResolvedQuery=resolvedQuery;
			String db2PolicyNumber=dbPolicyNumber;
			String dbspeech=speech;
			String db2ResolvedQuery=dbResolvedQuery;
			Thread t1=new Thread(new Runnable() 
			{
				public void run() 
				{
					System.out.println("Run Method Start");
					String status=adoption.adoptionlogsCall(dbSessionId, db2PolicyNumber, dbAction, db2ResolvedQuery, dbspeech);
					//String status=adoption.adoptionlogsCall(dbSessionId, db2PolicyNumber, dbAction, dbResolvedQuery, dbspeech);
					//String status=adoption.adoptionlogsCall(dbSessionId, db2PolicyNumber, dbAction, dbResolvedQuery);
				}
			});
			t1.start();
			t1.join();
			System.out.println("Run Method END");

		}catch(Exception ex)
		{
			System.out.println("Excption Occoured while saving data in to the database");
		}
		System.out.println(speech);
		WebhookResponse responseObj = new WebhookResponse(speech, speech,innerData);
		return responseObj;
	}
	public String instaCallBack(String sessionId)
	{
		String speech="";
		if(responsecache_onsessionId.containsKey(sessionId) || mapforrenewalPayment.containsKey(sessionId))
		{
			System.out.println("Action Invoded:- close.conversation");
			for(Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet())
			{
				String key = entry.getKey();
				if(key.equalsIgnoreCase(sessionId))
				{
					mapforcashbeforevalidation.remove(sessionId);
					mapforrenewalPayment.remove(sessionId);
				}
			}
			responsecache_onsessionId.remove(sessionId);
			mapforrenewalPayment.remove(sessionId);
			logger.info("Session_Id Removed :-" + sessionId);
			speech = "Thank you for contacting Max Life. Have a great day!";
		}
		else{
			speech = "Thank you for contacting Max Life. Have a great day!";
		}
		return speech;
	}
	//private static Pattern emailNamePtrn = Pattern
			//.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

	//public static boolean isValidEmailAddress(String email) {
		
		  //boolean result=true; 
		  //try { 
			//  InternetAddress emailAddr = new
		     // InternetAddress(email); emailAddr.validate(); 
		//  } catch(Exception e) 
		//  {
		// System.out.println(e); result=false; }
		
		//return result;
	//}
}
