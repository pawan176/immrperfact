package common;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ResourceBundle;
import javax.net.ssl.HttpsURLConnection;

public class AddressDetailService 
{
	public String AddressDetail(String pincode)
	{
		ResourceBundle res = ResourceBundle.getBundle("errorMessages");
		String applicationurl=res.getString("javalocateusurl");
		String output = new String();
		StringBuilder result = new StringBuilder();
		StringBuilder requestdata = new StringBuilder();
		HttpURLConnection conn = null;
		try{
			XTrustProvider trustProvider = new XTrustProvider();
			trustProvider.install();
			URL url = new URL(applicationurl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			requestdata.append(" 	{	 ");
			requestdata.append(" 	      \"payload\": {	 ");
			requestdata.append(" 	         \"pinCode\": \"").append(pincode).append("\"");
			requestdata.append(" 	   }	 ");
			requestdata.append(" 	}	 ");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}

			int apiResponseCode = conn.getResponseCode();
      System.out.println("API RESPONSE CODE FROM LOCATEUS SERVICE :- "+apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
      System.out.println("Exception Occoured While Calling API's ");
		}
		return result.toString();
	}
}
