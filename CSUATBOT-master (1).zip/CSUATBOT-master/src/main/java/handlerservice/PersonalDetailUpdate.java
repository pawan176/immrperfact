package handlerservice;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import common.Commons;
import common.XTrustProviderSSL;

@Component
public class PersonalDetailUpdate {
	
	public static ResourceBundle res = ResourceBundle.getBundle("errorMessages");
	
	public String getCustomerInfo(String policyNo, String intent, String flag)
	{
		String result="";
		String currentMobileNumber="";
		String currentEmail="";

		try
		{
			String soaurl="https://gatewayuat.maxlifeinsurance.com/apimgm/sb/soa/policyadministration/customer360/customercontactinfo/v1";
			XTrustProviderSSL.trustHttps();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("client_id", "27181c84-7120-4810-862d-b443f3b3bae8");
			headers.set("client_secret", "hU2lA8yS8jH5oF1tR0iY4hN2kV3eI5gV7iP1wI6mW5dP2gU7fT");
			StringBuilder sb=new StringBuilder();
			sb.append("{ ");
			sb.append("\"request\": { ");
			sb.append("\"header\": { ");
			sb.append("\"soaMsgVersion\": \"1.0\",");
			sb.append("\"soaCorrelationId\": \"225163708\",");
			sb.append("\"soaAppId\": \"CSBOT\"");
			sb.append("}, ");
			sb.append("\"requestData\": { ");
			sb.append("\"policyNo\": \""+policyNo+"\" ");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
			RestTemplate restTemplate=new RestTemplate();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			ResponseEntity<String> response = restTemplate.exchange(soaurl, HttpMethod.POST, entity,String.class);
			System.out.println(response);
			System.out.println("getStatusCodeValue"+response.getStatusCodeValue());
			if(response.getStatusCodeValue() == 200)
			{
				Map personaldetailupdate = new  Commons().getGsonData(response.getBody());
				Map responseData = (Map)((Map)personaldetailupdate.get("response")).get("responseData");
				if("200".equalsIgnoreCase(responseData.get("soaStatusCode")+""))
				{
					System.out.println("soaStatusCode"+responseData.get("soaStatusCode")+"");
					if(intent.equalsIgnoreCase("MobileNo"))
					{
					JSONObject jsonobj= new JSONObject(responseData);
				        try
					{
					currentMobileNumber = jsonobj.getJSONArray("mobileNumber").getJSONObject(0).getString("mobileNo")+"";
					}catch(Exception e)
					{
					     System.out.println(e);
					}
					System.out.println(currentMobileNumber);
				        if(null!=(currentMobileNumber)||!"".equalsIgnoreCase(currentMobileNumber))
					{
					result = "I will be updating your mobile number from " + currentMobileNumber + " to "
					+ flag
					+ " in your policy records, shall I go ahead & update the records?";
					}
					}
					else
					{
						JSONObject jsonobj= new JSONObject(responseData);
						System.out.println("jsonobj"+jsonobj);
						try
						{
						currentEmail = jsonobj.getJSONArray("emailIds").getJSONObject(0).getString("emailId")+"";
						}catch(Exception e)
						{
							System.out.println(e);
						}
						System.out.println("currentEmail"+currentEmail);
						if(null!=(currentEmail)||!"".equalsIgnoreCase(currentEmail))
						{
					        result = "I will be updating your Email Id from " + currentEmail + " to "
							+ flag
							+ " in your policy records, shall I go ahead & update the records?";
					}
					}
				}
									
			}
			else
			{
				return "There is some communication glitch! Please try again after some time. Error Code -MAX00GCI";
			}
		}catch(Exception ex)
		{
			System.out.println("exception"+ ex);
			return "There is some communication glitch! Please try again after some time. Error Code -EXMAX00GCI";
		}
		return result;
	
	}
	
	public String updateMobile(String policyNo, String newMobileNumber)
	{
		try
		{
			String soaurl="https://gatewayuat.maxlifeinsurance.com/apimgm/sb/soa/salesandcustomerservice/customerdetails/customercontactdetail/v1/updatecontactdetail";
			XTrustProviderSSL.trustHttps();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("client_id", "27181c84-7120-4810-862d-b443f3b3bae8");
			headers.set("client_secret", "hU2lA8yS8jH5oF1tR0iY4hN2kV3eI5gV7iP1wI6mW5dP2gU7fT");
			StringBuilder sb=new StringBuilder();
			sb.append("{ ");
			sb.append("\"request\": { ");
			sb.append("\"header\": { ");
			sb.append("\"soaMsgVersion\": \"1.0\",");
			sb.append("\"soaCorrelationId\": \"0024578965\",");
			sb.append("\"soaAppId\": \"CSBOT\"");
			sb.append("}, ");
			sb.append("\"requestData\": { ");
			sb.append("\"policyNo\": \""+policyNo+"\",");
			sb.append("\"mobileNo\": \""+newMobileNumber+"\" ");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
			RestTemplate restTemplate=new RestTemplate();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			ResponseEntity<String> response = restTemplate.exchange(soaurl, HttpMethod.POST, entity,String.class);
			if(response.getStatusCodeValue() == 200)
			{
				Map personaldetailupdate = new  Commons().getGsonData(response.getBody());
				Map responseData = (Map)((Map)personaldetailupdate.get("response")).get("responseData");
				if("200".equalsIgnoreCase(responseData.get("soastatusCode")+"")
					&& "Success".equalsIgnoreCase(responseData.get("soaMessage")+""))
				{
					return "Thank you for updating your mobile number, it will get updated in our records within next 1 hour."
							+" Is there anything else I can help you with? (Yes/No)";
				}
				else
				{
					return "Sorry!! We are unable to update your policy records at this time. Please try again later."
							+" Is there anything else I can help you with? (Yes/No)";

				}
			}
			else
			{
				return "There is some communication glitch! Please try again after some time. Error Code -MAX00UM";
			}
		}catch(Exception ex)
		{
			return "There is some communication glitch! Please try again after some time. Error Code -EXMAX00UM";
		}
		
	
	}
	
	public String updateEmail(String policyNo, String emailId)
	{
		try
		{
			String soaurl="https://gatewayuat.maxlifeinsurance.com/apimgm/sb/soa/salesandcustomerservice/customerdetails/customercontactdetail/v1/updatecontactdetail";
			XTrustProviderSSL.trustHttps();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("client_id", "27181c84-7120-4810-862d-b443f3b3bae8");
			headers.set("client_secret", "hU2lA8yS8jH5oF1tR0iY4hN2kV3eI5gV7iP1wI6mW5dP2gU7fT");
			StringBuilder sb=new StringBuilder();
			sb.append("{ ");
			sb.append("\"request\": { ");
			sb.append("\"header\": { ");
			sb.append("\"soaMsgVersion\": \"1.0\",");
			sb.append("\"soaCorrelationId\": \"0024578965\",");
			sb.append("\"soaAppId\": \"CSBOT\"");
			sb.append("}, ");
			sb.append("\"requestData\": { ");
			sb.append("\"policyNo\": \""+policyNo+"\",");
			sb.append("\"emailId\": \""+emailId+"\" ");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
			RestTemplate restTemplate=new RestTemplate();
			restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
			ResponseEntity<String> response = restTemplate.exchange(soaurl, HttpMethod.POST, entity,String.class);
			if(response.getStatusCodeValue() == 200)
			{
				Map personaldetailupdate = new  Commons().getGsonData(response.getBody());
				Map responseData = (Map)((Map)personaldetailupdate.get("response")).get("responseData");
				if("200".equalsIgnoreCase(responseData.get("soastatusCode")+"")
						&& "Success".equalsIgnoreCase(responseData.get("soaMessage")+""))
				{
					return "Thank you for updating your email ID, it will get updated in our records within next 1 hour."
							+ " Is there anything else I can help you with? (Yes/No)";
				}
				else
				{
					return "Sorry!! We are unable to update your policy records at this time. Please try again later."
							+ " Is there anything else I can help you with? (Yes/No)";

				}
			}
			else
			{
				return "There is some communication glitch! Please try again after some time. Error Code -MAX00UE";
			}
		}catch(Exception ex)
		{
			return "There is some communication glitch! Please try again after some time. Error Code -EXMAX00UE";
		}
	
	}

}

