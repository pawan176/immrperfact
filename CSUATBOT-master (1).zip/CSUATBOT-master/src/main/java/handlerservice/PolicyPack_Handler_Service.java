package handlerservice;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import common.Commons;
import common.Httpurl_Connection;

@Component
public class PolicyPack_Handler_Service 
{
	private static Logger logger = LogManager.getLogger(MliDoc_Handler_Service.class);
	public static ResourceBundle res = ResourceBundle.getBundle("errorMessages");
	public Map<String, String> getPolicyPackService (String policyNo)
	{
		System.out.println("PolicyPack Handler Service START");
		logger.info("Came Inside" + "getPolicyPackService :: Method :: STARTS");
		String finaldate="";
		String mliDoc = "PolicyPack";
		HashMap<String, String> returnMap = new HashMap();
		/*new Thread(new Runnable() 
		{
			public void run() 
			{
				System.out.println("Thread Running Process Start");
				Httpurl_Connection connection = new Httpurl_Connection();
				String result = connection.httpConnection_response(policyNo, mliDoc, finaldate);
			}
		}).start();*/
		
		//Httpurl_Connection connection = new Httpurl_Connection();
		//String result = connection.httpConnection_response(policyNo, mliDoc, finaldate);
		//System.out.println("Httpurl_Connection :: Result.tostring END FOR CHECKING");
		//System.out.println("Result Get From HttpUrlConnection :- "+ result.toString());
		try
		{
			/*Map resultData = Commons.getGsonData(result);
			String soaStatusCode = ((Map) ((Map) resultData.get("response")).get("responseData"))
					.get("statusCode").toString();*/
			/*if (soaStatusCode != null && !"".equalsIgnoreCase(soaStatusCode) && soaStatusCode.equalsIgnoreCase("200"))*/
			if(true)
			{
				//logger.info("Result Data :-"+ resultData );
				/*String statusMessage = ((Map) ((Map) resultData.get("response")).get("responseData"))
						.get("statusMessage").toString();*/
				String statusMessage ="Success";
				if (statusMessage.startsWith("Failure")) {
					returnMap.put("Message", res.getString("PolicyPackServiceFailure"));
				} else {
					returnMap.put("Message", res.getString("PolicyPackServiceSuccess"));
				}
			} 
			/*else
			{
				returnMap.put("Message", res.getString("PolicyPackServiceFailure"));
			}*/
			logger.info("Came OutSide" + "getPolicyPackService :: Method :: END");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("PolicyPack Handler Service END");
		return returnMap;
	}
}


