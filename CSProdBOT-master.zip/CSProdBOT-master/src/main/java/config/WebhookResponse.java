package config;

public class WebhookResponse {
    private final String speech;
    private final String displayText;
    private InnerData data;
    private final String source = "java-webhook";

	public WebhookResponse(String speech, String displayText) {
        this.speech = speech;
        this.displayText = displayText;
        
    }
    public WebhookResponse(String speech, String displayText, InnerData data) {
        this.speech = speech;
        this.displayText = displayText;
        this.data = data;
    }

    public String getSpeech() {
        return speech;
    }

    public String getDisplayText() {
        return displayText;
    }

    public String getSource() {
        return source;
    }
    public InnerData getData() {
		return data;
	}

	public void setData(InnerData data) {
		this.data = data;
	}
}
