package messageimpl;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class WIPCases 
{
	@Autowired
	private Bean bean;
	
	public String wipCasesIntent(JSONObject object, String wipyes)
	{
		String finalresponse="";
		double wip_Count=0;
		double wip_ADJ_MFYP=0;
		double wip_ADJ_MFYP1=0;
		String real_TIM_TIMSTAMP="";
		String location="";
		StringBuffer message = new StringBuffer();
		try{
			JSONArray array=object.getJSONObject("payload").getJSONArray("wipCases");
			{
				for(int i=0; i<array.length();i++)
				{
					if("".equalsIgnoreCase(wipyes))
					{
						try{
							wip_Count=wip_Count+Double.parseDouble(array.getJSONObject(i).get("wip_COUNT")+"");
						}catch(Exception ex)
						{
							wip_Count=0;
						}
						try{
							wip_ADJ_MFYP=wip_ADJ_MFYP+Double.parseDouble(array.getJSONObject(i).get("wip_ADJ_MFYP")+"");
						}catch(Exception ex)
						{
							wip_ADJ_MFYP=0;
						}
						try{
							real_TIM_TIMSTAMP=array.getJSONObject(i).get("real_TIM_TIMSTAMP")+"";
						}catch(Exception ex)
						{
							real_TIM_TIMSTAMP="";
						}
					}
					else
					{
						try{
							wip_ADJ_MFYP1=wip_ADJ_MFYP1+Double.parseDouble(array.getJSONObject(i).get("wip_ADJ_MFYP")+"");
						}catch(Exception ex)
						{
							wip_ADJ_MFYP1=0;
						}
						try{
							location=array.getJSONObject(i).get("wip_STAGE")+"";
						}catch(Exception ex)
						{
							location="";
						}
						if("HO".equalsIgnoreCase(location)||"GO".equalsIgnoreCase(location)||"FIN".equalsIgnoreCase(location)
								||"IT".equalsIgnoreCase(location) ||"MISC".equalsIgnoreCase(location)||"WELCOME".equalsIgnoreCase(location))
						{
							message.append(location+": WIP ADJ MFYP "+wip_ADJ_MFYP1+", ");
						}
						else
						{
							message.append(", "+location+": WIP ADJ MFYP "+wip_ADJ_MFYP1);
						}
					}
				}
			}
		}catch(Exception ex)
		{
			finalresponse="Somthing went wrong in wip logic, Please contact to concern team.";
		}
		if("".equalsIgnoreCase(wipyes))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
			else
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
		}
		else
		{
			finalresponse=message.toString();
		}
		System.out.println("WIPCases--"+ finalresponse);
		return finalresponse;
	}
}
