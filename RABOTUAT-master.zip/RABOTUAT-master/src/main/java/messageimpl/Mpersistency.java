package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class Mpersistency 
{
	@Autowired
	private Bean bean;
	
	public String mPersistencyIntent(String segmentAction)
	{
		String finalresponse="";
		if("FLS.MPERSISTENCY".equalsIgnoreCase(segmentAction))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			System.out.println("WelcomeCallingStatus--"+ finalresponse);
			
		}
		else if("FLS.MPERSISTENCYBASE".equalsIgnoreCase(segmentAction))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			System.out.println("WelcomeCallingStatus--"+ finalresponse);
		}
		else
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
				
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
			}
			System.out.println("WelcomeCallingStatus--"+ finalresponse);
		}
		return finalresponse;
	}
}
