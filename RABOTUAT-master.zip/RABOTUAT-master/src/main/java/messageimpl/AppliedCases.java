package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class AppliedCases 
{
	@Autowired
	private Bean bean;
	public String appliedCasesIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			 +" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		System.out.println("AppliedCases--"+ finalresponse);
		return finalresponse;
	}

}
