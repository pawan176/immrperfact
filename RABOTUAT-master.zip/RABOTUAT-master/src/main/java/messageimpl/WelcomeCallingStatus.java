package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class WelcomeCallingStatus 
{
	@Autowired
	private Bean bean;
	
	public String welcomeCallingStatusIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The Welcome Calling status for Policy "+bean.getPolicy_number()+ " is "+bean.getPol_welcom_call_status();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The Welcome Calling status for Policy "+bean.getPolicy_number()+ " is "+bean.getPol_welcom_call_status();
		}
		else
		{
			finalresponse="The Welcome Calling status for Policy "+bean.getPolicy_number()+ " is "+bean.getPol_welcom_call_status();
		}
		System.out.println("WelcomeCallingStatus--"+ finalresponse);
		return finalresponse;
	}
}
