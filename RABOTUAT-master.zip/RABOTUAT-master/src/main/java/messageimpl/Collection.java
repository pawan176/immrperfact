package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class Collection 
{
	@Autowired
	private Bean bean;
	public String collectionIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
		finalresponse="Not Applicable";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					", Your total collected amount for this month is Rs."+bean.getTotal_collection_mfyp()+
					" Lacs. Total collectable amount for the month is Rs."+bean.getTotal_collection_amt()+" Lacs.";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+
					", Your total collected amount for this month is Rs."+bean.getTotal_collection_mfyp()+
					" Lacs. Total collectable amount for the month is Rs."+bean.getTotal_collection_amt()+" Lacs.";
		}
		System.out.println("AdjMFYPIntent--"+ finalresponse);
		return finalresponse;
	}
}
