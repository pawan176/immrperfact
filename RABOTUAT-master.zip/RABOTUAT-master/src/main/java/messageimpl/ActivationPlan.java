package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class ActivationPlan 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String activationPlanIntent(String channel)
	{
		if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+" Activation Plan is "+bean.getMtd_activa_plan_ach_prcntg()+"% "
					+ "with Manmonth "+bean.getMtd_activa_plan_manmonth()+" and Active "+bean.getMtd_activa_plan_active();
		}
		else if("BancAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+" Activation Plan is "+bean.getActivisa_mtd_plan_prcntg()+"%.";
		}
		else{
			finalresponse="NOT APPLICABLE";
		}
		return finalresponse;
	}
}
