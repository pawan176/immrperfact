package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class MedicalCategory 
{
	@Autowired
	private Bean bean;
	public String medicalCategoryIntent(String policyNumber)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		else
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		System.out.println("MedicalCategory--"+ finalresponse);
		return finalresponse;
	}
}
