package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class PolicyStatusDobPan 
{
	@Autowired
	private Bean bean;
	
	public String policyStatusDobPanIntent(String customerName)
	{

		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		else
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		System.out.println("PolicyStatusDobPan --"+finalresponse);
		return finalresponse;
		
	}

}
