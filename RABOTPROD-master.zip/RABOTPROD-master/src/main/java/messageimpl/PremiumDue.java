package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class PremiumDue 
{
	@Autowired
	private Bean bean;

	public String premiumDueIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		else
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		System.out.println("PremiumDue--"+ finalresponse);
		return finalresponse;
	}
}
