package messageimpl;

import org.springframework.stereotype.Service;

@Service
public class ReasonWelcomeCallStatus 
{
	public String reasonWelcomeCallStatusIntent()
	{
		String finalresponse="Sorry we don't have anything yet for this Intent";
		return finalresponse;
	}
}
