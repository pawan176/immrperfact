package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class AdjMFYP 
{
	@Autowired
	private Bean bean;
	public String adjMFYPIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		else
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		System.out.println("AdjMFYPIntent--"+ finalresponse);
		return finalresponse;
	}
}
