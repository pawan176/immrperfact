package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class PaidCases 
{
	@Autowired
	private Bean bean;
	public String paidCasesIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				", MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				",  MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		else
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				",  MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		System.out.println("PaidCases--"+finalresponse);
		return finalresponse;
	}
}
