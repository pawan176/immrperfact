package service;
import hello.WebhookResponse; 
import java.text.DecimalFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import entity.DataBean;
import common.CallingJavaService;
import messageimpl.AdjMFYP;
import messageimpl.AppliedCases;
import messageimpl.AppliedFYP;
import messageimpl.Collection;
import messageimpl.ECSDatePolicy;
import messageimpl.FundValue;
import messageimpl.MedicalCategory;
import messageimpl.Mpersistency;
import messageimpl.NomineeDetails;
import messageimpl.Ntued;
import messageimpl.PaidCases;
import messageimpl.PolicyPack;
import messageimpl.PolicyStatus;
import messageimpl.PolicyStatusDobPan;
import messageimpl.PremiumDue;
import messageimpl.ReasonWelcomeCallStatus;
import messageimpl.RenewalPremium;
import messageimpl.RollingCollection;
import messageimpl.WIPCases;
import messageimpl.WelcomeCallingStatus;
import messageimpl.WtgMFYP;
import messageimpl.Help;
/*===================Sprint 3.2===========START====================*/
import messageimpl.Activation;
import messageimpl.ActivationPlan;
import messageimpl.PlanAchievement;
import messageimpl.Performance;
import messageimpl.PerformanceShortFall;
import messageimpl.GPA;
import messageimpl.Recruitment;
import messageimpl.QualityRecruitment;
import messageimpl.RecruitmentPlan;
import messageimpl.NAT;
/*===================Sprint 3.2============END===================*/

@Service
public class APIConsumerService 
{
	@Autowired private CallingJavaService callingJavaService;
	@Autowired private DataBean dataBean;
	@Autowired private AdjMFYP  adjMFYP;
	@Autowired private Collection collection;
	@Autowired private ECSDatePolicy eCSDatePolicy;
	@Autowired private FundValue fundValue;
	@Autowired private MedicalCategory medicalCategory;
	@Autowired private Mpersistency mpersistency;
	@Autowired private NomineeDetails nomineeDetails;
	@Autowired private Ntued ntued;
	@Autowired private PaidCases paidCases;
	@Autowired private PolicyPack policyPack;
	@Autowired private PolicyStatusDobPan policyStatusDobPan;
	@Autowired private PolicyStatus policyStatus;
	@Autowired private PremiumDue premiumDue;
	@Autowired private ReasonWelcomeCallStatus reasonWelcomeCallStatus;
	@Autowired private RenewalPremium renewalPremium;
	@Autowired private RollingCollection rollingCollection;
	@Autowired private WelcomeCallingStatus welcomeCallingStatus;
	@Autowired private WIPCases wIPCases;
	@Autowired private WtgMFYP wtgMFYP;
	@Autowired private AppliedCases appliedCases;
	@Autowired private AppliedFYP appliedFYP;
	@Autowired private Help help;
	/*-----------------Spring 3.2--------------------------*/
	@Autowired private Activation activation;
	@Autowired private ActivationPlan activationPlan;	
	@Autowired private PlanAchievement planAchievement;
	@Autowired private Performance performance;
	@Autowired private PerformanceShortFall performanceShortFall;
	@Autowired private GPA gpa;
	@Autowired private Recruitment recruitment;
	@Autowired private QualityRecruitment qualityRecruitment;
	@Autowired private RecruitmentPlan recruitmentPlan;
	@Autowired private NAT nat;
	/*-----------------Spring 3.2--------------------------*/
	
	private static Logger logger = LogManager.getLogger(APIConsumerService.class);
	public WebhookResponse getWipDataAll(String action, String channel, String period,String policyNumber,
			String user_ssoid, String user_sub_channel, String sessionId, String source, String raAdmAgtId, String customerName)
	{
		System.out.println("In Time::");
		String segment="";
		String segmentAction=action.toUpperCase();
		try{
		String [] modifyAction=action.split("FLS.");
		segment=modifyAction[1].toUpperCase();
		}catch(Exception ex)
		{
			segment="AdJMFYP";
		}
		String result = null;
		String finalresponse="";
		try{
			if("FLS.MPERSISTENCYUNPAID".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.MPERSISTENCYBASE".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.WIPYES".equalsIgnoreCase(segmentAction))
			{
				segment="WIPCASES";
			}
			else if(segment.equalsIgnoreCase("HELP"))
			{
				finalresponse=help.helpIntent();
			}
			if("".equalsIgnoreCase(finalresponse))
			{
				System.out.println("Call START 2: Call JavaService :: START");
				result = callingJavaService.callService(segment, user_ssoid, channel, user_sub_channel, raAdmAgtId, policyNumber);
				System.out.println("Call START 2: Call JavaService :: END");
			}
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occourd While calling java Service");
			finalresponse="Something went wrong in BOT! Please try after sometime! (JavaService)";
		}
		try
		{
		    if(result!=null && !result.isEmpty())
		    {
			JSONObject object = new JSONObject(result);
			String status="";
			String [] regex = segment.split(",");
			for(int i=0; i<regex.length; i++)
			{
				String split= regex[i];
				String splitIntent=split.toUpperCase();
				if("ACTIVATION".equalsIgnoreCase(splitIntent) || "ACTIVATIONPLAN".equalsIgnoreCase(splitIntent) || "PLANACHIEVEMENT".equalsIgnoreCase(splitIntent)
							||"PERFORMANCE".equalsIgnoreCase(splitIntent) || "PERFORMANCESHORTFALL".equalsIgnoreCase(splitIntent) 
							|| "GPA".equalsIgnoreCase(splitIntent) || "RECRUITMENT".equalsIgnoreCase(splitIntent) || "QUALITYRECRUITMENT".equalsIgnoreCase(splitIntent)
							|| "RECRUITMENTPLAN".equalsIgnoreCase(splitIntent) || "NAT".equalsIgnoreCase(splitIntent))
					{
						if("AXIS BANK".equalsIgnoreCase(channel))
						{
							splitIntent="AXISBANK";
						}
						else if("BancAssurance".equalsIgnoreCase(channel) || "Yes Bank".equalsIgnoreCase(channel))
						{
							splitIntent="YBL";
						}
						else if("CAT".equalsIgnoreCase(channel))
						{
							splitIntent="CAT";
						}
						else if("Agency".equalsIgnoreCase(channel))
						{
							splitIntent="Agency";
						}
					}
				System.out.println("In Time:Bean SET:");
				status = dataBean.getDatafromJsonObject(splitIntent, object);
				System.out.println("Out Time:Bean SET:");
			}
			if("true".equalsIgnoreCase(status))
			{
				System.out.println("Switch CASE Action:--"+segmentAction);
				switch(segmentAction)
				{
				case "FLS.ADJMFYP":
				{
					finalresponse=adjMFYP.adjMFYPIntent();
				}
				break;
				case "FLS.PAIDCASES":
				{
					finalresponse=paidCases.paidCasesIntent();
				}
				break;
				case "FLS.WTGMFYP":
				{
					finalresponse=wtgMFYP.wtgMFYPIntent();
				}
				break;
				case "FLS.POLICYSTATUS":
				{
					finalresponse=policyStatus.policyStatusIntent(policyNumber, customerName);
				}
				break;
				case "FLS.POLICYSTATUSDOBPAN":
				{
					finalresponse=policyStatusDobPan.policyStatusDobPanIntent(customerName);
				}
				break;
				case "FLS.RENEWALPREMIUM":
				{
					finalresponse=renewalPremium.renewalPremiumIntent(policyNumber);
				}
				break;
				case "FLS.PREMIUMDUE":
				{
					System.out.println("In Time:FLS.PremiumDue:");
					finalresponse=premiumDue.premiumDueIntent();
					System.out.println("Out Time:FLS.PremiumDue:");
				}
				break;
				case "FLS.COLLECTION":
				{
					finalresponse=collection.collectionIntent();
				}
				break;

				case "FLS.ROLLINGCOLLECTION":
				{
					finalresponse=rollingCollection.rollingCollectionIntent();
				}
				break;
				case "FLS.NTUED":
				{
					finalresponse=ntued.ntuedIntent();
				}
				break;
				case "FLS.NOMINEEDETAILS":
				{
					System.out.println("NomineeDetails ::START");
					/*if(!"".equalsIgnoreCase(policyNumber) && policyNumber!=null)
					{
						finalresponse=nomineeDetails.nomineeDetailsIntent(policyNumber, object);
					}
					else
					{
						finalresponse="PolicyNo. required ! ";
					}*/
					finalresponse="This information is not available";
					System.out.println("NomineeDetails ::END");
				}
				break;
				case "FLS.POLICYPACK":
				{
					finalresponse=policyPack.policyPackIntent();
				}
				break;
				case "FLS.MEDICALCATEGORY":
				{
					if(!"".equalsIgnoreCase(policyNumber))
					{
						finalresponse=medicalCategory.medicalCategoryIntent(policyNumber);
					}else
					{
						finalresponse="PolicyNo. required ! ";
					}
				}
				break;
				case "FLS.FUNDVALUE":
				{
					finalresponse=fundValue.fundValueIntent(policyNumber);
				}
				break;
				case "FLS.ECSDATEPOLICY":
				{
					finalresponse=eCSDatePolicy.eCSDatePolicyIntent(policyNumber);
				}
				break;
				case "FLS.WELCOMECALLINGSTATUS":
				{
					finalresponse=welcomeCallingStatus.welcomeCallingStatusIntent();
				}
				break;
				case "FLS.REASONWELCOMECALLSTATUS":
				{
					finalresponse=reasonWelcomeCallStatus.reasonWelcomeCallStatusIntent();
				}
				break;
				case "FLS.MPERSISTENCY":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.MPERSISTENCYBASE":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.MPERSISTENCYUNPAID":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.WIPCASES":
				{
					String wipyes="";
					finalresponse=wIPCases.wipCasesIntent(object, wipyes);
				}
				break;
				case "FLS.WIPYES":
				{
					String wipyes = "WIPYES";
					finalresponse=wIPCases.wipCasesIntent(object, wipyes );
				}
				break;
						
				case "FLS.APPLIEDCASES":
				{
					finalresponse=appliedCases.appliedCasesIntent();
				}
				break;
				case "FLS.APPLIEDFYP":
				{
					finalresponse=appliedFYP.appliedFYPIntent();
				}
				break;
				/*---------------------------------------------------------------RABOT SPRINT 3.2---------------------------------------------------------------*/
				case "FLS.ACTIVATION":
				{
					finalresponse=activation.activationIntent(channel);
				}
				break;
				case "FLS.ACTIVATIONPLAN":
				{
					finalresponse=activationPlan.activationPlanIntent(channel);
				}
				break;
				case "FLS.PLANACHIEVEMENT":
				{
					finalresponse=planAchievement.planAchievementIntent(channel);
				}
				break;
				case "FLS.PERFORMANCE":
				{
					finalresponse=performance.performanceIntent(channel);
				}
				break;
				case "FLS.PERFORMANCESHORTFALL":
				{
					finalresponse=performanceShortFall.performanceShortFallIntent(channel);
				}
				break;
				case "FLS.GPA":
				{
					finalresponse=gpa.gpaIntent(channel);
				}
				break;
				case "FLS.RECRUITMENT":
				{
					finalresponse=recruitment.recruitmentIntent(channel);
				}
				break;
				case "FLS.QUALITYRECRUITMENT":
				{
					finalresponse=qualityRecruitment.qualityRecruitmentIntent(channel);
				}
				break;
				case "FLS.RECRUITMENTPLAN":
				{
					finalresponse=recruitmentPlan.recruitmentPlanIntent(channel);
				}
				break;
				case "FLS.NAT":
				{
					finalresponse=nat.natIntent(channel);
				}
				break;
				default :
					finalresponse="Your action not identified by BOT! Please contact to concern team";
				}
			}
			else
			{
				finalresponse="Bean found Error! Please contact to concern team";
			}
		    }
		else
		{
			if(!segment.equalsIgnoreCase("HELP"))
			{
				finalresponse="Fetched result null or empty ! Please contact to concern team";
			}
		}
	}
	catch(Exception e)
	{
		finalresponse="Something went wrong in Bot \n. Please contact to concern team.";
	}
	String speech=finalresponse;
	System.out.println("Final Response :- "+speech);
	WebhookResponse responseObj = new WebhookResponse(speech, speech);
	return responseObj;
    }
	public String convertToCamelCase(String channel)
	{
		final String ACTIONABLE_DELIMITERS = " '-/"; // these cause the character following
		// to be capitalized

		StringBuilder sb = new StringBuilder();
		boolean capNext = true;

		for (char c : channel.toCharArray()) {
			c = (capNext)
					? Character.toUpperCase(c)
							: Character.toLowerCase(c);
					sb.append(c);
					capNext = (ACTIONABLE_DELIMITERS.indexOf((int) c) >= 0); // explicit cast not needed

		}
		return sb.toString();
	}
}
