package common;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.UUID;
import javax.net.ssl.HttpsURLConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class CallingJavaService 
{
	private static Logger logger = LogManager.getLogger(CallingJavaService.class);
	public String callService(String action, String ssoId, String channel, String subChannel, String raAdmAgtId, String policyNumber)
	{
		String  DevMode = "N";
		StringBuilder requestdata = new StringBuilder();
		StringBuilder result = new StringBuilder();
		String output = new String();
		ResourceBundle res = ResourceBundle.getBundle("errorMessages");
		HttpURLConnection conn = null;
		if("ACTIVATION".equalsIgnoreCase(action) || "ACTIVATIONPLAN".equalsIgnoreCase(action) || "PLANACHIEVEMENT".equalsIgnoreCase(action)
				||"PERFORMANCE".equalsIgnoreCase(action) || "PERFORMANCESHORTFALL".equalsIgnoreCase(action) 
				|| "GPA".equalsIgnoreCase(action) || "RECRUITMENT".equalsIgnoreCase(action) || "QUALITYRECRUITMENT".equalsIgnoreCase(action)
				|| "RECRUITMENTPLAN".equalsIgnoreCase(action) || "NAT".equalsIgnoreCase(action))
		{
			if("AXIS BANK".equalsIgnoreCase(channel))
			{
				action="AXISBANK";
			}
			else if("BancAssurance".equalsIgnoreCase(channel) || "YesBank".equalsIgnoreCase(channel))
			{
				action="YBL";
			}
			else if("CAT".equalsIgnoreCase(channel))
			{
				action="CAT";
			}
			else if("Agency".equalsIgnoreCase(channel))
			{
				action="Agency";
			}
		}
		else if("ADJMFYP".equalsIgnoreCase(action) || "PAIDCASES".equalsIgnoreCase(action) || "WTGMFYP".equalsIgnoreCase(action)
				|| "POLICYSTATUS".equalsIgnoreCase(action) || "POLICYSTATUSDOBPAN".equalsIgnoreCase(action) 
				|| "RENEWALPREMIUM".equalsIgnoreCase(action) ||"PREMIUMDUE".equalsIgnoreCase(action) 
				|| "COLLECTION".equalsIgnoreCase(action) || "ROLLINGCOLLECTION".equalsIgnoreCase(action)
				|| "NTUED".equalsIgnoreCase(action)|| "NOMINEEDETAILS".equalsIgnoreCase(action)
				|| "POLICYPACK".equalsIgnoreCase(action) || "MEDICALCATEGORY".equalsIgnoreCase(action)
				||"FUNDVALUE".equalsIgnoreCase(action) || "ECSDATEPOLICY".equalsIgnoreCase(action) 
				|| "WELCOMECALLINGSTATUS".equalsIgnoreCase(action)|| "REASONWELCOMECALLSTATUS".equalsIgnoreCase(action) 
				|| "MPERSISTENCY".equalsIgnoreCase(action) || "WIPCASES".equalsIgnoreCase(action)
				|| "APPLIEDCASES".equalsIgnoreCase(action) || "APPLIEDFYP".equalsIgnoreCase(action)
		                || "MPERSISTENCYUNPAID".equalsIgnoreCase(action) || "MPERSISTENCYBASE".equalsIgnoreCase(action))
			{
			    System.out.println(action);
			}
			if(!"".equalsIgnoreCase(action))
			{
			   try {
				XTrustProvider trustProvider = new XTrustProvider();
				trustProvider.install();
				String serviceurl = res.getString("JavaService");
				URL url = new URL(serviceurl);
				if(DevMode!=null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode))
				{
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
					conn = (HttpURLConnection) url.openConnection(proxy);
				}else{
					conn = (HttpURLConnection) url.openConnection();
				}
				UUID uniqueId = UUID.randomUUID();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				requestdata.append("	{	");
				requestdata.append("	  \"header\": {	");
				requestdata.append("	    \"correlationId\": \""+uniqueId+"\",	");
				requestdata.append("	    \"msgVersion\": \"\",	");
				requestdata.append("	    \"appId\": \"\",	");
				requestdata.append("	    \"userId\": \"\",	");
				requestdata.append("	    \"password\": \"\",	");
				requestdata.append("	    \"rollId\":\"\"	");
				requestdata.append("	  },	");
				requestdata.append("	  \"payload\": {	");
				requestdata.append("	    \"kpi\": \""+action+"\",	");
				requestdata.append("	    \"ssoId\": \""+ssoId+"\",");
				requestdata.append("	    \"channel\": \""+channel+"\",");
				requestdata.append("	    \"subChannel\": \""+subChannel+"\",");
				requestdata.append("	    \"raAdmAgtId\": \""+raAdmAgtId+"\",");
				requestdata.append("	    \"policyNumber\": \""+policyNumber+"\"");
				requestdata.append("	  }	");
				requestdata.append("	}	");
				logger.info("START External API Call : JavaProcedureService");
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(requestdata.toString());
				writer.flush();
				try {writer.close(); } catch (Exception e1) {}
				int apiResponseCode = conn.getResponseCode();
				if(apiResponseCode == 200)
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
				else
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
			}
			catch(Exception e)
			{
				System.out.println("Exception Occoured Calling Java API's to fetch data from backend-RABOTDATASERVICE" );
			}
			System.out.println("OutSide Method:: httpConnection_response ");
		}
		return result.toString();
	}
}

