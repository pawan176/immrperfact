package JsonImpl;
import org.json.JSONObject;
import DataBean.NatHybAppliedBean;

public class NatHybApplied
{
	public static NatHybAppliedBean appliedBean = new NatHybAppliedBean();
	public void natHybAppliedBean(JSONObject object)
	{
		try{
			appliedBean.setNativ_daily_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_daily_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_daily_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_daily_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_mtd_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_mtd_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_mtd_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_mtd_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_ytd_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_ytd_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_ytd_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_ytd_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_mtd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_mtd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_ytd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_ytd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setNativ_daily_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("nativ_daily_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_daily_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_daily_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_daily_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_daily_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_mtd_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_mtd_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_mtd_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_mtd_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_ytd_applied_afyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_ytd_applied_afyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_ytd_applied_count(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_ytd_applied_count").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_mtd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_mtd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_ytd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_ytd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setHybride_daily_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("hybride_daily_applied_adj_ifyp").toString());
		}catch(Exception e){}
		try{
			appliedBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybApplied").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}

}
