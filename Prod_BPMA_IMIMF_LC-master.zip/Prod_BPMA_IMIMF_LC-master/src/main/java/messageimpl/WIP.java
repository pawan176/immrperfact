package messageimpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import JsonImpl.NatHybWIP;

public class WIP 
{
	public static String wipIntent(String channel, String msgChannel, String convertsum4, String convertsum3)
	{
		Calendar cal = Calendar.getInstance(); // creates calendar
	   	cal.setTime(new Date()); // sets calendar time/date
	   	cal.add(Calendar.HOUR_OF_DAY, 5); // adds one hour
	   	cal.add(Calendar.MINUTE, 30);
	   	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		String finalresponse="";
		if(!"".equalsIgnoreCase(channel))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
						" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
						+ " Cr. Adj MFYP. If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
			}
			else{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse=" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Native ecomm is "+NatHybWIP.wipBean.getNativ_wip_count()
					+" Policies with "+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+" Cr. Adj MFYP.\n\n"
					+" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Hybrid ecomm is " +NatHybWIP.wipBean.getHybrd_wip_count()+" "
					+" Policies with "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+" Cr. Adj MFYP.";
				}
				else
				{
					finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
							" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
							+ " Cr. Adj MFYP. Do you wish to see the stage wise snapshot.";
				}
			}
		}
		else
		{
			finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
					" for MLI is "+convertsum4+" Policies with "+convertsum3+" "
					+ "Cr. Adj MFYP. Do you wish to see the stage wise snapshot.";
		}
		return finalresponse.toString();
	}
}
