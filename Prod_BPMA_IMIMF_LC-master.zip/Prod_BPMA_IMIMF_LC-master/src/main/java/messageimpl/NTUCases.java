package messageimpl;

import DataBean.NTUBean;

public class NTUCases 
{
	public static String ntuIntent(String channel, String period, String userzone, String user_region, 
			String user_circle, String subchannel, String user_clusters, String user_go, NTUBean ntu)
	{

		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			period=period.toUpperCase();
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}

		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies MTD for MLI is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "+ntu.getNtu_mtd_inforced_afyp()+" Cr."
					+ " If you want to see the channel wise business numbers, please specify";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(user_clusters))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies MTD for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "+ntu.getNtu_mtd_inforced_afyp()+" Cr."
						+ " If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
			}
			else{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies MTD for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "+ntu.getNtu_mtd_inforced_afyp()+" Cr.";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies Zone "+userzone+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "+ntu.getNtu_mtd_inforced_afyp()+" Cr.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+user_region+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "+ntu.getNtu_mtd_inforced_afyp()+" Cr.";
		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+user_clusters+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
					+ntu.getNtu_mtd_inforced_afyp()+" Cr.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+user_clusters+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
					+ntu.getNtu_mtd_inforced_afyp()+" Cr.";
		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+user_clusters+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
					+ntu.getNtu_mtd_inforced_afyp()+" Cr.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+user_region+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
					+ntu.getNtu_mtd_inforced_afyp()+" Cr.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}		}

		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}		
		}

		/*--------------------------------------Channel & GO------start----------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
		}
		/*--------------------------------------Channel & GO------end----------------------------------------------------------------------*/

		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
		}

		/*-----------------------------------------------------START*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for "+channel+" is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
		}
		/*-----------------------------------------------------END*/
		else
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for MLI is "+ntu.getNtu_mtd_inforced_count()+" with adj. MFYP "+ntu.getNtu_mtd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_mtd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" for MLI is "+ntu.getNtu_ytd_inforced_count()+" with adj. MFYP "+ntu.getNtu_ytd_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_ytd_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
			else
			{
				finalresponse= "As of "+ntu.getReal_tim_timstamp()+", the count of NTU policies "+period+" MLI for is "+ntu.getNtu_daily_inforced_count()+" with adj. MFYP "+ntu.getNtu_daily_adj_mfyp()+" Cr and AFYP "
						+ntu.getNtu_daily_inforced_afyp()+" Cr. If you want to see the channel wise business numbers, please specify";
			}
		}
		return finalresponse.toString();
	}
}
