package messageimpl;


public class HubHold 
{
	public static String hubHoldIntent(String channel, String period, String userzone, String user_region, 
			String real_tim_timstamp, String mtd_hub_hold_cases, String ytd_hub_hold_cases,
			String daily_hub_hold_cases, String mtd_hub_hold_adj_mfyp, String ytd_hub_hold_adj_mfyp,
			String daily_hub_hold_adj_mfyp, String total_hub_hold_cases, String total_hub_hold_adj_mfyp,
			String user_circle, String subchannel, String user_clusters, String user_go)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{user_region="Circle "+user_circle;}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{channel = subchannel;}
		
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for MLI is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 
			
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+channel+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 
					
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+userzone+" Zone is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 
			
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+user_region+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+user_clusters+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+user_clusters+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+user_clusters+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases for "+user_region+" is "+total_hub_hold_cases+" "
					+ "with adj. MFYP "+total_hub_hold_adj_mfyp+" cr."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			 && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr."; 
				
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
					+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr.";  
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		/*--------------------------------------Channel & GO------start----------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr.";  
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		/*--------------------------------------Channel & GO----------end------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		/*-----------------------------------------start----------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr."; 
			}
			else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		/*-------------------------------------------end--------------------------------------------------------------------------*/
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+ytd_hub_hold_cases+" "
						+ "with adj. MFYP "+ytd_hub_hold_adj_mfyp+" cr."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+mtd_hub_hold_cases+" "
						+ "with adj. MFYP "+mtd_hub_hold_adj_mfyp+" cr."; 
			}else
			{
				finalresponse= "As of "+real_tim_timstamp+" the total Hub hold cases "+period+" for "+channel+" is "+daily_hub_hold_cases+" "
						+ "with adj. MFYP "+daily_hub_hold_adj_mfyp+" cr."; 
			}
		}
		return finalresponse.toString();
		
	}

}
