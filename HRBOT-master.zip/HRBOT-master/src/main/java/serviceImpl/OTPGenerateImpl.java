package serviceImpl;

import java.io.BufferedReader;


import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;


import java.util.Random;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import hello.Facebook;
import hello.InnerButton;
import hello.InnerData;
import service.OTPGenerate;
import utils.XTrustProvider;

@Service
public class OTPGenerateImpl implements OTPGenerate {
	
//	private static Logger logger = LogManager.getLogger(OTPGenerateImpl.class);
	
	public static ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	
	public static Map<String, Map<String, String>> sessionMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> extraMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String,String> cacheRemove = new ConcurrentHashMap<String,String>();
	public  Map<String, Map<String,String>> kpilevel = new HashMap<String, Map<String,String>>();
	Map<String, String> innermap = new HashMap<String,String>();
	
	@Override
	public Map<String, Map<String, String>> OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId, String actionperformed) 
	{
		
//		logger.info("START :- Inside : - OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		
		HttpURLConnection conn = null;
		String output = new String();
		String DevMode = "N", status = "", randomotp = "";
		JSONObject object=null;
		StringBuilder result = new StringBuilder();
		Map<String, String> otpsession = new HashMap<String, String>();
		
		try {
			XTrustProvider trustProvider = new XTrustProvider();
			trustProvider.install();
			StringBuilder requestdata = new StringBuilder();
			
			String serviceurl = resProp.getString("servicesendotp");
			
			URL url = new URL(serviceurl);
			if (DevMode != null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode)) {
				Proxy proxy = new Proxy(Proxy.Type.HTTP,
						new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			} else {
				conn = (HttpURLConnection) url.openConnection();
			}
			UUID uniqueId2 = UUID.randomUUID();
			randomotp = randomNumber();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			requestdata.append("	{	");
			requestdata.append("	   \"MliSmsService\": {	");
			requestdata.append("	      \"requestHeader\": {	");
			requestdata.append("	         \"generalConsumerInformation\": {	");
			requestdata.append("	            \"messageVersion\": \"1.0\",	");
			requestdata.append("	            \"consumerId\": \"BPMA_BOT\",	");
			requestdata.append("	            \"correlationId\": \""+uniqueId2+"\"	");
			requestdata.append("	         }	");
			requestdata.append("	      },	");
			requestdata.append("	      \"requestBody\": {	");
			requestdata.append("	         \"appAccId\": \"PROMO_SOA\",	");
			requestdata.append("	         \"appAccPass\": \"y!7Ej@9C\",	");
			requestdata.append("	         \"appId\": \"MAXLIT\",	");
			requestdata.append("	         \"msgTo\": \"" + phoneno + "\",	");
			requestdata.append("	         \"msgText\": \"" + randomotp + "\"	");
			requestdata.append("	      }	");
			requestdata.append("	   }	");
			requestdata.append("	}	");
//			logger.info("OutputStream call : START ::: OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
			OutputStreamWriter writer3 = new OutputStreamWriter(conn.getOutputStream());
			writer3.write(requestdata.toString());
			writer3.flush();
			try {
				writer3.close();
			} catch (Exception e1)
			{}
//			logger.info("OutputStream call : END ::: OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
			int apiResponseCode3 = conn.getResponseCode();
//			logger.info("Response Code :- OTPVarification "+ apiResponseCode3+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
			if (apiResponseCode3 == 200) 
			{
				if(!"nb.validate".equalsIgnoreCase(actionperformed))
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
					object = new JSONObject(result.toString());
				}
				try {
					if(!"nb.validate".equalsIgnoreCase(actionperformed))
					{
						status = object.getJSONObject("MliSmsServiceResponse").getJSONObject("responseHeader")
								.getJSONObject("generalResponse").get("status") + "";

						Calendar cal = Calendar.getInstance();
						DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
						System.out.println(dateFormat.format(cal.getTime()));

						otpsession.put("Status", status);
						otpsession.put("AgentName", agentName);
						otpsession.put("otp", randomotp);
						otpsession.put("SoaStatus", "success");
						otpsession.put("validSSOID", ssoId);
						otpsession.put("channel", "MLI");
						otpsession.put("period", "MTD");
						otpsession.put("timeStamp", dateFormat.format(cal.getTime()));
						sessionMapcontainssoinfo.put(sessionId, otpsession);
					}
					else
					{
						otpsession.put("SoaStatus", "partial_content");
						otpsession.put("validSSOID", ssoId);
						otpsession.put("AgentName", agentName);
						sessionMapcontainssoinfo.put(sessionId, otpsession);
					}
				} catch (Exception e) 
				{
//					logger.info(e);
				}
//				logger.info("END : OutSide:- OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
			} else
			{
				otpsession.put("SoaStatus", "Failure_API_2");
				sessionMapcontainssoinfo.put(sessionId, otpsession);
//				logger.info("Exception Occoured while calling OTP Varification API Call");
			}
			
		} catch (Exception ex) 
		{
//			logger.info(ex);
			otpsession.put("SoaStatus", "Failure_API_2");
			sessionMapcontainssoinfo.put(sessionId, otpsession);
//			logger.info("Exception Occoured while calling OTP Varification API Call");
		}

		return sessionMapcontainssoinfo;
	}
	
	public static String randomNumber() {
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i < 6; i++) {
			bf = bf.append(getRandomNumberInRange(1, 9));
		}
		return bf.toString();
	}
	public static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

}
