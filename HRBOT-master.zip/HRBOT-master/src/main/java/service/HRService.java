package service;

import java.util.Map;

public interface HRService {
	public Map<String, Map<String, String>> APICallSSOValidation(String request);
}
