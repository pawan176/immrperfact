package service;

import java.util.Map;

public interface OTPGenerate {
	public Map<String, Map<String,String>>OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId,String actionperformed);

}
