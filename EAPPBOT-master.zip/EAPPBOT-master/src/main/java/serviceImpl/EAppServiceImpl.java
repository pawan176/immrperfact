package serviceImpl;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.qc.controller.MliBotController;
import service.EAppService;
import service.OTPGenerate;
//import com.qc.utils.XTrustProvider;
import utils.XTrustProvider;

@Service
public class EAppServiceImpl implements EAppService 
{
	@Autowired 
	OTPGenerate generate;
	

//	private static Logger logger = LogManager.getLogger(EAppServiceImpl.class);
	
	public static ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	
	public static Map<String, Map<String, String>> sessionMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> extraMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String,String> cacheRemove = new ConcurrentHashMap<String,String>();
	public  Map<String, Map<String,String>> kpilevel = new HashMap<String, Map<String,String>>();
	Map<String, String> innermap = new HashMap<String,String>();
	
	@Override
	public Map<String, Map<String, String>> APICallSSOValidation(String request)
	{
	        System.out.println("APISOOVALITION :: METHOD :: INSIDE");
//		logger.info("START :- Inside : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		
		String sessionId="", actionPerformed="";
		String phoneNo = "", agentName = "", DevMode = "N", mnylstatus = "",botlist="";

		HttpURLConnection conn = null;
		String output = new String();
		StringBuilder result = new StringBuilder();
		Map<String, Map<String, String>> cashData = null;
		Map<String, String> blankmessage = new HashMap<String, String>();
		
		try 
		{
//			MliBotController mliBotController = new MliBotController();
			JSONObject obj=new JSONObject(request);
			System.out.println("REQUEST ::"+request);
			String ssoId=obj.getJSONObject("result").get("resolvedQuery")+"";
			
			String[] sso=ssoId.split(" ");
			String mainSsoId=sso[0];
			
			sessionId=obj.getString("sessionId");
			actionPerformed=obj.getJSONObject("result").get("action")+"";
			System.out.println("ActionPerformed ::"+actionPerformed);
			XTrustProvider trustProvider = new XTrustProvider();
			trustProvider.install();
			StringBuilder requestdata = new StringBuilder();
			
			String serviceurl3 = resProp.getString("serviceprod");
			URL url3 = new URL(serviceurl3);
			if (DevMode != null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode)) {
				Proxy proxy = new Proxy(Proxy.Type.HTTP,
						new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url3.openConnection(proxy);
			} else {
				conn = (HttpURLConnection) url3.openConnection();
			}
			UUID uniqueId = UUID.randomUUID();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			requestdata.append("	{	");
			requestdata.append("	    \"request\": {	");
			requestdata.append("	        \"header\": {	");
			requestdata.append("	            \"soaCorrelationId\": \""+uniqueId+"\",	");
			requestdata.append("	            \"soaMsgVersion\": \"1.0\",	");
			requestdata.append("	            \"soaAppId\": \"MISBOT\",	");
			requestdata.append("	            \"soaUserId\": \"MISBOTPROD123\",	");
			requestdata.append("	            \"soaPassword\": \"cGFzd29yZDU=\"	");
			requestdata.append("	        },	");
			requestdata.append("	        \"requestData\": {	");
			requestdata.append("	            \"requestPayload\": {	");
			requestdata.append("	                \"transactions\": [	");
			requestdata.append("	                    {	");
			requestdata.append("	                        \"ssoId\": \"" + mainSsoId + "\"");
			requestdata.append("	                    }	");
			requestdata.append("	                ]	");
			requestdata.append("	            }	");
			requestdata.append("	        }	");
			requestdata.append("	    }	");
			requestdata.append("	}	");
//			logger.info("OutputStream call : START ::: APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
			OutputStreamWriter writer3 = new OutputStreamWriter(conn.getOutputStream());
			writer3.write(requestdata.toString());
			writer3.flush();
			try {
				writer3.close();
			} catch (Exception e1) {
			}
//			logger.info("OutputStream call : END ::: APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
			int apiResponseCode3 = conn.getResponseCode();
//			logger.info("Response Code :- "+ apiResponseCode3+ " SSOID:- "+ssoId+" SessionId :-"+sessionId );
			if (apiResponseCode3 == 200) 
			{
			       System.out.println("APIRESPONSE CODE :: 200");
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
				JSONObject object = new JSONObject(result.toString());
				try {
					
					
					phoneNo = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mnylpreferredmobile") + "";
//					logger.info("Phone No: - "+phoneNo+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
					mnylstatus = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mnylstatus") + "";
//					logger.info("Phone No: - "+mnylstatus+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
					agentName = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("givenname") + "";
//					logger.info("Phone No: - "+agentName+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
					
					System.out.println("Befor BOT LIST CODE :: START");
					botlist=object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("botlist") + "";
					System.out.println("Befor BOT LIST CODE :: END");
				
					String[] bot=botlist.split(",");
					
					System.out.println(botlist);
					String bot1=bot[0];
					String bot2=bot[1];
					String bot3=bot[2];
					
					if("nb.validate".equalsIgnoreCase(actionPerformed))
					{
					       System.out.println("NB.VALIDATE FOR OTP VARIFICATION :: START");
//						logger.info("START Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
						
						
						cashData = generate.OTPVarification(sessionId, phoneNo, agentName, mainSsoId, actionPerformed,bot1,bot2,bot3);
						System.out.println("NB.VALIDATE FOR OTP VARIFICATION :: END");
//						logger.info("END Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					}
					else if (phoneNo != null && !"".equalsIgnoreCase(phoneNo) && mnylstatus != null
							&& !"".equalsIgnoreCase(mnylstatus) && "Y".equalsIgnoreCase(mnylstatus))
					{
//						logger.info("START Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
						cashData = generate.OTPVarification(sessionId, phoneNo, agentName, mainSsoId, 
						actionPerformed,bot1,bot2,bot3);
//						logger.info("END Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);

					}
					else
					{
						blankmessage.put("PhoneStatus", phoneNo);
						blankmessage.put("mnylStatus",  mnylstatus);
						sessionMapcontainssoinfo.put(sessionId, blankmessage);
						cashData = sessionMapcontainssoinfo;
					}
				} catch (Exception e) {
//					logger.info(e);
				}
//				logger.info("External API Call : END ::: APICallSSOValidation");

			} else {
				blankmessage.put("SoaStatus", "Failure_API_1");
				sessionMapcontainssoinfo.put(sessionId, blankmessage);
				cashData = sessionMapcontainssoinfo;
			}
		} catch (Exception ex)
		{
//			logger.info(ex);
			blankmessage.put("SoaStatus", "Failure_API_1");
			sessionMapcontainssoinfo.put(sessionId, blankmessage);
			cashData = sessionMapcontainssoinfo;
		}
//		logger.info("END :- OutSide : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
                System.out.println("APISOOVALITION :: METHOD :: OUTSIDE");
		return cashData;
	}

}
