package service;

import java.util.Map;

public interface OTPGenerate {
	public Map<String, Map<String,String>>OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId,String actionperformed,String bot1,String bot2,String bot3);

}
