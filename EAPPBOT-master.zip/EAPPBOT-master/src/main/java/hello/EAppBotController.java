
package hello;


import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import utils.XTrustProvider;	
import java.net.URL;
import java.net.Proxy;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import javax.net.ssl.HttpsURLConnection;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import service.EAppService;

@Controller
@RequestMapping("/webhook")
public class EAppBotController{
	
	@Autowired 
	EAppService eAppService;
	
//	private static Logger logger = LogManager.getLogger(EAppBotController.class);
	public static Map<String, Map<String, String>> sessionMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> extraMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String,String> cacheRemove = new ConcurrentHashMap<String,String>();
	public  Map<String, Map<String,String>> kpilevel = new HashMap<String, Map<String,String>>();
	Map<String, String> innermap = new HashMap<String,String>();
	

	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody WebhookResponse webhook(@RequestBody String request, HttpSession httpSession) 
	{
		System.out.println("CAME Inside :: Webhook Controller");
		WebhookResponse response=new WebhookResponse();
		
		List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
		Facebook fb = new Facebook();
		InnerData innerData= new InnerData();
		InnerButton button=new InnerButton();
		InnerButton button2=new InnerButton();
		InnerButton button3=new InnerButton();
		
		
//		logger.info("CameInside :- Controller: Webhook");
//		logger.info("Skill :- Object Json from OutSide"+request.toString());
//		// ------------------------For Development Purpose
//		logger.info("Size of the CashHashMap:Internal Data Cash: " + sessionMap.size());
//		logger.info("Size of the CashHashMap: No.of User Enter: " + sessionMapcontainssoinfo.size());
//		logger.info("Size of the CashHashMap: No.of User Enter: " + extraMap.size());
		
		String productType = "" , planType = "", period = "", channel = "", sessionId = "", userOTP = "", speech = "";
		String cachePeriod = "",  cashplanType = "", cashchannel = "", cashproductType = "", ssoId = "", cashCircle = "";
		String cashRegion = "", cashZone = "", circle = "", region = "", zone = "", subChannel = "", cash_Sub_Channel = "";
		String source="",  nbvalidate_source = "", nbvalidateplatform="";
		
		try {
//			logger.info("EAppBotController :: STARTS ::");
			JSONObject object = new JSONObject(request);
			try
			{
				source = object.getJSONObject("originalRequest").get("source")+"";
			}catch(Exception ex)
			{
				source="";
			}
			String actionperformed = object.getJSONObject("result").get("action") + "";
			String resolvedQuery = object.getJSONObject("result").get("resolvedQuery") + "";
			sessionId = object.get("sessionId") + "";
			try {
				userOTP = object.getJSONObject("result").getJSONObject("parameters").get("otp") + "";
			} catch (Exception e) {
//				logger.info("Not getting OTP");
			}
			if ("SSO.Validation".equalsIgnoreCase(actionperformed) || "nb.validate".equalsIgnoreCase(actionperformed)) 
			{
//				logger.info("Inside SSO.Validation Method :START");
				ssoId = object.getJSONObject("result").get("resolvedQuery")+ "";
				System.out.println("After split");
				String[] sso=ssoId.split(" ");
				String mainSsoId=sso[0];
				try{
					nbvalidate_source = object.getJSONObject("result").getJSONObject("parameters").get("source")+"";
				}
				catch(Exception ex)
				{nbvalidate_source="";}
				try{
					nbvalidateplatform = object.getJSONObject("result").getJSONObject("parameters").get("platform")+"";
				}
				catch(Exception ex)
				{nbvalidateplatform="";}
				sessionId = object.get("sessionId") + "";
				Map otpsessionMap = sessionMapcontainssoinfo.get(sessionId);
				if (otpsessionMap == null) 
				{
					/*START---------This API Validate SSOID Via SOA API and get the info of the User------------------------------*/
//					logger.info("START Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					Map<String, Map<String, String>> returnmap = eAppService.APICallSSOValidation(request);
//					logger.info("END Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					/*END---------This API Validate SSOID Via SOA API and get the info of the User------------------------------*/
				
					String SoaStatus = "", mnylstatus = "", PhoneStatus = "", agentName ="",bot1="",bot2="",bot3="";

					Map<String, String> cashMap = returnmap.get(sessionId);
					SoaStatus = cashMap.get("SoaStatus");
//					logger.info("SOA STATUS :- "+SoaStatus);
					PhoneStatus = cashMap.get("PhoneStatus")+"";
//					logger.info("SOA STATUS :- "+PhoneStatus);
					mnylstatus = cashMap.get("mnylStatus")+"";
//					logger.info("SOA STATUS :- "+mnylstatus);
					agentName=cashMap.get("AgentName");
//					logger.info("SOA STATUS :- "+agentName);
					
					bot1=cashMap.get("MISBot");
					bot2=cashMap.get("HRBot");
					bot3=cashMap.get("RABot");
					
					if ("N".equalsIgnoreCase(mnylstatus))
					{
						speech = "This UserID Is InActive";
					} else if ("success".equalsIgnoreCase(SoaStatus)) 
					{
						speech = "I need to verify the OTP which was sent on your registered mobile number. Please enter it here "
								+ cashMap.get("otp") + "";
						
						sessionMapcontainssoinfo.put(sessionId, cashMap);
						
					} else if ("".equalsIgnoreCase(PhoneStatus) || PhoneStatus==null) {
						speech = "Your PhoneNo. is not registered with us! Please Enter a registered PhoneNo.";
					} else if ("Failure_API_1".equalsIgnoreCase(SoaStatus)|| "Failure_API_2".equalsIgnoreCase("SoaStatus")) 
					{
//						logger.info("Problem Occoured In Calling External API's SOA");
						speech = "There is some communication glitch ! Please try after some time !! ";
					}
					else if("partial_content".equalsIgnoreCase(SoaStatus))
					{
						speech = "Hi " + agentName + ", I can help you with following options";
						cashMap.put("Validation", "success");
						cashMap.put("nbvalidatesource", nbvalidate_source);
						cashMap.put("nbvalidateplatform", nbvalidateplatform);
						sessionMapcontainssoinfo.put(sessionId, cashMap);
						
						if(!bot1.equalsIgnoreCase("N"))
						{
							button.setText("Business Numbers");			// MISBot
							button.setPostback(bot1);
							innerbuttonlist.add(button);
						}
						
						if(!bot2.equalsIgnoreCase("N"))
						{
							button2.setText("HrPolicies");					// RABot
							button2.setPostback(bot2);
							innerbuttonlist.add(button2);
						}
						
						if(!bot3.equalsIgnoreCase("N"))
						{
							button3.setText("FLS");				// HRBot
							button3.setPostback(bot3);
							innerbuttonlist.add(button3);
						}
						
						
						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");
						
						innerData.setFacebook(fb);
					}
					else 
					{
						speech = "Oops! I could not find any registered mobile number for this SSO";
					}
				}
				 else 
					{
						if (otpsessionMap.get("validSSOID") != null	&& otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId)) 
						{
							speech = "Already validated";
						}
						if (!otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId))
						{
							speech = "You are trying to be login as different user. Please close earlier conversation to proceed";
						}
					}
				}
			

			else if ("nb.OTP.Validation".equalsIgnoreCase(actionperformed)) 
			{
//				logger.info("Action START :- nb.OTP.Validation");
				String AgentName = "", cashOTP = "";
				if (sessionMapcontainssoinfo.containsKey(sessionId)) 
				{
					Map<String, String> cashMap = sessionMapcontainssoinfo.get(sessionId);
					String validSSOID = cashMap.get("validSSOID");
					if (cashMap.containsKey(validSSOID + "_VERIFY")) 
					{
						speech = "Already validated!";
					} else {
						cashOTP = cashMap.get("otp");
						AgentName = cashMap.get("AgentName");
						if (cashOTP.equalsIgnoreCase(userOTP))
						{
							speech = "Hi " + AgentName + ", How can i help you today?";
							cashMap.put("Validation", "success");
							cashMap.put(validSSOID + "_VERIFY", cashOTP);
							sessionMapcontainssoinfo.put(sessionId, cashMap);
						} else {
							speech = "Invalid OTP Entered! "
									+ "The OTP you have provided does not match. Please provide valid OTP "
									+ "that has been sent to your registered mobile number.";
						}
					}
				} else {
					speech = "Please Validate SSO Credentials For Further Process";
				}
//				logger.info("Action END :- nb.OTP.Validation");
			}
			else if("close.clear".equalsIgnoreCase(actionperformed))
			{
				sessionMapcontainssoinfo.clear();
				extraMap.clear();
				sessionMap.clear();
				kpilevel.clear();
				innermap.clear();
				speech = "Data Cleared ! Thanks....";
			}
			
			else if ("close.conversation".equalsIgnoreCase(actionperformed)) 
			{
//				logger.info("Action START :- close.conversation");
				if (sessionMapcontainssoinfo.containsKey(sessionId))
				{
					sessionMapcontainssoinfo.remove(sessionId);
					try{
						extraMap.remove(sessionMap.get(sessionId).get("user_ssoid"));
					}
					catch(Exception ex)
					{
//						logger.info("Remove Extra Map");
					}
					sessionMap.remove(sessionId);
					kpilevel.remove(sessionId);
					innermap.remove("cachePeriod_"+sessionId);
					innermap.remove("cashplanType_"+sessionId);
					innermap.remove("cashCircle_"+sessionId);
					innermap.remove("cashRegion_"+sessionId);
					innermap.remove("cashZone_"+sessionId);
					innermap.remove("cash_Sub_Channel_"+sessionId);
					innermap.remove("cashproductType_"+sessionId);
					speech = "Thank you for contacting Max Life. Have a great day!";
//					logger.info("Action END :- close.conversation");
				}
				else {
					speech = "Thank you for contacting Max Life. Have a great day!";
				}
			} 
		} catch (Exception e) {
//			logger.info(e);
		}
		WebhookResponse response1=new WebhookResponse(speech, speech,innerData);
		
		return response1;
	}
}
