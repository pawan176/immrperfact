package service;
import hello.WebhookResponse; 
import java.text.DecimalFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import entity.DataBean;
import common.CallingJavaService;
import messageimpl.AdjMFYP;
import messageimpl.AppliedCases;
import messageimpl.AppliedFYP;
import messageimpl.Collection;
import messageimpl.ECSDatePolicy;
import messageimpl.FundValue;
import messageimpl.MedicalCategory;
import messageimpl.Mpersistency;
import messageimpl.NomineeDetails;
import messageimpl.Ntued;
import messageimpl.PaidCases;
import messageimpl.PolicyPack;
import messageimpl.PolicyStatus;
import messageimpl.PolicyStatusDobPan;
import messageimpl.PremiumDue;
import messageimpl.ReasonWelcomeCallStatus;
import messageimpl.RenewalPremium;
import messageimpl.RollingCollection;
import messageimpl.WIPCases;
import messageimpl.WelcomeCallingStatus;
import messageimpl.WtgMFYP;
import messageimpl.Help;

@Service
public class APIConsumerService 
{
	@Autowired private CallingJavaService callingJavaService;
	@Autowired private DataBean dataBean;
	@Autowired private AdjMFYP  adjMFYP;
	@Autowired private Collection collection;
	@Autowired private ECSDatePolicy eCSDatePolicy;
	@Autowired private FundValue fundValue;
	@Autowired private MedicalCategory medicalCategory;
	@Autowired private Mpersistency mpersistency;
	@Autowired private NomineeDetails nomineeDetails;
	@Autowired private Ntued ntued;
	@Autowired private PaidCases paidCases;
	@Autowired private PolicyPack policyPack;
	@Autowired private PolicyStatusDobPan policyStatusDobPan;
	@Autowired private PolicyStatus policyStatus;
	@Autowired private PremiumDue premiumDue;
	@Autowired private ReasonWelcomeCallStatus reasonWelcomeCallStatus;
	@Autowired private RenewalPremium renewalPremium;
	@Autowired private RollingCollection rollingCollection;
	@Autowired private WelcomeCallingStatus welcomeCallingStatus;
	@Autowired private WIPCases wIPCases;
	@Autowired private WtgMFYP wtgMFYP;
	@Autowired private AppliedCases appliedCases;
	@Autowired private AppliedFYP appliedFYP;
	@Autowired private Help help;
	
	private static Logger logger = LogManager.getLogger(APIConsumerService.class);
	public WebhookResponse getWipDataAll(String action, String channel, String period,String policyNumber,
			String user_ssoid, String user_sub_channel, String sessionId, String source, String raAdmAgtId, String customerName)
	{
		System.out.println("In Time::");
		String segment="";
		String segmentAction=action.toUpperCase();
		try{
		String [] modifyAction=action.split("FLS.");
		segment=modifyAction[1].toUpperCase();
		}catch(Exception ex)
		{
			segment="AdJMFYP";
		}
		String result = null;
		String finalresponse="";
		try{
			if("FLS.MPERSISTENCYUNPAID".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.MPERSISTENCYBASE".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.WIPYES".equalsIgnoreCase(segmentAction))
			{
				segment="WIPCASES";
			}
			else if(segment.equalsIgnoreCase("HELP"))
			{
				finalresponse=help.helpIntent();
			}
			if("".equalsIgnoreCase(finalresponse))
			{
				result = callingJavaService.callService(segment, user_ssoid, channel, user_sub_channel, raAdmAgtId, policyNumber);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occourd While calling java Service");
			finalresponse="Exception Occourd While calling java Service";
		}
		try
		{
			DecimalFormat df = new DecimalFormat("####0.00");
			DecimalFormat df1 = new DecimalFormat("####");
			JSONObject object = new JSONObject(result);
			String status="";
			String [] regex = segment.split(",");
			for(int i=0; i<regex.length; i++)
			{
				String split= regex[i];
				String splitIntent=split.toUpperCase();
				System.out.println("In Time:Bean SET:");
				status = dataBean.getDatafromJsonObject(splitIntent, object);
				System.out.println("Out Time:Bean SET:");
			}
			if("true".equalsIgnoreCase(status))
			{
				switch(segmentAction)
				{
				case "FLS.ADJMFYP":
				{
					finalresponse=adjMFYP.adjMFYPIntent();
				}
				break;
				case "FLS.PAIDCASES":
				{
					finalresponse=paidCases.paidCasesIntent();
				}
				break;
				case "FLS.WTGMFYP":
				{
					finalresponse=wtgMFYP.wtgMFYPIntent();
				}
				break;
				case "FLS.POLICYSTATUS":
				{
					finalresponse=policyStatus.policyStatusIntent(policyNumber, customerName);
				}
				break;
				case "FLS.POLICYSTATUSDOBPAN":
				{
					finalresponse=policyStatusDobPan.policyStatusDobPanIntent(customerName);
				}
				break;
				case "FLS.RENEWALPREMIUM":
				{
					finalresponse=renewalPremium.renewalPremiumIntent(policyNumber);
				}
				break;
				case "FLS.PREMIUMDUE":
				{
					System.out.println("In Time:FLS.PremiumDue:");
					finalresponse=premiumDue.premiumDueIntent();
					System.out.println("Out Time:FLS.PremiumDue:");
				}
				break;
				case "FLS.COLLECTION":
				{
					finalresponse=collection.collectionIntent();
				}
				break;

				case "FLS.ROLLINGCOLLECTION":
				{
					finalresponse=rollingCollection.rollingCollectionIntent();
				}
				break;
				case "FLS.NTUED":
				{
					finalresponse=ntued.ntuedIntent();
				}
				break;
				case "FLS.NOMINEEDETAILS":
				{
					System.out.println("NomineeDetails ::START");
					/*if(!"".equalsIgnoreCase(policyNumber) && policyNumber!=null)
					{
						finalresponse=nomineeDetails.nomineeDetailsIntent(policyNumber, object);
					}
					else
					{
						finalresponse="PolicyNo. required ! ";
					}*/
					finalresponse="This information is not available";
					System.out.println("NomineeDetails ::END");
				}
				break;
				case "FLS.POLICYPACK":
				{
					finalresponse=policyPack.policyPackIntent();
				}
				break;
				case "FLS.MEDICALCATEGORY":
				{
					if(!"".equalsIgnoreCase(policyNumber))
					{
						finalresponse=medicalCategory.medicalCategoryIntent(policyNumber);
					}else
					{
						finalresponse="PolicyNo. required ! ";
					}
				}
				break;
				case "FLS.FUNDVALUE":
				{
					finalresponse=fundValue.fundValueIntent(policyNumber);
				}
				break;
				case "FLS.ECSDATEPOLICY":
				{
					finalresponse=eCSDatePolicy.eCSDatePolicyIntent(policyNumber);
				}
				break;
				case "FLS.WELCOMECALLINGSTATUS":
				{
					finalresponse=welcomeCallingStatus.welcomeCallingStatusIntent();
				}
				break;
				case "FLS.REASONWELCOMECALLSTATUS":
				{
					finalresponse=reasonWelcomeCallStatus.reasonWelcomeCallStatusIntent();
				}
				break;
				case "FLS.MPERSISTENCY":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.MPERSISTENCYBASE":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.MPERSISTENCYUNPAID":
				{
					finalresponse=mpersistency.mPersistencyIntent(segmentAction);
				}
				break;
				case "FLS.WIPCASES":
				{
					String wipyes="";
					finalresponse=wIPCases.wipCasesIntent(object, wipyes);
				}
				break;
				case "FLS.WIPYES":
				{
					String wipyes = "WIPYES";
					finalresponse=wIPCases.wipCasesIntent(object, wipyes );
				}
				break;
						
				case "FLS.APPLIEDCASES":
				{
					finalresponse=appliedCases.appliedCasesIntent();
				}
				break;
				case "FLS.APPLIEDFYP":
				{
					finalresponse=appliedFYP.appliedFYPIntent();
				}
				break;
				default :
					finalresponse="Intent not matched with skill! Contact to concern team";
				}
			}
			else
			{
				finalresponse="There is some communication glitch! Please try after some time";
			}
		}
		catch(Exception e)
		{
			logger.info("Something went wrong in Bot Logic");
		}
		String speech=finalresponse;
		System.out.println("Final Response --:"+speech);
		WebhookResponse responseObj = new WebhookResponse(speech, speech);
		return responseObj;
	}
	public String convertToCamelCase(String channel)
	{
		final String ACTIONABLE_DELIMITERS = " '-/"; // these cause the character following
		// to be capitalized

		StringBuilder sb = new StringBuilder();
		boolean capNext = true;

		for (char c : channel.toCharArray()) {
			c = (capNext)
					? Character.toUpperCase(c)
							: Character.toLowerCase(c);
					sb.append(c);
					capNext = (ACTIONABLE_DELIMITERS.indexOf((int) c) >= 0); // explicit cast not needed

		}
		return sb.toString();
	}
}
