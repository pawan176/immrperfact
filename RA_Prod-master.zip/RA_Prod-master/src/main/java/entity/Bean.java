package entity;

import org.springframework.stereotype.Service;

@Service
public class Bean 
{
	private	String	channel;
	private	String	sub_channel;
	private	String	ra_adm_agt_id;
	private	String	adj_mfyp_ftd;
	private	String	adj_mfyp_mtd;
	private	String	adj_mfyp_qtd;
	private	String	adj_mfyp_ytd;
	private	String	inforced_ftd;
	private	String	inforced_mtd;
	private	String	inforced_qtd;
	private	String	inforced_ytd;
	private	String	wtg_mfyp_mtd;
	private	String	wtg_mfyp_qtd;
	private	String	wtg_mfyp_ytd;
	private	String	policy_number;
	private	String	pol_due_date;
	private	String	pol_owner_dob;
	private	String	pol_owner_pan;
	private	String	policy_status_desc;
	private	String	pol_renewal_prm;
	private	String	due_policy_count;
	private	String	due_policy_mfyp;
	private	String	total_collection_amt;
	private	String	total_collection_mfyp;
	private	String	rolling_collection_12mth;
	private	String	rolling_mfyp_12mth;
	private	String	ntu_policy_count;
	private	String	ntu_policy_afyp;
	private	String	nominee_name;
	private	String	nominee_dob;
	private	String	nominee_relationship;
	private	String	nominee_share;
	private	String	pol_pack_delvry_dt;
	private	String	pol_med_category;
	private	String	pol_fund_value;
	private	String	total_base_13m_pers;
	private	String	unpaid_base_13m_pers;
	private	String	achievement_13m_pers;
	private	String	wip_count;
	private	String	wip_mfyp;
	private	String	wip_afyp;
	private	String	wip_adj_mfyp;
	private	String	wip_stage;
	private	String	pol_welcom_call_status;
	private	String	pol_welcom_call_region;
	private	String	policy_ecs_dt;
	private String  applied_total_afyp_ftd;
	private String  applied_total_afyp_mtd;
	private String  applied_total_afyp_qtd;
	private String  applied_total_afyp_ytd;
	private String  applied_count_ftd;
	private String  applied_count_mtd;
	private String  applied_count_qtd;
	private String  applied_count_ytd;
	private String  BTCH_TIMSTAMP;
	private String  REAL_TIM_TIMSTAMP;
	
	public Bean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getRa_adm_agt_id() {
		return ra_adm_agt_id;
	}

	public void setRa_adm_agt_id(String ra_adm_agt_id) {
		this.ra_adm_agt_id = ra_adm_agt_id;
	}

	public String getAdj_mfyp_ftd() {
		return adj_mfyp_ftd;
	}

	public void setAdj_mfyp_ftd(String adj_mfyp_ftd) {
		this.adj_mfyp_ftd = adj_mfyp_ftd;
	}

	public String getAdj_mfyp_mtd() {
		return adj_mfyp_mtd;
	}

	public void setAdj_mfyp_mtd(String adj_mfyp_mtd) {
		this.adj_mfyp_mtd = adj_mfyp_mtd;
	}

	public String getAdj_mfyp_qtd() {
		return adj_mfyp_qtd;
	}

	public void setAdj_mfyp_qtd(String adj_mfyp_qtd) {
		this.adj_mfyp_qtd = adj_mfyp_qtd;
	}

	public String getAdj_mfyp_ytd() {
		return adj_mfyp_ytd;
	}

	public void setAdj_mfyp_ytd(String adj_mfyp_ytd) {
		this.adj_mfyp_ytd = adj_mfyp_ytd;
	}

	public String getInforced_ftd() {
		return inforced_ftd;
	}

	public void setInforced_ftd(String inforced_ftd) {
		this.inforced_ftd = inforced_ftd;
	}

	public String getInforced_mtd() {
		return inforced_mtd;
	}

	public void setInforced_mtd(String inforced_mtd) {
		this.inforced_mtd = inforced_mtd;
	}

	public String getInforced_qtd() {
		return inforced_qtd;
	}

	public void setInforced_qtd(String inforced_qtd) {
		this.inforced_qtd = inforced_qtd;
	}

	public String getInforced_ytd() {
		return inforced_ytd;
	}

	public void setInforced_ytd(String inforced_ytd) {
		this.inforced_ytd = inforced_ytd;
	}

	public String getWtg_mfyp_mtd() {
		return wtg_mfyp_mtd;
	}

	public void setWtg_mfyp_mtd(String wtg_mfyp_mtd) {
		this.wtg_mfyp_mtd = wtg_mfyp_mtd;
	}

	public String getWtg_mfyp_qtd() {
		return wtg_mfyp_qtd;
	}

	public void setWtg_mfyp_qtd(String wtg_mfyp_qtd) {
		this.wtg_mfyp_qtd = wtg_mfyp_qtd;
	}

	public String getWtg_mfyp_ytd() {
		return wtg_mfyp_ytd;
	}

	public void setWtg_mfyp_ytd(String wtg_mfyp_ytd) {
		this.wtg_mfyp_ytd = wtg_mfyp_ytd;
	}

	public String getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}

	public String getPol_due_date() {
		return pol_due_date;
	}

	public void setPol_due_date(String pol_due_date) {
		this.pol_due_date = pol_due_date;
	}

	public String getPol_owner_dob() {
		return pol_owner_dob;
	}

	public void setPol_owner_dob(String pol_owner_dob) {
		this.pol_owner_dob = pol_owner_dob;
	}

	public String getPol_owner_pan() {
		return pol_owner_pan;
	}

	public void setPol_owner_pan(String pol_owner_pan) {
		this.pol_owner_pan = pol_owner_pan;
	}

	public String getPolicy_status_desc() {
		return policy_status_desc;
	}

	public void setPolicy_status_desc(String policy_status_desc) {
		this.policy_status_desc = policy_status_desc;
	}

	public String getPol_renewal_prm() {
		return pol_renewal_prm;
	}

	public void setPol_renewal_prm(String pol_renewal_prm) {
		this.pol_renewal_prm = pol_renewal_prm;
	}

	public String getDue_policy_count() {
		return due_policy_count;
	}

	public void setDue_policy_count(String due_policy_count) {
		this.due_policy_count = due_policy_count;
	}

	public String getDue_policy_mfyp() {
		return due_policy_mfyp;
	}

	public void setDue_policy_mfyp(String due_policy_mfyp) {
		this.due_policy_mfyp = due_policy_mfyp;
	}

	public String getTotal_collection_amt() {
		return total_collection_amt;
	}

	public void setTotal_collection_amt(String total_collection_amt) {
		this.total_collection_amt = total_collection_amt;
	}

	public String getTotal_collection_mfyp() {
		return total_collection_mfyp;
	}

	public void setTotal_collection_mfyp(String total_collection_mfyp) {
		this.total_collection_mfyp = total_collection_mfyp;
	}

	public String getRolling_collection_12mth() {
		return rolling_collection_12mth;
	}

	public void setRolling_collection_12mth(String rolling_collection_12mth) {
		this.rolling_collection_12mth = rolling_collection_12mth;
	}

	public String getRolling_mfyp_12mth() {
		return rolling_mfyp_12mth;
	}

	public void setRolling_mfyp_12mth(String rolling_mfyp_12mth) {
		this.rolling_mfyp_12mth = rolling_mfyp_12mth;
	}

	public String getNtu_policy_count() {
		return ntu_policy_count;
	}

	public void setNtu_policy_count(String ntu_policy_count) {
		this.ntu_policy_count = ntu_policy_count;
	}

	public String getNtu_policy_afyp() {
		return ntu_policy_afyp;
	}

	public void setNtu_policy_afyp(String ntu_policy_afyp) {
		this.ntu_policy_afyp = ntu_policy_afyp;
	}

	public String getNominee_name() {
		return nominee_name;
	}

	public void setNominee_name(String nominee_name) {
		this.nominee_name = nominee_name;
	}

	public String getNominee_dob() {
		return nominee_dob;
	}

	public void setNominee_dob(String nominee_dob) {
		this.nominee_dob = nominee_dob;
	}

	public String getNominee_relationship() {
		return nominee_relationship;
	}

	public void setNominee_relationship(String nominee_relationship) {
		this.nominee_relationship = nominee_relationship;
	}

	public String getNominee_share() {
		return nominee_share;
	}

	public void setNominee_share(String nominee_share) {
		this.nominee_share = nominee_share;
	}

	public String getPol_pack_delvry_dt() {
		return pol_pack_delvry_dt;
	}

	public void setPol_pack_delvry_dt(String pol_pack_delvry_dt) {
		this.pol_pack_delvry_dt = pol_pack_delvry_dt;
	}

	public String getPol_med_category() {
		return pol_med_category;
	}

	public void setPol_med_category(String pol_med_category) {
		this.pol_med_category = pol_med_category;
	}

	public String getPol_fund_value() {
		return pol_fund_value;
	}

	public void setPol_fund_value(String pol_fund_value) {
		this.pol_fund_value = pol_fund_value;
	}

	public String getTotal_base_13m_pers() {
		return total_base_13m_pers;
	}

	public void setTotal_base_13m_pers(String total_base_13m_pers) {
		this.total_base_13m_pers = total_base_13m_pers;
	}

	public String getUnpaid_base_13m_pers() {
		return unpaid_base_13m_pers;
	}

	public void setUnpaid_base_13m_pers(String unpaid_base_13m_pers) {
		this.unpaid_base_13m_pers = unpaid_base_13m_pers;
	}

	public String getAchievement_13m_pers() {
		return achievement_13m_pers;
	}

	public void setAchievement_13m_pers(String achievement_13m_pers) {
		this.achievement_13m_pers = achievement_13m_pers;
	}

	public String getWip_count() {
		return wip_count;
	}

	public void setWip_count(String wip_count) {
		this.wip_count = wip_count;
	}

	public String getWip_mfyp() {
		return wip_mfyp;
	}

	public void setWip_mfyp(String wip_mfyp) {
		this.wip_mfyp = wip_mfyp;
	}

	public String getWip_afyp() {
		return wip_afyp;
	}

	public void setWip_afyp(String wip_afyp) {
		this.wip_afyp = wip_afyp;
	}

	public String getWip_adj_mfyp() {
		return wip_adj_mfyp;
	}

	public void setWip_adj_mfyp(String wip_adj_mfyp) {
		this.wip_adj_mfyp = wip_adj_mfyp;
	}

	public String getWip_stage() {
		return wip_stage;
	}

	public void setWip_stage(String wip_stage) {
		this.wip_stage = wip_stage;
	}

	public String getPol_welcom_call_status() {
		return pol_welcom_call_status;
	}

	public void setPol_welcom_call_status(String pol_welcom_call_status) {
		this.pol_welcom_call_status = pol_welcom_call_status;
	}

	public String getPol_welcom_call_region() {
		return pol_welcom_call_region;
	}

	public void setPol_welcom_call_region(String pol_welcom_call_region) {
		this.pol_welcom_call_region = pol_welcom_call_region;
	}

	public String getPolicy_ecs_dt() {
		return policy_ecs_dt;
	}

	public void setPolicy_ecs_dt(String policy_ecs_dt) {
		this.policy_ecs_dt = policy_ecs_dt;
	}

	public String getApplied_total_afyp_ftd() {
		return applied_total_afyp_ftd;
	}

	public void setApplied_total_afyp_ftd(String applied_total_afyp_ftd) {
		this.applied_total_afyp_ftd = applied_total_afyp_ftd;
	}

	public String getApplied_total_afyp_mtd() {
		return applied_total_afyp_mtd;
	}

	public void setApplied_total_afyp_mtd(String applied_total_afyp_mtd) {
		this.applied_total_afyp_mtd = applied_total_afyp_mtd;
	}

	public String getApplied_total_afyp_qtd() {
		return applied_total_afyp_qtd;
	}

	public void setApplied_total_afyp_qtd(String applied_total_afyp_qtd) {
		this.applied_total_afyp_qtd = applied_total_afyp_qtd;
	}

	public String getApplied_total_afyp_ytd() {
		return applied_total_afyp_ytd;
	}

	public void setApplied_total_afyp_ytd(String applied_total_afyp_ytd) {
		this.applied_total_afyp_ytd = applied_total_afyp_ytd;
	}

	public String getApplied_count_ftd() {
		return applied_count_ftd;
	}

	public void setApplied_count_ftd(String applied_count_ftd) {
		this.applied_count_ftd = applied_count_ftd;
	}

	public String getApplied_count_mtd() {
		return applied_count_mtd;
	}

	public void setApplied_count_mtd(String applied_count_mtd) {
		this.applied_count_mtd = applied_count_mtd;
	}

	public String getApplied_count_qtd() {
		return applied_count_qtd;
	}

	public void setApplied_count_qtd(String applied_count_qtd) {
		this.applied_count_qtd = applied_count_qtd;
	}

	public String getApplied_count_ytd() {
		return applied_count_ytd;
	}

	public void setApplied_count_ytd(String applied_count_ytd) {
		this.applied_count_ytd = applied_count_ytd;
	}

	public String getBTCH_TIMSTAMP() {
		return BTCH_TIMSTAMP;
	}

	public void setBTCH_TIMSTAMP(String bTCH_TIMSTAMP) {
		BTCH_TIMSTAMP = bTCH_TIMSTAMP;
	}

	public String getREAL_TIM_TIMSTAMP() {
		return REAL_TIM_TIMSTAMP;
	}

	public void setREAL_TIM_TIMSTAMP(String rEAL_TIM_TIMSTAMP) {
		REAL_TIM_TIMSTAMP = rEAL_TIM_TIMSTAMP;
	}

	@Override
	public String toString() {
		return "Bean [channel=" + channel + ", sub_channel=" + sub_channel + ", ra_adm_agt_id=" + ra_adm_agt_id
				+ ", adj_mfyp_ftd=" + adj_mfyp_ftd + ", adj_mfyp_mtd=" + adj_mfyp_mtd + ", adj_mfyp_qtd=" + adj_mfyp_qtd
				+ ", adj_mfyp_ytd=" + adj_mfyp_ytd + ", inforced_ftd=" + inforced_ftd + ", inforced_mtd=" + inforced_mtd
				+ ", inforced_qtd=" + inforced_qtd + ", inforced_ytd=" + inforced_ytd + ", wtg_mfyp_mtd=" + wtg_mfyp_mtd
				+ ", wtg_mfyp_qtd=" + wtg_mfyp_qtd + ", wtg_mfyp_ytd=" + wtg_mfyp_ytd + ", policy_number="
				+ policy_number + ", pol_due_date=" + pol_due_date + ", pol_owner_dob=" + pol_owner_dob
				+ ", pol_owner_pan=" + pol_owner_pan + ", policy_status_desc=" + policy_status_desc
				+ ", pol_renewal_prm=" + pol_renewal_prm + ", due_policy_count=" + due_policy_count
				+ ", due_policy_mfyp=" + due_policy_mfyp + ", total_collection_amt=" + total_collection_amt
				+ ", total_collection_mfyp=" + total_collection_mfyp + ", rolling_collection_12mth="
				+ rolling_collection_12mth + ", rolling_mfyp_12mth=" + rolling_mfyp_12mth + ", ntu_policy_count="
				+ ntu_policy_count + ", ntu_policy_afyp=" + ntu_policy_afyp + ", nominee_name=" + nominee_name
				+ ", nominee_dob=" + nominee_dob + ", nominee_relationship=" + nominee_relationship + ", nominee_share="
				+ nominee_share + ", pol_pack_delvry_dt=" + pol_pack_delvry_dt + ", pol_med_category="
				+ pol_med_category + ", pol_fund_value=" + pol_fund_value + ", total_base_13m_pers="
				+ total_base_13m_pers + ", unpaid_base_13m_pers=" + unpaid_base_13m_pers + ", achievement_13m_pers="
				+ achievement_13m_pers + ", wip_count=" + wip_count + ", wip_mfyp=" + wip_mfyp + ", wip_afyp="
				+ wip_afyp + ", wip_adj_mfyp=" + wip_adj_mfyp + ", wip_stage=" + wip_stage + ", pol_welcom_call_status="
				+ pol_welcom_call_status + ", pol_welcom_call_region=" + pol_welcom_call_region + ", policy_ecs_dt="
				+ policy_ecs_dt + ", applied_total_afyp_ftd=" + applied_total_afyp_ftd + ", applied_total_afyp_mtd="
				+ applied_total_afyp_mtd + ", applied_total_afyp_qtd=" + applied_total_afyp_qtd
				+ ", applied_total_afyp_ytd=" + applied_total_afyp_ytd + ", applied_count_ftd=" + applied_count_ftd
				+ ", applied_count_mtd=" + applied_count_mtd + ", applied_count_qtd=" + applied_count_qtd
				+ ", applied_count_ytd=" + applied_count_ytd + ", BTCH_TIMSTAMP=" + BTCH_TIMSTAMP
				+ ", REAL_TIM_TIMSTAMP=" + REAL_TIM_TIMSTAMP + "]";
	}
}
