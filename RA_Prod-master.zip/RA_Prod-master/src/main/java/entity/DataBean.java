package entity;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class DataBean 
{
	@Autowired
	private Bean bean;
	
	public String getDatafromJsonObject(String splitIntent, JSONObject object)
	{
		String finalresponse="true";
		switch(splitIntent)
		{
		case "ADJMFYP":
		{
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("adjMFYP").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_ftd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setAdj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_qtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "PAIDCASES":
		{
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("paidcase").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("paidcase").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("paidcase").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_ftd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setInforced_mtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_qtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_ytd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WTGMFYP":
		{
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWtg_mfyp_mtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_MTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setWtg_mfyp_qtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWtg_mfyp_ytd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYSTATUS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatus").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatus").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatus").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatus").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatus").get("policy_STATUS_DESC")+"");
			}
			catch(Exception ex)	{}
			try	{
				bean.setPol_due_date(object.getJSONObject("payload").getJSONObject("policyStatus").get("pol_DUE_DATE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYSTATUSDOBPAN":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_owner_dob(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_DOB").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPol_owner_pan(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_PAN").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_STATUS_DESC").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "RENEWALPREMIUM":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("renewalPremium").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("renewalPremium").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_renewal_prm(object.getJSONObject("payload").getJSONObject("renewalPremium").get("pol_RENEWAL_PRM").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "PREMIUMDUE":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("premiumDue").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("premiumDue").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("premiumDue").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setDue_policy_count(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setDue_policy_mfyp(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "COLLECTION":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("collection").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("collection").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("collection").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setTotal_collection_amt(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_AMT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setTotal_collection_mfyp(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "ROLLINGCOLLECTION":
		{   
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("rollingCollection").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRolling_collection_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_COLLECTION_12MTH").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setRolling_mfyp_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_MFYP_12MTH").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "NTUED":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ntued").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ntued").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ntued").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNtu_policy_count(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setNtu_policy_afyp(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_AFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "NOMINEEDETAILS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setNominee_name(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_NAME")+"");
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_dob(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_DOB").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_relationship(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_RELATIONSHIP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_share(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_SHARE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYPACK":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyPack").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyPack").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyPack").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyPack").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_pack_delvry_dt(object.getJSONObject("payload").getJSONObject("policyPack").get("pol_PACK_DELVRY_DT").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "MEDICALCATEGORY":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("medicalCategory").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("medicalCategory").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_med_category(object.getJSONObject("payload").getJSONObject("medicalCategory").get("pol_MED_CATEGORY").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "FUNDVALUE":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("fundValue").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("fundValue").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("fundValue").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("fundValue").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_fund_value(object.getJSONObject("payload").getJSONObject("fundValue").get("pol_FUND_VALUE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "ECSDATEPOLICY":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ecsdate").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ecsdate").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ecsdate").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPolicy_ecs_dt(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_ECS_DT").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WELCOMECALLINGSTATUS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_welcom_call_status(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("pol_WELCOM_CALL_STATUS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "REASONWELCOMECALLSTATUS":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_welcom_call_region(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("pol_WELCOM_CALL_REGION").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "MPERSISTENCY":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("mpersistency").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("mpersistency").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("mpersistency").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setTotal_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("total_BASE_13M_PERS").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setUnpaid_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("unpaid_BASE_13M_PERS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAchievement_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("achievement_13M_PERS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WIPCASES":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("wipCases").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wipCases").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wipCases").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_count(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setWip_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_afyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_AFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_adj_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_ADJ_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_stage(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_STAGE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "APPLIEDCASES":
		case "APPLIEDFYP":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("appliedCases").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("appliedCases").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("appliedCases").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setApplied_total_afyp_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_FTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		default :
			finalresponse="No Action Matched";
		}
		return finalresponse;
	}
}

