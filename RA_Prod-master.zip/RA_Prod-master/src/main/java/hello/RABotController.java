package hello;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.stereotype.Controller;
import service.APIConsumerService;
import common.HttpUrlConnectionMlabInsert;
import common.OTPGeneration;
import common.SSOJavaValidation;
import common.SSOValidation;
import common.Adoptionlogs;
import common.CalculateTimeDiff;

@Controller
@RequestMapping("/webhook")
public class RABotController{

	private static Logger logger = LogManager.getLogger(RABotController.class);
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();
	
	@Autowired
	private APIConsumerService aPIConsumerService;
	@Autowired
	private SSOValidation ssoValidation;
	@Autowired
	private OTPGeneration otpGeneration;
	@Autowired
	private SSOJavaValidation ssoJavaValidation;
	@Autowired
	private HttpUrlConnectionMlabInsert httpUrlConnectionMlabInsert;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private CalculateTimeDiff calculateTimeDiff;

	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody WebhookResponse webhook(@RequestBody String obj, Model model, HttpSession httpSession) 
	{
		System.out.println("CameInside :- Controller: Webhook");
		/*System.out.println("Skill :- Object Json from OutSide"+obj.toString());*/
		System.out.println("Size of the HashMap for RA --" + sessionMapcontainssoinfo.size());
		String period = "", sessionId = "", userOTP = "", speech = "";
		String ssoId = "";
		String source="",  nbvalidate_source = "", nbvalidateplatform="";
		String AgentName = "";
		String rachannel="";
		String raSubChannel="";
		String raADMAGTID="";
		String resolvedQuery="";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		try {
			System.out.println("RABOTController :: STARTS ::");
			JSONObject object = new JSONObject(obj);
			try
			{
				source = object.getJSONObject("originalRequest").get("source")+"";
			}catch(Exception ex)
			{
				source="";
			}
			String actionperformed = object.getJSONObject("result").get("action")+"";
			try{
				resolvedQuery = object.getJSONObject("result").get("resolvedQuery") + "";
			}catch(Exception ex)
			{
				resolvedQuery="unable to fetch resolvedQuery!";
			}
			sessionId = object.get("sessionId") + "";
			try {
				userOTP = object.getJSONObject("result").getJSONObject("parameters").get("number") + "";
			} catch (Exception e) {
				logger.info("Not getting OTP");
			}
			if ("SSO.Validation".equalsIgnoreCase(actionperformed) || "nb.validate".equalsIgnoreCase(actionperformed)
					|| "nb.integrate".equalsIgnoreCase(actionperformed)) 
			{
				logger.info("Inside SSO.Validation Method :START");
				try{
					ssoId = object.getJSONObject("result").getJSONObject("parameters").get("SSOID")+ "";
				}catch(Exception ex)
				{
					ssoId="";
				}
				if("nb.integrate".equalsIgnoreCase(actionperformed))
				{
					String resolvedQuery2 = object.getJSONObject("result").get("resolvedQuery") + "";
					String [] part = resolvedQuery2.split(" ");
					String part2=part[1];
					ssoId=part2;
					System.out.println("Nb.Integrate--"+ssoId);
				}
				try{
					nbvalidate_source = object.getJSONObject("result").getJSONObject("parameters").get("source")+"";
				}
				catch(Exception ex)
				{nbvalidate_source="";}
				try{
					nbvalidateplatform = object.getJSONObject("result").getJSONObject("parameters").get("platform")+"";
				}
				catch(Exception ex)
				{nbvalidateplatform="";}
				sessionId = object.get("sessionId") + "";
				Map otpsessionMap = sessionMapcontainssoinfo.get(sessionId);
				if (otpsessionMap == null) 
				{
					logger.info("START Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					Map<String, Map<String, String>> returnmap = APICallSSOValidation(ssoId,sessionId, actionperformed);
					logger.info("END Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);

					String SoaStatus = "", mnylstatus = "", PhoneStatus = "", agentName ="", IntegrateStatus="",
					firstValidationStatusapi="";
					
					Map<String, String> cashMap = returnmap.get(sessionId);
					firstValidationStatusapi = cashMap.get("firstValidationStatusapi");
					IntegrateStatus = cashMap.get("Validation");
					SoaStatus = cashMap.get("SoaStatus");
					logger.info("SOA STATUS :- "+SoaStatus);
					PhoneStatus = cashMap.get("PhoneStatus")+"";
					logger.info("SOA STATUS :- "+PhoneStatus);
					mnylstatus = cashMap.get("mnylStatus")+"";
					logger.info("SOA STATUS :- "+mnylstatus);
					agentName=cashMap.get("AgentName");
					logger.info("SOA STATUS :- "+agentName);
					if("N".equalsIgnoreCase(firstValidationStatusapi))
					{
						speech=" This UserID Is In Active";
					}
					else if("Success".equalsIgnoreCase(IntegrateStatus))
					{
						speech="How can i help you with business KPI's."+"\n"
								+ "Please select Help in case you need detailed information regarding KPIs or keywords "
								+ "you can ask from the bot.";
						String serviceResponse=ssoJavaValidation.getSSOInfo(ssoId);
						try{
							object = new JSONObject(serviceResponse);
						}
						catch(Exception ex)
						{
							speech = "You are not Authorized with us. Thank you for contacting Max Life. Have a great day!";
						}
						rachannel = object.getJSONObject("payload").getJSONObject("ssovalidation").get("channel") +"";
						raSubChannel = object.getJSONObject("payload").getJSONObject("ssovalidation").get("sub_CHANNEL") +"";
						raADMAGTID = object.getJSONObject("payload").getJSONObject("ssovalidation").get("ra_ADM_AGT_ID") +"";
						cashMap.put("loginTime", dtf.format(now));
						cashMap.put("raChannel"+sessionId, rachannel);
						cashMap.put("raSubChannel"+sessionId, raSubChannel);
						cashMap.put("raADMAGTID"+sessionId, raADMAGTID);
						sessionMapcontainssoinfo.put(sessionId, cashMap);
					}
					else if ("N".equalsIgnoreCase(mnylstatus))
					{
						speech = "This UserID Is InActive";
					} else if ("success".equalsIgnoreCase(SoaStatus)) 
					{
						speech = "I need to verify the OTP which was sent on your registered mobile number. Please enter it here "
								+ cashMap.get("otp") + "";
						System.out.println(speech);
					} else if ("".equalsIgnoreCase(PhoneStatus) || PhoneStatus==null) {
						speech = "Your PhoneNo. is not registered with us! Please Enter a registered PhoneNo.";
					} else if ("Failure_API".equalsIgnoreCase(SoaStatus)) 
					{
						logger.info("Problem Occoured In Calling External API's SOA");
						speech = "There is some communication glitch ! Please try after some time ";
					}
					else if("partial_content".equalsIgnoreCase(SoaStatus))
					{
						speech = "Hi " + agentName + ", How can i help you today?";
						cashMap.put("Validation", "success");
						cashMap.put("nbvalidatesource", nbvalidate_source);
						cashMap.put("nbvalidateplatform", nbvalidateplatform);
						sessionMapcontainssoinfo.put(sessionId, cashMap);
					}
					else 
					{
						speech = "Oops! I could not find any registered mobile number for this SSO";
					}
				} else 
				{
					if (otpsessionMap.get("validSSOID") != null	&& otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId)) 
					{
						speech = "Already validated";
					}
					if (!otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId))
					{
						speech = "You are trying to be login as different user. Please close earlier conversation to proceed";
					}
				}
			} 
				else if ("nb.OTP.Validation".equalsIgnoreCase(actionperformed)) 
			{
				logger.info("Action START :- nb.OTP.Validation");
				String cashOTP = "";
				if (sessionMapcontainssoinfo.containsKey(sessionId)) 
				{
					Map<String, String> cashMap = sessionMapcontainssoinfo.get(sessionId);
					String validSSOID = cashMap.get("validSSOID");
					if (cashMap.containsKey(validSSOID + "_VERIFY")) 
					{
						speech = "Already validated!";
					} else {
						cashOTP = cashMap.get("otp");
						AgentName = cashMap.get("AgentName");
						if (cashOTP.equalsIgnoreCase(userOTP))
						{
							speech = "Hi " + AgentName + ", How can i help you today?";
							cashMap.put("Validation", "success");
							cashMap.put(validSSOID + "_VERIFY", cashOTP);
							String serviceResponse=ssoJavaValidation.getSSOInfo(validSSOID);
							try{
								object = new JSONObject(serviceResponse);
							}
							catch(Exception ex)
							{
								speech = "You are not Authorized with us. Thank you for contacting Max Life. Have a great day!";
							}
							rachannel = object.getJSONObject("payload").getJSONObject("ssovalidation").get("channel") +"";
							raSubChannel = object.getJSONObject("payload").getJSONObject("ssovalidation").get("sub_CHANNEL") +"";
							raADMAGTID = object.getJSONObject("payload").getJSONObject("ssovalidation").get("ra_ADM_AGT_ID") +"";
							cashMap.put("loginTime", dtf.format(now));
							cashMap.put("raChannel"+sessionId, rachannel);
							cashMap.put("raSubChannel"+sessionId, raSubChannel);
							cashMap.put("raADMAGTID"+sessionId, raADMAGTID);
							sessionMapcontainssoinfo.put(sessionId, cashMap);
						} else {
							speech = "Invalid OTP Entered! "
									+ "The OTP you have provided does not match. Please provide valid OTP "
									+ "that has been sent to your registered mobile number.";
						}
					}
				} else {
					speech = "Please Validate SSO Credentials For Further Process";
				}
				logger.info("Action END :- nb.OTP.Validation");
			}
			else if ("close.conversation".equalsIgnoreCase(actionperformed)) 
			{
				logger.info("Action START :- close.conversation");
				if (sessionMapcontainssoinfo.containsKey(sessionId))
				{
					sessionMapcontainssoinfo.remove(sessionId);
					for(Map.Entry<String, Map<String, String>> entry : sessionMapcontainssoinfo.entrySet())
					{
						String keytoremove = entry.getKey();
						Map<String,String> valueMap = entry.getValue();
						for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
						{
							if(getKeyValueMap.getKey().contains("loginTime"))
							{
								String logntimevalue = getKeyValueMap.getValue();
								String currentTime = dtf.format(now);
								long diffminutes = calculateTimeDiff.timediff(currentTime, logntimevalue);
								if(diffminutes > 30)
								{
									sessionMapcontainssoinfo.remove(keytoremove);
								}
								break;
							}
						}
					}
					speech = "Thank you for contacting Max Life. Have a great day!";
					logger.info("Action END :- close.conversation");
				}
				else {
					speech = "Thank you for contacting Max Life. Have a great day!";
				}
			}
			else if ("close.clear".equalsIgnoreCase(actionperformed)) 
			{
				for(Map.Entry<String, Map<String, String>> entry : sessionMapcontainssoinfo.entrySet())
				{
					String keytoremove = entry.getKey();
					Map<String,String> valueMap = entry.getValue();
					for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
					{
						if(getKeyValueMap.getKey().contains("loginTime"))
						{
							String logntimevalue = getKeyValueMap.getValue();
							String currentTime = dtf.format(now);
							long diffminutes = calculateTimeDiff.timediff(currentTime, logntimevalue);
							if(diffminutes > 30)
							{
								sessionMapcontainssoinfo.remove(keytoremove);
							}
							break;
						}
					}
				}
				speech = "Thank you for contacting Max Life. Have a great day!";
			} 
			else
			{
				if (sessionMapcontainssoinfo.containsKey(sessionId)) 
				{
					String policyNumber="";
					String Validation = "";
					String raAdmAgtId="";
					Map<String, String> cashMap = sessionMapcontainssoinfo.get(sessionId);
					Validation = cashMap.get("Validation");
					ssoId = cashMap.get("validSSOID");
					raAdmAgtId = cashMap.get("raADMAGTID"+sessionId);
					rachannel=cashMap.get("raChannel"+sessionId);
					raSubChannel=cashMap.get("raSubChannel"+sessionId);
					if ("success".equalsIgnoreCase(Validation))
					{
						logger.info("Action Call START : SessionId"+sessionId);
						try {
							try 
							{
								policyNumber = object.getJSONObject("result").getJSONObject("parameters").getLong("policyno")+"";
							}
							catch (Exception e)
							{
								policyNumber = object.getJSONObject("result").getJSONObject("parameters").getString("policyno")+"";
							}
							if("".equalsIgnoreCase(policyNumber))
							{
								policyNumber=sessionMapcontainssoinfo.get(sessionId).get("PolicyNumber"+sessionId)+"";
							}else
							{
								 sessionMapcontainssoinfo.get(sessionId).put("PolicyNumber"+sessionId, policyNumber);
							}
						} catch (Exception e) 
						{
							policyNumber=sessionMapcontainssoinfo.get(sessionId).get("PolicyNumber"+sessionId)+"";
						}
						try {
							period = object.getJSONObject("result").getJSONObject("parameters").getString("Period");
							if(!"".equalsIgnoreCase(period))
							{
								period=sessionMapcontainssoinfo.get(sessionId).put("Period"+sessionId, period)+"";
							}else
							{
								period=sessionMapcontainssoinfo.get(sessionId).get("Period"+sessionId)+"";
							}
						} catch (Exception e) 
						{
							period=sessionMapcontainssoinfo.get(sessionId).get("Period"+sessionId)+"";
						}
						if (!"".equalsIgnoreCase(actionperformed) && actionperformed != null && rachannel!=null && !rachannel.isEmpty() 
								&& raAdmAgtId!=null && !raAdmAgtId.isEmpty() && raSubChannel!=null && !raSubChannel.isEmpty()) 
						{
							/*try
							{
								System.out.println("Start MLAB");
								String status=httpUrlConnectionMlabInsert.httpConnection_response_mlab_Insert(sessionId, ssoId, actionperformed,
										policyNumber, period, resolvedQuery);
								System.out.println("Status of a MLAB:-"+status);
								System.out.println("End MLAB");
							}catch(Exception ex)
							{
								System.out.println("Something goes wrong to connect Mlab:MongoDb");
							}*/
							String dbSessionId = sessionId, dbSSOId = ssoId, dbActionPerformed=actionperformed;
							String dbPolicyNumber=policyNumber, dbPeriod=period, dbResolvedQuery = resolvedQuery;
							try{
								Thread t1=new Thread(new Runnable() 
								{
									public void run() 
									{
										System.out.println("Run Method Start");
										String status=adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed,
												dbPolicyNumber, dbPeriod, dbResolvedQuery);
									}
								});
								t1.start();
								t1.join();
								System.out.println("Run Method END");
							}catch(Exception ex)
							{
								System.out.println("Excption Occoured while saving data in to the database");
							}
							return aPIConsumerService.getWipDataAll(actionperformed, rachannel, period, policyNumber, ssoId, 
									raSubChannel, sessionId, source, raAdmAgtId, AgentName);
						}
						else
						{
							speech="We didn't find valid information for further process.";
						}
					} 
					else {
						speech = "I need to verify the OTP which was sent on your registered mobile number. Please enter it here";
					}
				} else
				{
					speech = "Your session is expired ! Please reload your bot \n\n"
							+ "Thank You !";
				}
			}
		} catch (Exception e) 
		{
		   speech="We didn't find valid information for further process.";
		}
		System.out.println("Final Response --:"+speech);
		System.out.println("RABOTController :: END ::");
		WebhookResponse responseObj = new WebhookResponse(speech, speech);
		return responseObj;
	}

	public Map<String, Map<String, String>> APICallSSOValidation(String ssoId, String sessionId,String actionperformed)
	{
		logger.info("START :- Inside : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		String phoneNo = "", agentName = "", mnylstatus = "";
		String result=null;
		Map<String, Map<String, String>> cashData = null;
		Map<String, String> blankmessage = new HashMap<String, String>();
		if(!"nb.integrate".equalsIgnoreCase(actionperformed))
		{
			result=ssoValidation.SSOCall(ssoId);
		}
		else
		{
			blankmessage.put("Validation", "Success");
			blankmessage.put("validSSOID",  ssoId);
			sessionMapcontainssoinfo.put(sessionId, blankmessage);
			cashData = sessionMapcontainssoinfo;
			return cashData;
		}
		if (result!=null && !"".equalsIgnoreCase(result)) 
		{
			JSONObject object = new JSONObject(result);
			try {
				phoneNo = object.getJSONObject("response").getJSONObject("responseData")
						.getJSONArray("Transactions").getJSONObject(0).get("mnylpreferredmobile") + "";
				logger.info("Phone No: - "+phoneNo+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
				mnylstatus = object.getJSONObject("response").getJSONObject("responseData")
						.getJSONArray("Transactions").getJSONObject(0).get("mnylstatus") + "";
				logger.info("Phone No: - "+mnylstatus+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);
				agentName = object.getJSONObject("response").getJSONObject("responseData")
						.getJSONArray("Transactions").getJSONObject(0).get("givenname") + "";
				logger.info("Phone No: - "+agentName+ " SSOID:- "+ssoId+" SessionId :-"+sessionId);

				if("nb.validate".equalsIgnoreCase(actionperformed))
				{
					logger.info("START Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					cashData = OTPVarification(sessionId, phoneNo, agentName, ssoId, actionperformed);
					logger.info("END Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
				}
				else if (phoneNo != null && !"".equalsIgnoreCase(phoneNo) && mnylstatus != null
						&& !"".equalsIgnoreCase(mnylstatus) && "Y".equalsIgnoreCase(mnylstatus))
				{
					logger.info("START Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					cashData = OTPVarification(sessionId, phoneNo, agentName, ssoId, actionperformed);
					logger.info("END Calling OTPVarification API SSOID :-"+ssoId+ "Session Id:-"+sessionId);

				}
				else
				{
					blankmessage.put("PhoneStatus", phoneNo);
					blankmessage.put("mnylStatus",  mnylstatus);
					sessionMapcontainssoinfo.put(sessionId, blankmessage);
					cashData = sessionMapcontainssoinfo;
				}
			} catch (Exception e) {
				blankmessage.put("firstValidationStatusapi",  "N");
				sessionMapcontainssoinfo.put(sessionId, blankmessage);
				cashData = sessionMapcontainssoinfo;
			}
			System.out.println("External API Call : END ::: APICallSSOValidation");

		} else {
			blankmessage.put("SoaStatus", "Failure_API_1");
			sessionMapcontainssoinfo.put(sessionId, blankmessage);
			cashData = sessionMapcontainssoinfo;
		}

		System.out.println("END :- OutSide : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		return cashData;
	}
	public Map<String, Map<String, String>> OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId,String actionperformed)
	{
		logger.info("START :- Inside : - OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		String status = "", randomotp = "";
		JSONObject object=null;
		Map<String, String> otpsession = new HashMap<String, String>();
		randomotp = randomNumber();
		String serviceResponse=otpGeneration.generateOTP(phoneno, randomotp);

		if (serviceResponse!=null && !"".equalsIgnoreCase(serviceResponse)) 
		{
			if(!"nb.validate".equalsIgnoreCase(actionperformed))
			{
				object = new JSONObject(serviceResponse);
			}
			try {
				if(!"nb.validate".equalsIgnoreCase(actionperformed))
				{
					status = object.getJSONObject("MliSmsServiceResponse").getJSONObject("responseHeader")
							.getJSONObject("generalResponse").get("status") + "";

					Calendar cal = Calendar.getInstance();
					DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
					System.out.println(dateFormat.format(cal.getTime()));
					otpsession.put("Status", status);
					otpsession.put("AgentName", agentName);
					otpsession.put("otp", randomotp);
					otpsession.put("SoaStatus", "success");
					otpsession.put("validSSOID", ssoId);
					otpsession.put("channel", "MLI");
					otpsession.put("period", "MTD");
					otpsession.put("timeStamp", dateFormat.format(cal.getTime()));
					sessionMapcontainssoinfo.put(sessionId, otpsession);
				}else
				{
					otpsession.put("SoaStatus", "partial_content");
					otpsession.put("validSSOID", ssoId);
					otpsession.put("AgentName", agentName);
					sessionMapcontainssoinfo.put(sessionId, otpsession);
				}
			} catch (Exception e) 
			{
				logger.info(e);
			}
			System.out.println("END : OutSide:- OTPVarification :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		}else
		{
			otpsession.put("SoaStatus", "Failure_API");
			sessionMapcontainssoinfo.put(sessionId, otpsession);
			System.out.println("Exception Occoured while calling OTP Varification API Call");
		}
		return sessionMapcontainssoinfo;
	}
	public static String randomNumber()
	{
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i<6; i++) {
			bf =bf.append(getRandomNumberInRange(1, 9));
		}
		return bf.toString();

	}
	public static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
}
