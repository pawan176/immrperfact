package messageimpl;
import JsonImpl.NatHybInforced;

public class AdjMFYP 
{
	public static String adjMFYPIntent(String period, String source, String msgChannel, String mtdAdjustMFYP, String real_tim_timstamp,
			String channel, String dailyAdjustMFYP, String ytd_adj_mfyp,
			String daily_inforced_afyp2, String daily_inforced_count2, String daily_adj_mfyp2, String LacsCr)
	{
		String finalresponse="";
		if("MONTHLY".equalsIgnoreCase(period) ||"MTD".equalsIgnoreCase(period) ||"MONTH".equalsIgnoreCase(period))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse=" Current Update for Monthly Paid Business of "+msgChannel+
						" as of now is : "+mtdAdjustMFYP+ " " + LacsCr;
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()
					+", for Native ecomm - Paid AdjMFYP Business MTD is :"+NatHybInforced.inforcedBean.getNativ_mtd_adj_mfyp()+ " " + LacsCr + ".\n\n"
					+ " For Hybrid ecomm- Paid AdjMFYP Business MTD is :"+NatHybInforced.inforcedBean.getHybride_mtd_adj_mfyp()+ " " + LacsCr;
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+" Paid AdjMFYP Business MTD for "+msgChannel+
							" is : "+mtdAdjustMFYP+ " " + LacsCr;
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse=" Current Update for Paid Business of "+msgChannel
						+" For the day : " +dailyAdjustMFYP+ " " + LacsCr + ","
						+" For the Month : " +mtdAdjustMFYP+ " " + LacsCr
						+" For the Year : " +ytd_adj_mfyp+ " " + LacsCr;

			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel) && "YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", for Native ecomm- Paid AdjMFYP Business YTD is : "+NatHybInforced.inforcedBean.getNativ_ytd_adj_mfyp()+ " " + LacsCr + ". "
							+ "\n\nFor Hybrid ecomm- Paid AdjMFYP Business YTD is : "+NatHybInforced.inforcedBean.getHybride_ytd_adj_mfyp()+ " " + LacsCr;
				}
				else if("Internet Sales".equalsIgnoreCase(channel) && "FTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", for Native ecomm- Paid AdjMFYP Business FTD is : "+NatHybInforced.inforcedBean.getNativ_daily_adj_mfyp()+ " " + LacsCr + ". "
							+ "\n\nFor Hybrid ecomm- Paid AdjMFYP Business FTD is : "+NatHybInforced.inforcedBean.getHybride_daily_adj_mfyp()+ " " + LacsCr;
				}
				else
				{
					if("FTD".equalsIgnoreCase(period))
					{
						finalresponse="As of "+real_tim_timstamp+", for "+msgChannel+", Paid Adj. MFYP - FTD (as on last batch) is "+dailyAdjustMFYP+ " " + LacsCr + ", "
								+ "and FTD (as on current date) is "+daily_adj_mfyp2+ " " + LacsCr;
					}
					else
					{
						finalresponse="As of "+real_tim_timstamp+"  Paid AdjMFYP Business for "+msgChannel+ " is :"+
								" FTD : " +dailyAdjustMFYP+ " " + LacsCr + ","
								+" MTD : " +mtdAdjustMFYP+ " " + LacsCr
								+" YTD : " +ytd_adj_mfyp+ " " + LacsCr;
					}
				}
				if("Agency".equalsIgnoreCase(msgChannel))
				{
					finalresponse=finalresponse+"\n If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
				}
			}
		}
		else 
		{
			if("FTD".equalsIgnoreCase(period))
			{
				finalresponse="As of "+real_tim_timstamp+", for "+msgChannel+", Paid Adj. MFYP - FTD (as on last batch) is "+dailyAdjustMFYP+ " " + LacsCr + ", "
						+ "and FTD (as on current date) is "+daily_adj_mfyp2+ " " + LacsCr;
			}
			else
			{
				finalresponse="As of "+real_tim_timstamp+" paid AdjMFYP Business"+
						" FTD : " +dailyAdjustMFYP+ " " + LacsCr + ","
						+" MTD : " +mtdAdjustMFYP+ " " + LacsCr
						+" YTD : " +ytd_adj_mfyp+ " " + LacsCr;
			}
		}
		return finalresponse.toString();
	}
}
