package messageimpl;
import JsonImpl.NatHybGrowth;
public class Growth 
{
	public static String growthIntent(String source, String msgChannel, String grth_ovr_lst_yr_paid, String adj_mfyp_sam_ytd_lst_yr, 
			String ytd_inforced_adj_mfyp, String period, String grth_lst_yr_sm_adj_mfyp_mtd, String prev_year_adj_mfyp_mtd, 
			String mtd_inforced_adj_mfyp, String LacsCr)
	{
		String finalresponse="";
		if("google".equalsIgnoreCase(source))
		{
			finalresponse = msgChannel+" has witnessed paid Business growth of "+grth_ovr_lst_yr_paid
					+"% on YTD basis, \n\n last year we had clocked "+adj_mfyp_sam_ytd_lst_yr+
					" " + LacsCr +" of paid business, as compared to "+ytd_inforced_adj_mfyp+" " + LacsCr +" today.";
		}
		else if("YTD".equalsIgnoreCase(period))
		{
			finalresponse = msgChannel+" has witnessed paid Business growth of "+grth_ovr_lst_yr_paid
					+"% on YTD basis, \n\n last year we had clocked "+adj_mfyp_sam_ytd_lst_yr+
					" " + LacsCr +" of Adj MFYP as compared to "+ytd_inforced_adj_mfyp+" " + LacsCr + " today.";
		}
		else
		{
			/*if("Internet Sales".equalsIgnoreCase(msgChannel))
			{
				finalresponse="Native ecomm has witnessed paid Business growth of "+NatHybGrowth.growthBean.getN_grth_lst_yr_sm_adj_mfyp_mtd()+ " % on MTD basis, "
						+ "last year same month we had clocked "+NatHybGrowth.growthBean.getN_prev_year_adj_mfyp_mtd()+" Cr of Adj MFYP as compared to "+NatHybGrowth.growthBean.getN_mtd_inforced_adj_mfyp()+" today. \n\n"
						+ "Hybrid ecomm has witnessed paid Business growth of "+NatHybGrowth.growthBean.getH_grth_lst_yr_sm_adj_mfyp_mtd()+" % on MTD basis, "
						+ " last year same month we had clocked "+NatHybGrowth.growthBean.getH_prev_year_adj_mfyp_mtd()+" Cr of Adj MFYP "
						+ " as compared to "+NatHybGrowth.growthBean.getH_mtd_inforced_adj_mfyp()+" today.";
			}
			else
			{*/
				finalresponse = msgChannel+" has witnessed paid Business growth of "+grth_lst_yr_sm_adj_mfyp_mtd
						+"% on MTD basis, \n\n last year same month we had clocked "+prev_year_adj_mfyp_mtd+
						" " + LacsCr +" of Adj MFYP as compared to "+mtd_inforced_adj_mfyp+" " + LacsCr +" today.";
			
		}
		if("Agency".equalsIgnoreCase(msgChannel))
		{
		  finalresponse=finalresponse+" If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
		}
		return finalresponse.toString();
	}
}
