package messageimpl;
import java.util.ArrayList; 
import java.util.List; 
import JsonImpl.NatHybApplied;
import JsonImpl.NatHybInforced;
import JsonImpl.NatHybWIP;
public class Numbers 
{
	public static String numberIntent(String period, String source, String msgChannel, String mtdAdjustMFYP, String mtdAppliedAFYP,
			String convertsum3, String real_tim_timstamp, String channel, String user_sub_channel, String dailyAdjustMFYP, 
			String ytd_adj_mfyp, String dailyAppliedAFYP, String ytd_applied_afyp,

			String daily_applied_afyp2, String daily_applied_count2, String daily_applied_adj_ifyp2,
			String daily_inforced_afyp2, String daily_inforced_count2, String daily_adj_mfyp2, String LacsCr)
	{
		String finalresponse="";
		
if("MONTHLY".equalsIgnoreCase(period) ||"MTD".equalsIgnoreCase(period) ||"MONTH".equalsIgnoreCase(period))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse="Current Monthly Update for "+msgChannel+ "  :\n "
						+"Paid Value for Month is, : "+mtdAdjustMFYP+ " "+ LacsCr +" \n\n"
						+"Applied Value for Month is, : " +mtdAppliedAFYP+" " + LacsCr +" \n\n "
						+"Wip Amount is, : " +convertsum3+" " + LacsCr +" \n\n ";
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse=" As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" the Business update for Native ecomm is :\n Adj MFYP MTD : "+NatHybInforced.inforcedBean.getNativ_mtd_adj_mfyp()+" " + LacsCr
							+ "\n Applied AFYP MTD: "+NatHybApplied.appliedBean.getNativ_mtd_applied_afyp()+" " + LacsCr +" \n WIP Adj MFYP:"+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+" " + LacsCr +". \n\n "
									+ "Hybrid ecomm is : \n Adj MFYP MTD : "+NatHybInforced.inforcedBean.getHybride_mtd_adj_mfyp()+" Cr \n Applied AFYP MTD:"
							+ NatHybApplied.appliedBean.getHybride_mtd_applied_afyp()+" " + LacsCr +" \n WIP Adj MFYP: "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+" " + LacsCr +".";  
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+
							", the Business update for "+msgChannel+ " is :\n"
							+"Adj MFYP MTD : "+mtdAdjustMFYP+ " " + LacsCr +" \n\n"
							+"Applied AFYP MTD: " +mtdAppliedAFYP+ " " + LacsCr +" \n\n "
							+"WIP Adj MFYP: " +convertsum3+ " " + LacsCr +". \n\n ";
				}
			}
			if("MLI".equalsIgnoreCase(channel) || "".equalsIgnoreCase(channel))
			{
				if("".equalsIgnoreCase(user_sub_channel))
				{
					finalresponse = finalresponse+" Do you want to see the Data For any Channel. Please Enter the Channel Name like :\n\n Agency, Axis Bank, Banca, CAT, Ecomm, IM/IMF, SPARC, POSP";
				}
			}
			else if("Agency".equalsIgnoreCase(msgChannel))
			{
				finalresponse=finalresponse+"\n If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
			}
		}
		else if(!"MLI".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(channel))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse="Current Business Update for "+msgChannel+" is : \n Paid Value For the day is, :"+dailyAdjustMFYP+ " " + LacsCr +", \n\n" 
						+"Paid Value For the Month  is, : " +mtdAdjustMFYP+ " "+ LacsCr +", \n\n"
						+"Paid Value For the Year is, : "+ytd_adj_mfyp+ " "+ LacsCr +", \n\n"
						+"Applied value for the Day is, : " +dailyAppliedAFYP+ " "+ LacsCr +", \n\n"
						+"Applied value for the Month is, : " +mtdAppliedAFYP+ " " +LacsCr +", \n\n"
						+"Applied value for the Year is, : "+ytd_applied_afyp+ " " +LacsCr +", \n\n"
						+"WIP Adj MFYP, : " +convertsum3+ " " +LacsCr +".";	
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel)  && "YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" the Business update for Native ecomm is : \n Adj MFYP YTD : "+NatHybInforced.inforcedBean.getNativ_ytd_adj_mfyp()+" " + LacsCr +" \n Applied AFYP YTD: "+NatHybApplied.appliedBean.getNativ_ytd_applied_afyp()+" " + LacsCr 
							+ "\n WIP Adj MFYP: "+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+" " + LacsCr +". \n\n"
							+ "Hybrid ecomm is : \n Adj MFYP YTD :"+NatHybInforced.inforcedBean.getHybride_ytd_adj_mfyp()+" " + LacsCr +" \n Applied AFYP YTD: "+NatHybApplied.appliedBean.getHybride_ytd_applied_afyp()+" " + LacsCr +" \n WIP Adj MFYP: "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+" " + LacsCr +".";
					
				}
				else if ("Internet Sales".equalsIgnoreCase(channel)  && ("MTD".equalsIgnoreCase(period)||"FTD".equalsIgnoreCase(period)))
				{
					finalresponse=" As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" the Business update for Native ecomm is : \n Adj MFYP MTD : "+NatHybInforced.inforcedBean.getNativ_mtd_adj_mfyp()+" " + LacsCr +" \n  Applied AFYP YTD: "+NatHybApplied.appliedBean.getNativ_mtd_applied_afyp()+" " + LacsCr
							+ "\n WIP Adj MFYP: "+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+" " + LacsCr +". \n\n"
							+ "Hybrid ecomm is : \n Adj MFYP YTD :"+NatHybInforced.inforcedBean.getHybride_mtd_adj_mfyp()+" " + LacsCr +" \n Applied AFYP YTD: "+NatHybApplied.appliedBean.getHybride_mtd_applied_afyp()+" " + LacsCr +" \n WIP Adj MFYP: "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+" " + LacsCr +".";
				}
				else
				{
					if("FTD".equalsIgnoreCase(period))
					{
						finalresponse="As of "+real_tim_timstamp+", the Business update for "+msgChannel+" is : \n"
								+ "Adj MFYP- FTD (as on last batch) : "+dailyAdjustMFYP+ " " +LacsCr +", FTD (as on current date) :"+daily_adj_mfyp2+ " " +LacsCr +", \n\n"
								+ "Applied AFYP - FTD (as on last batch): "+dailyAppliedAFYP+ " " +LacsCr +", FTD (as on current date) : "+daily_applied_afyp2+ " " +LacsCr +" \n\n"
								+ "WIP Adj MFYP : "+convertsum3+ " " +LacsCr +".";
					}
					else if("YTD".equalsIgnoreCase(period))
					{
						finalresponse="As of "+real_tim_timstamp+
								", the Business update for "+msgChannel+" is : \n"
								+"Adj MFYP YTD : "+ytd_adj_mfyp+ " " +LacsCr +", \n\n"
								+"Applied AFYP YTD: "+ytd_applied_afyp+ " " +LacsCr +", \n\n"
								+"WIP Adj MFYP : " +convertsum3+ " " +LacsCr +".";
					}
					else
					{
						finalresponse="As of "+real_tim_timstamp+
								", the Business update for "+msgChannel+" is : \n Adj MFYP FTD:"+dailyAdjustMFYP+ " " +LacsCr +", \n\n"
								+"Adj MFYP MTD: " +mtdAdjustMFYP+ " " +LacsCr +", \n\n"
								+"Adj MFYP YTD : "+ytd_adj_mfyp+ " " +LacsCr +", \n\n"
								+"Applied AFYP FTD: " +dailyAppliedAFYP+ " " +LacsCr +", \n\n"
								+"Applied AFYP MTD: " +mtdAppliedAFYP+ " " +LacsCr +", \n\n"
								+"Applied AFYP YTD: "+ytd_applied_afyp+ " " +LacsCr +", \n\n"
								+"WIP Adj MFYP : " +convertsum3+ " " +LacsCr +".";
					}
				}
				if("Agency".equalsIgnoreCase(channel))
				{
					finalresponse=finalresponse+"\n If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
				}
			}
		}
		else 
		{
			if("FTD".equalsIgnoreCase(period))
			{
				finalresponse="As of "+real_tim_timstamp+", the Business update for "+msgChannel+" is : \n"
						+ "Adj MFYP- FTD (as on last batch) : "+dailyAdjustMFYP+ " " +LacsCr +", FTD (as on current date) :"+daily_adj_mfyp2+ " " +LacsCr +", \n\n"
						+ "Applied AFYP - FTD (as on last batch): "+dailyAppliedAFYP+ " " +LacsCr +", FTD (as on current date) : "+daily_applied_afyp2+ " " +LacsCr +" \n\n"
						+ "WIP Adj MFYP : "+convertsum3+ " " +LacsCr +".";
			}
			else if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of "+real_tim_timstamp+
						", the Business update for "+msgChannel+" is : \n"
						+"Adj MFYP YTD : "+ytd_adj_mfyp+ " " +LacsCr +", \n\n"
						+"Applied AFYP YTD: "+ytd_applied_afyp+ " " +LacsCr +", \n\n"
						+"WIP Adj MFYP : " +convertsum3+ " " +LacsCr +".";
			}
			else
			{
				finalresponse="As of "+real_tim_timstamp+
						", the Business update for "+msgChannel+" is : \n Adj MFYP FTD:"+dailyAdjustMFYP+ " " +LacsCr +", \n\n"
						+"Adj MFYP MTD: " +mtdAdjustMFYP+ " " +LacsCr +", \n\n"
						+"Adj MFYP YTD : "+ytd_adj_mfyp+ " " +LacsCr +", \n\n"
						+"Applied AFYP FTD: " +dailyAppliedAFYP+ " " +LacsCr +", \n\n"
						+"Applied AFYP MTD: " +mtdAppliedAFYP+ " " +LacsCr +", \n\n"
						+"Applied AFYP YTD: "+ytd_applied_afyp+ " " +LacsCr +", \n\n"
						+"WIP Adj MFYP: " +convertsum3+ " " +LacsCr +".";
			}
			if("MLI".equalsIgnoreCase(channel) || "".equalsIgnoreCase(channel))
			{
				if("".equalsIgnoreCase(user_sub_channel))
				{
					finalresponse = finalresponse+" Do you want to see the Data For any Channel. Please Enter the Channel Name like :\n\n Agency, Axis Bank, Banca, CAT, Ecomm, IM/IMF, SPARC, POSP";
				}
			}
		}
		return finalresponse.toString();
	}
}
