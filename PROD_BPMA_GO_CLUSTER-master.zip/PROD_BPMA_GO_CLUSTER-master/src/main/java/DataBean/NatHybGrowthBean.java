package DataBean;

public class NatHybGrowthBean {

	private String n_grh_lst_yr_inforced_cnt_ytd;
	private String n_ytd_inforced_cnt;
	private String n_prev_year_inforced_cnt_ytd;
	private String n_grth_lst_yr_inforced_cnt_mtd;
	private String n_mtd_inforced_cnt;
	private String n_prev_year_inforced_cnt_mtd;
	private String n_grth_lst_yr_sm_adj_mfyp_ytd;
	private String n_ytd_inforced_adj_mfyp;
	private String n_prev_year_adj_mfyp_ytd;
	private String n_grth_lst_yr_sm_adj_mfyp_mtd;
	private String n_mtd_inforced_adj_mfyp;
	private String n_prev_year_adj_mfyp_mtd;
	private String n_grth_lst_yr_sm_adj_afyp_ytd;
	private String n_ytd_inforced_adj_afyp;
	private String n_prev_year_adj_afyp_ytd;
	private String n_grth_lst_yr_sm_adj_afyp_mtd;
	private String n_mtd_inforced_adj_afyp;
	private String n_prev_year_adj_afyp_mtd;
	private String n_btch_timstamp;
	private String n_real_tim_timstamp;
	private String n_grth_applied_afyp_mtd;
	private String n_prev_applied_afyp_mtd;
	private String n_applied_afyp_mtd;
	private String n_grth_applied_adj_ifyp_mtd;
	private String n_applied_adj_ifyp_mtd;
	private String n_rpev_applied_adj_ifyp_mtd;
	private String n_grth_applied_cases_mtd;
	private String n_applied_cases_mtd;
	private String n_prev_applied_cases_mtd;
	private String n_grth_lpc_applied_cases_mtd;
	private String n_lpc_applied_cases_mtd;
	private String n_prev_lpc_applied_cases_mtd;
	private String n_grh_lpc_applied_adj_ifyp_mtd;
	private String n_lpc_applied_adj_ifyp_mtd;
	private String n_prv_lpc_applied_adj_ifyp_mtd;
	private String n_grth_lpc_applied_afyp_mtd;
	private String n_curr_lpc_applied_afyp_mtd;
	private String n_prev_lpc_applied_afyp_mtd;
	private String n_grth_lpc_paid_cases_mtd;
	private String n_lpc_paid_cases_mtd;
	private String n_prev_lpc_paid_cases_mtd;
	private String n_grth_lpc_paid_adj_mfyp_mtd;
	private String n_lpc_paid_adj_mfyp_mtd;
	private String n_prev_lpc_paid_adj_mfyp_mtd;
	private String n_grth_recruitment_mtd;
	private String n_recruitment_mtd;
	private String n_prev_recruitment_mtd;
	private String n_grth_case_size_afyp_mtd;
	private String n_case_size_afyp_mtd;
	private String n_prev_case_size_afyp_mtd;
	private String n_grth_prod_mix_adj_mfyp_mtd;
	private String n_prod_mix_adj_mfyp_mtd;
	private String n_prev_prod_mix_adj_mfyp_mtd;
	private String n_grth_prod_mix_paid_cases_mtd;
	private String n_prod_mix_paid_cases_mtd;
	private String n_prev_prod_mix_paid_cases_mtd;
	private String n_grth_mode_mix_adj_mfyp_mtd;
	private String n_mode_mix_adj_mfyp_mtd;
	private String n_prev_mode_mix_adj_mfyp_mtd;
	private String n_grth_applied_afyp_ytd;
	private String n_prev_applied_afyp_ytd;
	private String n_applied_afyp_ytd;
	private String n_grth_applied_adj_ifyp_ytd;
	private String n_applied_adj_ifyp_ytd;
	private String n_rpev_applied_adj_ifyp_ytd;
	private String n_grth_applied_cases_ytd;
	private String n_applied_cases_ytd;
	private String n_prev_applied_cases_ytd;
	private String n_grth_lpc_applied_cases_ytd;
	private String n_lpc_applied_cases_ytd;
	private String n_prev_lpc_applied_cases_ytd;
	private String n_grh_lpc_applied_adj_ifyp_ytd;
	private String n_lpc_applied_adj_ifyp_ytd;
	private String n_prv_lpc_applied_adj_ifyp_ytd;
	private String n_grth_lpc_applied_afyp_ytd;
	private String n_curr_lpc_applied_afyp_ytd;
	private String n_prev_lpc_applied_afyp_ytd;
	private String n_grth_lpc_paid_cases_ytd;
	private String n_lpc_paid_cases_ytd;
	private String n_prev_lpc_paid_cases_ytd;
	private String n_grth_lpc_paid_adj_mfyp_ytd;
	private String n_lpc_paid_adj_mfyp_ytd;
	private String n_prev_lpc_paid_adj_mfyp_ytd;
	private String n_grth_recruitment_ytd;
	private String n_recruitment_ytd;
	private String n_prev_recruitment_ytd;
	private String n_grth_case_size_afyp_ytd;
	private String n_case_size_afyp_ytd;
	private String n_prev_case_size_afyp_ytd;
	private String n_grth_prod_mix_adj_mfyp_ytd;
	private String n_prod_mix_adj_mfyp_ytd;
	private String n_prev_prod_mix_adj_mfyp_ytd;
	private String n_grth_prod_mix_paid_cases_ytd;
	private String n_prod_mix_paid_cases_ytd;
	private String n_prev_prod_mix_paid_cases_ytd;
	private String n_grth_mode_mix_adj_mfyp_ytd;
	private String n_mode_mix_adj_mfyp_ytd;
	private String n_prev_mode_mix_adj_mfyp_ytd;
	private String n_grth_mtd_case_active;
	private String n_mtd_case_active;
	private String n_prev_mtd_case_active;
	private String n_grth_ytd_case_active;
	private String n_ytd_case_active;
	private String n_prev_ytd_case_active;
	private String n_grth_proactive_agents_mtd;
	private String n_proactive_agents_mtd;
	private String n_prev_proactive_agents_mtd;
	private String n_grth_proactive_agents_ytd;
	private String n_proactive_agents_ytd;
	private String n_prev_proactive_agents_ytd;
	private String h_grth_lst_yr_inforced_cnt_ytd;
	private String h_ytd_inforced_cnt;
	private String h_prev_year_inforced_cnt_ytd;
	private String h_grth_lst_yr_inforced_cnt_mtd;
	private String h_mtd_inforced_cnt;
	private String h_prev_year_inforced_cnt_mtd;
	private String h_grth_lst_yr_sm_adj_mfyp_ytd;
	private String h_ytd_inforced_adj_mfyp;
	private String h_prev_year_adj_mfyp_ytd;
	private String h_grth_lst_yr_sm_adj_mfyp_mtd;
	private String h_mtd_inforced_adj_mfyp;
	private String h_prev_year_adj_mfyp_mtd;
	private String h_grth_lst_yr_sm_adj_afyp_ytd;
	private String h_ytd_inforced_adj_afyp;
	private String h_prev_year_adj_afyp_ytd;
	private String h_grth_lst_yr_sm_adj_afyp_mtd;
	private String h_mtd_inforced_adj_afyp;
	private String h_prev_year_adj_afyp_mtd;
	private String h_btch_timstamp;
	private String h_real_tim_timstamp;
	private String h_grth_applied_afyp_mtd;
	private String h_prev_applied_afyp_mtd;
	private String h_applied_afyp_mtd;
	private String h_grth_applied_adj_ifyp_mtd;
	private String h_applied_adj_ifyp_mtd;
	private String h_rpev_applied_adj_ifyp_mtd;
	private String h_grth_applied_cases_mtd;
	private String h_applied_cases_mtd;
	private String h_prev_applied_cases_mtd;
	private String h_grth_lpc_applied_cases_mtd;
	private String h_lpc_applied_cases_mtd;
	private String h_prev_lpc_applied_cases_mtd;
	private String h_grh_lpc_applied_adj_ifyp_mtd;
	private String h_lpc_applied_adj_ifyp_mtd;
	private String h_prv_lpc_applied_adj_ifyp_mtd;
	private String h_grth_lpc_applied_afyp_mtd;
	private String h_curr_lpc_applied_afyp_mtd;
	private String h_prev_lpc_applied_afyp_mtd;
	private String h_grth_lpc_paid_cases_mtd;
	private String h_lpc_paid_cases_mtd;
	private String h_prev_lpc_paid_cases_mtd;
	private String h_grth_lpc_paid_adj_mfyp_mtd;
	private String h_lpc_paid_adj_mfyp_mtd;
	private String h_prev_lpc_paid_adj_mfyp_mtd;
	private String h_grth_recruitment_mtd;
	private String h_recruitment_mtd;
	private String h_prev_recruitment_mtd;
	private String h_grth_case_size_afyp_mtd;
	private String h_case_size_afyp_mtd;
	private String h_prev_case_size_afyp_mtd;
	private String h_grth_prod_mix_adj_mfyp_mtd;
	private String h_prod_mix_adj_mfyp_mtd;
	private String h_prev_prod_mix_adj_mfyp_mtd;
	private String h_grth_prod_mix_paid_cases_mtd;
	private String h_prod_mix_paid_cases_mtd;
	private String h_prev_prod_mix_paid_cases_mtd;
	private String h_grth_mode_mix_adj_mfyp_mtd;
	private String h_mode_mix_adj_mfyp_mtd;
	private String h_prev_mode_mix_adj_mfyp_mtd;
	private String h_grth_applied_afyp_ytd;
	private String h_prev_applied_afyp_ytd;
	private String h_applied_afyp_ytd;
	private String h_grth_applied_adj_ifyp_ytd;
	private String h_applied_adj_ifyp_ytd;
	private String h_rpev_applied_adj_ifyp_ytd;
	private String h_grth_applied_cases_ytd;
	private String h_applied_cases_ytd;
	private String h_prev_applied_cases_ytd;
	private String h_grth_lpc_applied_cases_ytd;
	private String h_lpc_applied_cases_ytd;
	private String h_prev_lpc_applied_cases_ytd;
	private String h_grh_lpc_applied_adj_ifyp_ytd;
	private String h_lpc_applied_adj_ifyp_ytd;
	private String h_prv_lpc_applied_adj_ifyp_ytd;
	private String h_grth_lpc_applied_afyp_ytd;
	private String h_curr_lpc_applied_afyp_ytd;
	private String h_prev_lpc_applied_afyp_ytd;
	private String h_grth_lpc_paid_cases_ytd;
	private String h_lpc_paid_cases_ytd;
	private String h_prev_lpc_paid_cases_ytd;
	private String h_grth_lpc_paid_adj_mfyp_ytd;
	private String h_lpc_paid_adj_mfyp_ytd;
	private String h_prev_lpc_paid_adj_mfyp_ytd;
	private String h_grth_recruitment_ytd;
	private String h_recruitment_ytd;
	private String h_prev_recruitment_ytd;
	private String h_grth_case_size_afyp_ytd;
	private String h_case_size_afyp_ytd;
	private String h_prev_case_size_afyp_ytd;
	private String h_grth_prod_mix_adj_mfyp_ytd;
	private String h_prod_mix_adj_mfyp_ytd;
	private String h_prev_prod_mix_adj_mfyp_ytd;
	private String h_grth_prod_mix_paid_cases_ytd;
	private String h_prod_mix_paid_cases_ytd;
	private String h_prev_prod_mix_paid_cases_ytd;
	private String h_grth_mode_mix_adj_mfyp_ytd;
	private String h_mode_mix_adj_mfyp_ytd;
	private String h_prev_mode_mix_adj_mfyp_ytd;
	private String h_grth_mtd_case_active;
	private String h_mtd_case_active;
	private String h_prev_mtd_case_active;
	private String h_grth_ytd_case_active;
	private String h_ytd_case_active;
	private String h_prev_ytd_case_active;
	private String h_grth_proactive_agents_mtd;
	private String h_proactive_agents_mtd;
	private String h_prev_proactive_agents_mtd;
	private String h_grth_proactive_agents_ytd;
	private String h_proactive_agents_ytd;
	private String h_prev_proactive_agents_ytd;
	private String real_tim_timstamp;

	public String getN_grh_lst_yr_inforced_cnt_ytd() {
		return n_grh_lst_yr_inforced_cnt_ytd;
	}

	public void setN_grh_lst_yr_inforced_cnt_ytd(String n_grh_lst_yr_inforced_cnt_ytd) {
		this.n_grh_lst_yr_inforced_cnt_ytd = n_grh_lst_yr_inforced_cnt_ytd;
	}

	public String getN_ytd_inforced_cnt() {
		return n_ytd_inforced_cnt;
	}

	public void setN_ytd_inforced_cnt(String n_ytd_inforced_cnt) {
		this.n_ytd_inforced_cnt = n_ytd_inforced_cnt;
	}

	public String getN_prev_year_inforced_cnt_ytd() {
		return n_prev_year_inforced_cnt_ytd;
	}

	public void setN_prev_year_inforced_cnt_ytd(String n_prev_year_inforced_cnt_ytd) {
		this.n_prev_year_inforced_cnt_ytd = n_prev_year_inforced_cnt_ytd;
	}

	public String getN_grth_lst_yr_inforced_cnt_mtd() {
		return n_grth_lst_yr_inforced_cnt_mtd;
	}

	public void setN_grth_lst_yr_inforced_cnt_mtd(String n_grth_lst_yr_inforced_cnt_mtd) {
		this.n_grth_lst_yr_inforced_cnt_mtd = n_grth_lst_yr_inforced_cnt_mtd;
	}

	public String getN_mtd_inforced_cnt() {
		return n_mtd_inforced_cnt;
	}

	public void setN_mtd_inforced_cnt(String n_mtd_inforced_cnt) {
		this.n_mtd_inforced_cnt = n_mtd_inforced_cnt;
	}

	public String getN_prev_year_inforced_cnt_mtd() {
		return n_prev_year_inforced_cnt_mtd;
	}

	public void setN_prev_year_inforced_cnt_mtd(String n_prev_year_inforced_cnt_mtd) {
		this.n_prev_year_inforced_cnt_mtd = n_prev_year_inforced_cnt_mtd;
	}

	public String getN_grth_lst_yr_sm_adj_mfyp_ytd() {
		return n_grth_lst_yr_sm_adj_mfyp_ytd;
	}

	public void setN_grth_lst_yr_sm_adj_mfyp_ytd(String n_grth_lst_yr_sm_adj_mfyp_ytd) {
		this.n_grth_lst_yr_sm_adj_mfyp_ytd = n_grth_lst_yr_sm_adj_mfyp_ytd;
	}

	public String getN_ytd_inforced_adj_mfyp() {
		return n_ytd_inforced_adj_mfyp;
	}

	public void setN_ytd_inforced_adj_mfyp(String n_ytd_inforced_adj_mfyp) {
		this.n_ytd_inforced_adj_mfyp = n_ytd_inforced_adj_mfyp;
	}

	public String getN_prev_year_adj_mfyp_ytd() {
		return n_prev_year_adj_mfyp_ytd;
	}

	public void setN_prev_year_adj_mfyp_ytd(String n_prev_year_adj_mfyp_ytd) {
		this.n_prev_year_adj_mfyp_ytd = n_prev_year_adj_mfyp_ytd;
	}

	public String getN_grth_lst_yr_sm_adj_mfyp_mtd() {
		return n_grth_lst_yr_sm_adj_mfyp_mtd;
	}

	public void setN_grth_lst_yr_sm_adj_mfyp_mtd(String n_grth_lst_yr_sm_adj_mfyp_mtd) {
		this.n_grth_lst_yr_sm_adj_mfyp_mtd = n_grth_lst_yr_sm_adj_mfyp_mtd;
	}

	public String getN_mtd_inforced_adj_mfyp() {
		return n_mtd_inforced_adj_mfyp;
	}

	public void setN_mtd_inforced_adj_mfyp(String n_mtd_inforced_adj_mfyp) {
		this.n_mtd_inforced_adj_mfyp = n_mtd_inforced_adj_mfyp;
	}

	public String getN_prev_year_adj_mfyp_mtd() {
		return n_prev_year_adj_mfyp_mtd;
	}

	public void setN_prev_year_adj_mfyp_mtd(String n_prev_year_adj_mfyp_mtd) {
		this.n_prev_year_adj_mfyp_mtd = n_prev_year_adj_mfyp_mtd;
	}

	public String getN_grth_lst_yr_sm_adj_afyp_ytd() {
		return n_grth_lst_yr_sm_adj_afyp_ytd;
	}

	public void setN_grth_lst_yr_sm_adj_afyp_ytd(String n_grth_lst_yr_sm_adj_afyp_ytd) {
		this.n_grth_lst_yr_sm_adj_afyp_ytd = n_grth_lst_yr_sm_adj_afyp_ytd;
	}

	public String getN_ytd_inforced_adj_afyp() {
		return n_ytd_inforced_adj_afyp;
	}

	public void setN_ytd_inforced_adj_afyp(String n_ytd_inforced_adj_afyp) {
		this.n_ytd_inforced_adj_afyp = n_ytd_inforced_adj_afyp;
	}

	public String getN_prev_year_adj_afyp_ytd() {
		return n_prev_year_adj_afyp_ytd;
	}

	public void setN_prev_year_adj_afyp_ytd(String n_prev_year_adj_afyp_ytd) {
		this.n_prev_year_adj_afyp_ytd = n_prev_year_adj_afyp_ytd;
	}

	public String getN_grth_lst_yr_sm_adj_afyp_mtd() {
		return n_grth_lst_yr_sm_adj_afyp_mtd;
	}

	public void setN_grth_lst_yr_sm_adj_afyp_mtd(String n_grth_lst_yr_sm_adj_afyp_mtd) {
		this.n_grth_lst_yr_sm_adj_afyp_mtd = n_grth_lst_yr_sm_adj_afyp_mtd;
	}

	public String getN_mtd_inforced_adj_afyp() {
		return n_mtd_inforced_adj_afyp;
	}

	public void setN_mtd_inforced_adj_afyp(String n_mtd_inforced_adj_afyp) {
		this.n_mtd_inforced_adj_afyp = n_mtd_inforced_adj_afyp;
	}

	public String getN_prev_year_adj_afyp_mtd() {
		return n_prev_year_adj_afyp_mtd;
	}

	public void setN_prev_year_adj_afyp_mtd(String n_prev_year_adj_afyp_mtd) {
		this.n_prev_year_adj_afyp_mtd = n_prev_year_adj_afyp_mtd;
	}

	public String getN_btch_timstamp() {
		return n_btch_timstamp;
	}

	public void setN_btch_timstamp(String n_btch_timstamp) {
		this.n_btch_timstamp = n_btch_timstamp;
	}

	public String getN_real_tim_timstamp() {
		return n_real_tim_timstamp;
	}

	public void setN_real_tim_timstamp(String n_real_tim_timstamp) {
		this.n_real_tim_timstamp = n_real_tim_timstamp;
	}

	public String getN_grth_applied_afyp_mtd() {
		return n_grth_applied_afyp_mtd;
	}

	public void setN_grth_applied_afyp_mtd(String n_grth_applied_afyp_mtd) {
		this.n_grth_applied_afyp_mtd = n_grth_applied_afyp_mtd;
	}

	public String getN_prev_applied_afyp_mtd() {
		return n_prev_applied_afyp_mtd;
	}

	public void setN_prev_applied_afyp_mtd(String n_prev_applied_afyp_mtd) {
		this.n_prev_applied_afyp_mtd = n_prev_applied_afyp_mtd;
	}

	public String getN_applied_afyp_mtd() {
		return n_applied_afyp_mtd;
	}

	public void setN_applied_afyp_mtd(String n_applied_afyp_mtd) {
		this.n_applied_afyp_mtd = n_applied_afyp_mtd;
	}

	public String getN_grth_applied_adj_ifyp_mtd() {
		return n_grth_applied_adj_ifyp_mtd;
	}

	public void setN_grth_applied_adj_ifyp_mtd(String n_grth_applied_adj_ifyp_mtd) {
		this.n_grth_applied_adj_ifyp_mtd = n_grth_applied_adj_ifyp_mtd;
	}

	public String getN_applied_adj_ifyp_mtd() {
		return n_applied_adj_ifyp_mtd;
	}

	public void setN_applied_adj_ifyp_mtd(String n_applied_adj_ifyp_mtd) {
		this.n_applied_adj_ifyp_mtd = n_applied_adj_ifyp_mtd;
	}

	public String getN_rpev_applied_adj_ifyp_mtd() {
		return n_rpev_applied_adj_ifyp_mtd;
	}

	public void setN_rpev_applied_adj_ifyp_mtd(String n_rpev_applied_adj_ifyp_mtd) {
		this.n_rpev_applied_adj_ifyp_mtd = n_rpev_applied_adj_ifyp_mtd;
	}

	public String getN_grth_applied_cases_mtd() {
		return n_grth_applied_cases_mtd;
	}

	public void setN_grth_applied_cases_mtd(String n_grth_applied_cases_mtd) {
		this.n_grth_applied_cases_mtd = n_grth_applied_cases_mtd;
	}

	public String getN_applied_cases_mtd() {
		return n_applied_cases_mtd;
	}

	public void setN_applied_cases_mtd(String n_applied_cases_mtd) {
		this.n_applied_cases_mtd = n_applied_cases_mtd;
	}

	public String getN_prev_applied_cases_mtd() {
		return n_prev_applied_cases_mtd;
	}

	public void setN_prev_applied_cases_mtd(String n_prev_applied_cases_mtd) {
		this.n_prev_applied_cases_mtd = n_prev_applied_cases_mtd;
	}

	public String getN_grth_lpc_applied_cases_mtd() {
		return n_grth_lpc_applied_cases_mtd;
	}

	public void setN_grth_lpc_applied_cases_mtd(String n_grth_lpc_applied_cases_mtd) {
		this.n_grth_lpc_applied_cases_mtd = n_grth_lpc_applied_cases_mtd;
	}

	public String getN_lpc_applied_cases_mtd() {
		return n_lpc_applied_cases_mtd;
	}

	public void setN_lpc_applied_cases_mtd(String n_lpc_applied_cases_mtd) {
		this.n_lpc_applied_cases_mtd = n_lpc_applied_cases_mtd;
	}

	public String getN_prev_lpc_applied_cases_mtd() {
		return n_prev_lpc_applied_cases_mtd;
	}

	public void setN_prev_lpc_applied_cases_mtd(String n_prev_lpc_applied_cases_mtd) {
		this.n_prev_lpc_applied_cases_mtd = n_prev_lpc_applied_cases_mtd;
	}

	public String getN_grh_lpc_applied_adj_ifyp_mtd() {
		return n_grh_lpc_applied_adj_ifyp_mtd;
	}

	public void setN_grh_lpc_applied_adj_ifyp_mtd(String n_grh_lpc_applied_adj_ifyp_mtd) {
		this.n_grh_lpc_applied_adj_ifyp_mtd = n_grh_lpc_applied_adj_ifyp_mtd;
	}

	public String getN_lpc_applied_adj_ifyp_mtd() {
		return n_lpc_applied_adj_ifyp_mtd;
	}

	public void setN_lpc_applied_adj_ifyp_mtd(String n_lpc_applied_adj_ifyp_mtd) {
		this.n_lpc_applied_adj_ifyp_mtd = n_lpc_applied_adj_ifyp_mtd;
	}

	public String getN_prv_lpc_applied_adj_ifyp_mtd() {
		return n_prv_lpc_applied_adj_ifyp_mtd;
	}

	public void setN_prv_lpc_applied_adj_ifyp_mtd(String n_prv_lpc_applied_adj_ifyp_mtd) {
		this.n_prv_lpc_applied_adj_ifyp_mtd = n_prv_lpc_applied_adj_ifyp_mtd;
	}

	public String getN_grth_lpc_applied_afyp_mtd() {
		return n_grth_lpc_applied_afyp_mtd;
	}

	public void setN_grth_lpc_applied_afyp_mtd(String n_grth_lpc_applied_afyp_mtd) {
		this.n_grth_lpc_applied_afyp_mtd = n_grth_lpc_applied_afyp_mtd;
	}

	public String getN_curr_lpc_applied_afyp_mtd() {
		return n_curr_lpc_applied_afyp_mtd;
	}

	public void setN_curr_lpc_applied_afyp_mtd(String n_curr_lpc_applied_afyp_mtd) {
		this.n_curr_lpc_applied_afyp_mtd = n_curr_lpc_applied_afyp_mtd;
	}

	public String getN_prev_lpc_applied_afyp_mtd() {
		return n_prev_lpc_applied_afyp_mtd;
	}

	public void setN_prev_lpc_applied_afyp_mtd(String n_prev_lpc_applied_afyp_mtd) {
		this.n_prev_lpc_applied_afyp_mtd = n_prev_lpc_applied_afyp_mtd;
	}

	public String getN_grth_lpc_paid_cases_mtd() {
		return n_grth_lpc_paid_cases_mtd;
	}

	public void setN_grth_lpc_paid_cases_mtd(String n_grth_lpc_paid_cases_mtd) {
		this.n_grth_lpc_paid_cases_mtd = n_grth_lpc_paid_cases_mtd;
	}

	public String getN_lpc_paid_cases_mtd() {
		return n_lpc_paid_cases_mtd;
	}

	public void setN_lpc_paid_cases_mtd(String n_lpc_paid_cases_mtd) {
		this.n_lpc_paid_cases_mtd = n_lpc_paid_cases_mtd;
	}

	public String getN_prev_lpc_paid_cases_mtd() {
		return n_prev_lpc_paid_cases_mtd;
	}

	public void setN_prev_lpc_paid_cases_mtd(String n_prev_lpc_paid_cases_mtd) {
		this.n_prev_lpc_paid_cases_mtd = n_prev_lpc_paid_cases_mtd;
	}

	public String getN_grth_lpc_paid_adj_mfyp_mtd() {
		return n_grth_lpc_paid_adj_mfyp_mtd;
	}

	public void setN_grth_lpc_paid_adj_mfyp_mtd(String n_grth_lpc_paid_adj_mfyp_mtd) {
		this.n_grth_lpc_paid_adj_mfyp_mtd = n_grth_lpc_paid_adj_mfyp_mtd;
	}

	public String getN_lpc_paid_adj_mfyp_mtd() {
		return n_lpc_paid_adj_mfyp_mtd;
	}

	public void setN_lpc_paid_adj_mfyp_mtd(String n_lpc_paid_adj_mfyp_mtd) {
		this.n_lpc_paid_adj_mfyp_mtd = n_lpc_paid_adj_mfyp_mtd;
	}

	public String getN_prev_lpc_paid_adj_mfyp_mtd() {
		return n_prev_lpc_paid_adj_mfyp_mtd;
	}

	public void setN_prev_lpc_paid_adj_mfyp_mtd(String n_prev_lpc_paid_adj_mfyp_mtd) {
		this.n_prev_lpc_paid_adj_mfyp_mtd = n_prev_lpc_paid_adj_mfyp_mtd;
	}

	public String getN_grth_recruitment_mtd() {
		return n_grth_recruitment_mtd;
	}

	public void setN_grth_recruitment_mtd(String n_grth_recruitment_mtd) {
		this.n_grth_recruitment_mtd = n_grth_recruitment_mtd;
	}

	public String getN_recruitment_mtd() {
		return n_recruitment_mtd;
	}

	public void setN_recruitment_mtd(String n_recruitment_mtd) {
		this.n_recruitment_mtd = n_recruitment_mtd;
	}

	public String getN_prev_recruitment_mtd() {
		return n_prev_recruitment_mtd;
	}

	public void setN_prev_recruitment_mtd(String n_prev_recruitment_mtd) {
		this.n_prev_recruitment_mtd = n_prev_recruitment_mtd;
	}

	public String getN_grth_case_size_afyp_mtd() {
		return n_grth_case_size_afyp_mtd;
	}

	public void setN_grth_case_size_afyp_mtd(String n_grth_case_size_afyp_mtd) {
		this.n_grth_case_size_afyp_mtd = n_grth_case_size_afyp_mtd;
	}

	public String getN_case_size_afyp_mtd() {
		return n_case_size_afyp_mtd;
	}

	public void setN_case_size_afyp_mtd(String n_case_size_afyp_mtd) {
		this.n_case_size_afyp_mtd = n_case_size_afyp_mtd;
	}

	public String getN_prev_case_size_afyp_mtd() {
		return n_prev_case_size_afyp_mtd;
	}

	public void setN_prev_case_size_afyp_mtd(String n_prev_case_size_afyp_mtd) {
		this.n_prev_case_size_afyp_mtd = n_prev_case_size_afyp_mtd;
	}

	public String getN_grth_prod_mix_adj_mfyp_mtd() {
		return n_grth_prod_mix_adj_mfyp_mtd;
	}

	public void setN_grth_prod_mix_adj_mfyp_mtd(String n_grth_prod_mix_adj_mfyp_mtd) {
		this.n_grth_prod_mix_adj_mfyp_mtd = n_grth_prod_mix_adj_mfyp_mtd;
	}

	public String getN_prod_mix_adj_mfyp_mtd() {
		return n_prod_mix_adj_mfyp_mtd;
	}

	public void setN_prod_mix_adj_mfyp_mtd(String n_prod_mix_adj_mfyp_mtd) {
		this.n_prod_mix_adj_mfyp_mtd = n_prod_mix_adj_mfyp_mtd;
	}

	public String getN_prev_prod_mix_adj_mfyp_mtd() {
		return n_prev_prod_mix_adj_mfyp_mtd;
	}

	public void setN_prev_prod_mix_adj_mfyp_mtd(String n_prev_prod_mix_adj_mfyp_mtd) {
		this.n_prev_prod_mix_adj_mfyp_mtd = n_prev_prod_mix_adj_mfyp_mtd;
	}

	public String getN_grth_prod_mix_paid_cases_mtd() {
		return n_grth_prod_mix_paid_cases_mtd;
	}

	public void setN_grth_prod_mix_paid_cases_mtd(String n_grth_prod_mix_paid_cases_mtd) {
		this.n_grth_prod_mix_paid_cases_mtd = n_grth_prod_mix_paid_cases_mtd;
	}

	public String getN_prod_mix_paid_cases_mtd() {
		return n_prod_mix_paid_cases_mtd;
	}

	public void setN_prod_mix_paid_cases_mtd(String n_prod_mix_paid_cases_mtd) {
		this.n_prod_mix_paid_cases_mtd = n_prod_mix_paid_cases_mtd;
	}

	public String getN_prev_prod_mix_paid_cases_mtd() {
		return n_prev_prod_mix_paid_cases_mtd;
	}

	public void setN_prev_prod_mix_paid_cases_mtd(String n_prev_prod_mix_paid_cases_mtd) {
		this.n_prev_prod_mix_paid_cases_mtd = n_prev_prod_mix_paid_cases_mtd;
	}

	public String getN_grth_mode_mix_adj_mfyp_mtd() {
		return n_grth_mode_mix_adj_mfyp_mtd;
	}

	public void setN_grth_mode_mix_adj_mfyp_mtd(String n_grth_mode_mix_adj_mfyp_mtd) {
		this.n_grth_mode_mix_adj_mfyp_mtd = n_grth_mode_mix_adj_mfyp_mtd;
	}

	public String getN_mode_mix_adj_mfyp_mtd() {
		return n_mode_mix_adj_mfyp_mtd;
	}

	public void setN_mode_mix_adj_mfyp_mtd(String n_mode_mix_adj_mfyp_mtd) {
		this.n_mode_mix_adj_mfyp_mtd = n_mode_mix_adj_mfyp_mtd;
	}

	public String getN_prev_mode_mix_adj_mfyp_mtd() {
		return n_prev_mode_mix_adj_mfyp_mtd;
	}

	public void setN_prev_mode_mix_adj_mfyp_mtd(String n_prev_mode_mix_adj_mfyp_mtd) {
		this.n_prev_mode_mix_adj_mfyp_mtd = n_prev_mode_mix_adj_mfyp_mtd;
	}

	public String getN_grth_applied_afyp_ytd() {
		return n_grth_applied_afyp_ytd;
	}

	public void setN_grth_applied_afyp_ytd(String n_grth_applied_afyp_ytd) {
		this.n_grth_applied_afyp_ytd = n_grth_applied_afyp_ytd;
	}

	public String getN_prev_applied_afyp_ytd() {
		return n_prev_applied_afyp_ytd;
	}

	public void setN_prev_applied_afyp_ytd(String n_prev_applied_afyp_ytd) {
		this.n_prev_applied_afyp_ytd = n_prev_applied_afyp_ytd;
	}

	public String getN_applied_afyp_ytd() {
		return n_applied_afyp_ytd;
	}

	public void setN_applied_afyp_ytd(String n_applied_afyp_ytd) {
		this.n_applied_afyp_ytd = n_applied_afyp_ytd;
	}

	public String getN_grth_applied_adj_ifyp_ytd() {
		return n_grth_applied_adj_ifyp_ytd;
	}

	public void setN_grth_applied_adj_ifyp_ytd(String n_grth_applied_adj_ifyp_ytd) {
		this.n_grth_applied_adj_ifyp_ytd = n_grth_applied_adj_ifyp_ytd;
	}

	public String getN_applied_adj_ifyp_ytd() {
		return n_applied_adj_ifyp_ytd;
	}

	public void setN_applied_adj_ifyp_ytd(String n_applied_adj_ifyp_ytd) {
		this.n_applied_adj_ifyp_ytd = n_applied_adj_ifyp_ytd;
	}

	public String getN_rpev_applied_adj_ifyp_ytd() {
		return n_rpev_applied_adj_ifyp_ytd;
	}

	public void setN_rpev_applied_adj_ifyp_ytd(String n_rpev_applied_adj_ifyp_ytd) {
		this.n_rpev_applied_adj_ifyp_ytd = n_rpev_applied_adj_ifyp_ytd;
	}

	public String getN_grth_applied_cases_ytd() {
		return n_grth_applied_cases_ytd;
	}

	public void setN_grth_applied_cases_ytd(String n_grth_applied_cases_ytd) {
		this.n_grth_applied_cases_ytd = n_grth_applied_cases_ytd;
	}

	public String getN_applied_cases_ytd() {
		return n_applied_cases_ytd;
	}

	public void setN_applied_cases_ytd(String n_applied_cases_ytd) {
		this.n_applied_cases_ytd = n_applied_cases_ytd;
	}

	public String getN_prev_applied_cases_ytd() {
		return n_prev_applied_cases_ytd;
	}

	public void setN_prev_applied_cases_ytd(String n_prev_applied_cases_ytd) {
		this.n_prev_applied_cases_ytd = n_prev_applied_cases_ytd;
	}

	public String getN_grth_lpc_applied_cases_ytd() {
		return n_grth_lpc_applied_cases_ytd;
	}

	public void setN_grth_lpc_applied_cases_ytd(String n_grth_lpc_applied_cases_ytd) {
		this.n_grth_lpc_applied_cases_ytd = n_grth_lpc_applied_cases_ytd;
	}

	public String getN_lpc_applied_cases_ytd() {
		return n_lpc_applied_cases_ytd;
	}

	public void setN_lpc_applied_cases_ytd(String n_lpc_applied_cases_ytd) {
		this.n_lpc_applied_cases_ytd = n_lpc_applied_cases_ytd;
	}

	public String getN_prev_lpc_applied_cases_ytd() {
		return n_prev_lpc_applied_cases_ytd;
	}

	public void setN_prev_lpc_applied_cases_ytd(String n_prev_lpc_applied_cases_ytd) {
		this.n_prev_lpc_applied_cases_ytd = n_prev_lpc_applied_cases_ytd;
	}

	public String getN_grh_lpc_applied_adj_ifyp_ytd() {
		return n_grh_lpc_applied_adj_ifyp_ytd;
	}

	public void setN_grh_lpc_applied_adj_ifyp_ytd(String n_grh_lpc_applied_adj_ifyp_ytd) {
		this.n_grh_lpc_applied_adj_ifyp_ytd = n_grh_lpc_applied_adj_ifyp_ytd;
	}

	public String getN_lpc_applied_adj_ifyp_ytd() {
		return n_lpc_applied_adj_ifyp_ytd;
	}

	public void setN_lpc_applied_adj_ifyp_ytd(String n_lpc_applied_adj_ifyp_ytd) {
		this.n_lpc_applied_adj_ifyp_ytd = n_lpc_applied_adj_ifyp_ytd;
	}

	public String getN_prv_lpc_applied_adj_ifyp_ytd() {
		return n_prv_lpc_applied_adj_ifyp_ytd;
	}

	public void setN_prv_lpc_applied_adj_ifyp_ytd(String n_prv_lpc_applied_adj_ifyp_ytd) {
		this.n_prv_lpc_applied_adj_ifyp_ytd = n_prv_lpc_applied_adj_ifyp_ytd;
	}

	public String getN_grth_lpc_applied_afyp_ytd() {
		return n_grth_lpc_applied_afyp_ytd;
	}

	public void setN_grth_lpc_applied_afyp_ytd(String n_grth_lpc_applied_afyp_ytd) {
		this.n_grth_lpc_applied_afyp_ytd = n_grth_lpc_applied_afyp_ytd;
	}

	public String getN_curr_lpc_applied_afyp_ytd() {
		return n_curr_lpc_applied_afyp_ytd;
	}

	public void setN_curr_lpc_applied_afyp_ytd(String n_curr_lpc_applied_afyp_ytd) {
		this.n_curr_lpc_applied_afyp_ytd = n_curr_lpc_applied_afyp_ytd;
	}

	public String getN_prev_lpc_applied_afyp_ytd() {
		return n_prev_lpc_applied_afyp_ytd;
	}

	public void setN_prev_lpc_applied_afyp_ytd(String n_prev_lpc_applied_afyp_ytd) {
		this.n_prev_lpc_applied_afyp_ytd = n_prev_lpc_applied_afyp_ytd;
	}

	public String getN_grth_lpc_paid_cases_ytd() {
		return n_grth_lpc_paid_cases_ytd;
	}

	public void setN_grth_lpc_paid_cases_ytd(String n_grth_lpc_paid_cases_ytd) {
		this.n_grth_lpc_paid_cases_ytd = n_grth_lpc_paid_cases_ytd;
	}

	public String getN_lpc_paid_cases_ytd() {
		return n_lpc_paid_cases_ytd;
	}

	public void setN_lpc_paid_cases_ytd(String n_lpc_paid_cases_ytd) {
		this.n_lpc_paid_cases_ytd = n_lpc_paid_cases_ytd;
	}

	public String getN_prev_lpc_paid_cases_ytd() {
		return n_prev_lpc_paid_cases_ytd;
	}

	public void setN_prev_lpc_paid_cases_ytd(String n_prev_lpc_paid_cases_ytd) {
		this.n_prev_lpc_paid_cases_ytd = n_prev_lpc_paid_cases_ytd;
	}

	public String getN_grth_lpc_paid_adj_mfyp_ytd() {
		return n_grth_lpc_paid_adj_mfyp_ytd;
	}

	public void setN_grth_lpc_paid_adj_mfyp_ytd(String n_grth_lpc_paid_adj_mfyp_ytd) {
		this.n_grth_lpc_paid_adj_mfyp_ytd = n_grth_lpc_paid_adj_mfyp_ytd;
	}

	public String getN_lpc_paid_adj_mfyp_ytd() {
		return n_lpc_paid_adj_mfyp_ytd;
	}

	public void setN_lpc_paid_adj_mfyp_ytd(String n_lpc_paid_adj_mfyp_ytd) {
		this.n_lpc_paid_adj_mfyp_ytd = n_lpc_paid_adj_mfyp_ytd;
	}

	public String getN_prev_lpc_paid_adj_mfyp_ytd() {
		return n_prev_lpc_paid_adj_mfyp_ytd;
	}

	public void setN_prev_lpc_paid_adj_mfyp_ytd(String n_prev_lpc_paid_adj_mfyp_ytd) {
		this.n_prev_lpc_paid_adj_mfyp_ytd = n_prev_lpc_paid_adj_mfyp_ytd;
	}

	public String getN_grth_recruitment_ytd() {
		return n_grth_recruitment_ytd;
	}

	public void setN_grth_recruitment_ytd(String n_grth_recruitment_ytd) {
		this.n_grth_recruitment_ytd = n_grth_recruitment_ytd;
	}

	public String getN_recruitment_ytd() {
		return n_recruitment_ytd;
	}

	public void setN_recruitment_ytd(String n_recruitment_ytd) {
		this.n_recruitment_ytd = n_recruitment_ytd;
	}

	public String getN_prev_recruitment_ytd() {
		return n_prev_recruitment_ytd;
	}

	public void setN_prev_recruitment_ytd(String n_prev_recruitment_ytd) {
		this.n_prev_recruitment_ytd = n_prev_recruitment_ytd;
	}

	public String getN_grth_case_size_afyp_ytd() {
		return n_grth_case_size_afyp_ytd;
	}

	public void setN_grth_case_size_afyp_ytd(String n_grth_case_size_afyp_ytd) {
		this.n_grth_case_size_afyp_ytd = n_grth_case_size_afyp_ytd;
	}

	public String getN_case_size_afyp_ytd() {
		return n_case_size_afyp_ytd;
	}

	public void setN_case_size_afyp_ytd(String n_case_size_afyp_ytd) {
		this.n_case_size_afyp_ytd = n_case_size_afyp_ytd;
	}

	public String getN_prev_case_size_afyp_ytd() {
		return n_prev_case_size_afyp_ytd;
	}

	public void setN_prev_case_size_afyp_ytd(String n_prev_case_size_afyp_ytd) {
		this.n_prev_case_size_afyp_ytd = n_prev_case_size_afyp_ytd;
	}

	public String getN_grth_prod_mix_adj_mfyp_ytd() {
		return n_grth_prod_mix_adj_mfyp_ytd;
	}

	public void setN_grth_prod_mix_adj_mfyp_ytd(String n_grth_prod_mix_adj_mfyp_ytd) {
		this.n_grth_prod_mix_adj_mfyp_ytd = n_grth_prod_mix_adj_mfyp_ytd;
	}

	public String getN_prod_mix_adj_mfyp_ytd() {
		return n_prod_mix_adj_mfyp_ytd;
	}

	public void setN_prod_mix_adj_mfyp_ytd(String n_prod_mix_adj_mfyp_ytd) {
		this.n_prod_mix_adj_mfyp_ytd = n_prod_mix_adj_mfyp_ytd;
	}

	public String getN_prev_prod_mix_adj_mfyp_ytd() {
		return n_prev_prod_mix_adj_mfyp_ytd;
	}

	public void setN_prev_prod_mix_adj_mfyp_ytd(String n_prev_prod_mix_adj_mfyp_ytd) {
		this.n_prev_prod_mix_adj_mfyp_ytd = n_prev_prod_mix_adj_mfyp_ytd;
	}

	public String getN_grth_prod_mix_paid_cases_ytd() {
		return n_grth_prod_mix_paid_cases_ytd;
	}

	public void setN_grth_prod_mix_paid_cases_ytd(String n_grth_prod_mix_paid_cases_ytd) {
		this.n_grth_prod_mix_paid_cases_ytd = n_grth_prod_mix_paid_cases_ytd;
	}

	public String getN_prod_mix_paid_cases_ytd() {
		return n_prod_mix_paid_cases_ytd;
	}

	public void setN_prod_mix_paid_cases_ytd(String n_prod_mix_paid_cases_ytd) {
		this.n_prod_mix_paid_cases_ytd = n_prod_mix_paid_cases_ytd;
	}

	public String getN_prev_prod_mix_paid_cases_ytd() {
		return n_prev_prod_mix_paid_cases_ytd;
	}

	public void setN_prev_prod_mix_paid_cases_ytd(String n_prev_prod_mix_paid_cases_ytd) {
		this.n_prev_prod_mix_paid_cases_ytd = n_prev_prod_mix_paid_cases_ytd;
	}

	public String getN_grth_mode_mix_adj_mfyp_ytd() {
		return n_grth_mode_mix_adj_mfyp_ytd;
	}

	public void setN_grth_mode_mix_adj_mfyp_ytd(String n_grth_mode_mix_adj_mfyp_ytd) {
		this.n_grth_mode_mix_adj_mfyp_ytd = n_grth_mode_mix_adj_mfyp_ytd;
	}

	public String getN_mode_mix_adj_mfyp_ytd() {
		return n_mode_mix_adj_mfyp_ytd;
	}

	public void setN_mode_mix_adj_mfyp_ytd(String n_mode_mix_adj_mfyp_ytd) {
		this.n_mode_mix_adj_mfyp_ytd = n_mode_mix_adj_mfyp_ytd;
	}

	public String getN_prev_mode_mix_adj_mfyp_ytd() {
		return n_prev_mode_mix_adj_mfyp_ytd;
	}

	public void setN_prev_mode_mix_adj_mfyp_ytd(String n_prev_mode_mix_adj_mfyp_ytd) {
		this.n_prev_mode_mix_adj_mfyp_ytd = n_prev_mode_mix_adj_mfyp_ytd;
	}

	public String getN_grth_mtd_case_active() {
		return n_grth_mtd_case_active;
	}

	public void setN_grth_mtd_case_active(String n_grth_mtd_case_active) {
		this.n_grth_mtd_case_active = n_grth_mtd_case_active;
	}

	public String getN_mtd_case_active() {
		return n_mtd_case_active;
	}

	public void setN_mtd_case_active(String n_mtd_case_active) {
		this.n_mtd_case_active = n_mtd_case_active;
	}

	public String getN_prev_mtd_case_active() {
		return n_prev_mtd_case_active;
	}

	public void setN_prev_mtd_case_active(String n_prev_mtd_case_active) {
		this.n_prev_mtd_case_active = n_prev_mtd_case_active;
	}

	public String getN_grth_ytd_case_active() {
		return n_grth_ytd_case_active;
	}

	public void setN_grth_ytd_case_active(String n_grth_ytd_case_active) {
		this.n_grth_ytd_case_active = n_grth_ytd_case_active;
	}

	public String getN_ytd_case_active() {
		return n_ytd_case_active;
	}

	public void setN_ytd_case_active(String n_ytd_case_active) {
		this.n_ytd_case_active = n_ytd_case_active;
	}

	public String getN_prev_ytd_case_active() {
		return n_prev_ytd_case_active;
	}

	public void setN_prev_ytd_case_active(String n_prev_ytd_case_active) {
		this.n_prev_ytd_case_active = n_prev_ytd_case_active;
	}

	public String getN_grth_proactive_agents_mtd() {
		return n_grth_proactive_agents_mtd;
	}

	public void setN_grth_proactive_agents_mtd(String n_grth_proactive_agents_mtd) {
		this.n_grth_proactive_agents_mtd = n_grth_proactive_agents_mtd;
	}

	public String getN_proactive_agents_mtd() {
		return n_proactive_agents_mtd;
	}

	public void setN_proactive_agents_mtd(String n_proactive_agents_mtd) {
		this.n_proactive_agents_mtd = n_proactive_agents_mtd;
	}

	public String getN_prev_proactive_agents_mtd() {
		return n_prev_proactive_agents_mtd;
	}

	public void setN_prev_proactive_agents_mtd(String n_prev_proactive_agents_mtd) {
		this.n_prev_proactive_agents_mtd = n_prev_proactive_agents_mtd;
	}

	public String getN_grth_proactive_agents_ytd() {
		return n_grth_proactive_agents_ytd;
	}

	public void setN_grth_proactive_agents_ytd(String n_grth_proactive_agents_ytd) {
		this.n_grth_proactive_agents_ytd = n_grth_proactive_agents_ytd;
	}

	public String getN_proactive_agents_ytd() {
		return n_proactive_agents_ytd;
	}

	public void setN_proactive_agents_ytd(String n_proactive_agents_ytd) {
		this.n_proactive_agents_ytd = n_proactive_agents_ytd;
	}

	public String getN_prev_proactive_agents_ytd() {
		return n_prev_proactive_agents_ytd;
	}

	public void setN_prev_proactive_agents_ytd(String n_prev_proactive_agents_ytd) {
		this.n_prev_proactive_agents_ytd = n_prev_proactive_agents_ytd;
	}

	public String getH_grth_lst_yr_inforced_cnt_ytd() {
		return h_grth_lst_yr_inforced_cnt_ytd;
	}

	public void setH_grth_lst_yr_inforced_cnt_ytd(String h_grth_lst_yr_inforced_cnt_ytd) {
		this.h_grth_lst_yr_inforced_cnt_ytd = h_grth_lst_yr_inforced_cnt_ytd;
	}

	public String getH_ytd_inforced_cnt() {
		return h_ytd_inforced_cnt;
	}

	public void setH_ytd_inforced_cnt(String h_ytd_inforced_cnt) {
		this.h_ytd_inforced_cnt = h_ytd_inforced_cnt;
	}

	public String getH_prev_year_inforced_cnt_ytd() {
		return h_prev_year_inforced_cnt_ytd;
	}

	public void setH_prev_year_inforced_cnt_ytd(String h_prev_year_inforced_cnt_ytd) {
		this.h_prev_year_inforced_cnt_ytd = h_prev_year_inforced_cnt_ytd;
	}

	public String getH_grth_lst_yr_inforced_cnt_mtd() {
		return h_grth_lst_yr_inforced_cnt_mtd;
	}

	public void setH_grth_lst_yr_inforced_cnt_mtd(String h_grth_lst_yr_inforced_cnt_mtd) {
		this.h_grth_lst_yr_inforced_cnt_mtd = h_grth_lst_yr_inforced_cnt_mtd;
	}

	public String getH_mtd_inforced_cnt() {
		return h_mtd_inforced_cnt;
	}

	public void setH_mtd_inforced_cnt(String h_mtd_inforced_cnt) {
		this.h_mtd_inforced_cnt = h_mtd_inforced_cnt;
	}

	public String getH_prev_year_inforced_cnt_mtd() {
		return h_prev_year_inforced_cnt_mtd;
	}

	public void setH_prev_year_inforced_cnt_mtd(String h_prev_year_inforced_cnt_mtd) {
		this.h_prev_year_inforced_cnt_mtd = h_prev_year_inforced_cnt_mtd;
	}

	public String getH_grth_lst_yr_sm_adj_mfyp_ytd() {
		return h_grth_lst_yr_sm_adj_mfyp_ytd;
	}

	public void setH_grth_lst_yr_sm_adj_mfyp_ytd(String h_grth_lst_yr_sm_adj_mfyp_ytd) {
		this.h_grth_lst_yr_sm_adj_mfyp_ytd = h_grth_lst_yr_sm_adj_mfyp_ytd;
	}

	public String getH_ytd_inforced_adj_mfyp() {
		return h_ytd_inforced_adj_mfyp;
	}

	public void setH_ytd_inforced_adj_mfyp(String h_ytd_inforced_adj_mfyp) {
		this.h_ytd_inforced_adj_mfyp = h_ytd_inforced_adj_mfyp;
	}

	public String getH_prev_year_adj_mfyp_ytd() {
		return h_prev_year_adj_mfyp_ytd;
	}

	public void setH_prev_year_adj_mfyp_ytd(String h_prev_year_adj_mfyp_ytd) {
		this.h_prev_year_adj_mfyp_ytd = h_prev_year_adj_mfyp_ytd;
	}

	public String getH_grth_lst_yr_sm_adj_mfyp_mtd() {
		return h_grth_lst_yr_sm_adj_mfyp_mtd;
	}

	public void setH_grth_lst_yr_sm_adj_mfyp_mtd(String h_grth_lst_yr_sm_adj_mfyp_mtd) {
		this.h_grth_lst_yr_sm_adj_mfyp_mtd = h_grth_lst_yr_sm_adj_mfyp_mtd;
	}

	public String getH_mtd_inforced_adj_mfyp() {
		return h_mtd_inforced_adj_mfyp;
	}

	public void setH_mtd_inforced_adj_mfyp(String h_mtd_inforced_adj_mfyp) {
		this.h_mtd_inforced_adj_mfyp = h_mtd_inforced_adj_mfyp;
	}

	public String getH_prev_year_adj_mfyp_mtd() {
		return h_prev_year_adj_mfyp_mtd;
	}

	public void setH_prev_year_adj_mfyp_mtd(String h_prev_year_adj_mfyp_mtd) {
		this.h_prev_year_adj_mfyp_mtd = h_prev_year_adj_mfyp_mtd;
	}

	public String getH_grth_lst_yr_sm_adj_afyp_ytd() {
		return h_grth_lst_yr_sm_adj_afyp_ytd;
	}

	public void setH_grth_lst_yr_sm_adj_afyp_ytd(String h_grth_lst_yr_sm_adj_afyp_ytd) {
		this.h_grth_lst_yr_sm_adj_afyp_ytd = h_grth_lst_yr_sm_adj_afyp_ytd;
	}

	public String getH_ytd_inforced_adj_afyp() {
		return h_ytd_inforced_adj_afyp;
	}

	public void setH_ytd_inforced_adj_afyp(String h_ytd_inforced_adj_afyp) {
		this.h_ytd_inforced_adj_afyp = h_ytd_inforced_adj_afyp;
	}

	public String getH_prev_year_adj_afyp_ytd() {
		return h_prev_year_adj_afyp_ytd;
	}

	public void setH_prev_year_adj_afyp_ytd(String h_prev_year_adj_afyp_ytd) {
		this.h_prev_year_adj_afyp_ytd = h_prev_year_adj_afyp_ytd;
	}

	public String getH_grth_lst_yr_sm_adj_afyp_mtd() {
		return h_grth_lst_yr_sm_adj_afyp_mtd;
	}

	public void setH_grth_lst_yr_sm_adj_afyp_mtd(String h_grth_lst_yr_sm_adj_afyp_mtd) {
		this.h_grth_lst_yr_sm_adj_afyp_mtd = h_grth_lst_yr_sm_adj_afyp_mtd;
	}

	public String getH_mtd_inforced_adj_afyp() {
		return h_mtd_inforced_adj_afyp;
	}

	public void setH_mtd_inforced_adj_afyp(String h_mtd_inforced_adj_afyp) {
		this.h_mtd_inforced_adj_afyp = h_mtd_inforced_adj_afyp;
	}

	public String getH_prev_year_adj_afyp_mtd() {
		return h_prev_year_adj_afyp_mtd;
	}

	public void setH_prev_year_adj_afyp_mtd(String h_prev_year_adj_afyp_mtd) {
		this.h_prev_year_adj_afyp_mtd = h_prev_year_adj_afyp_mtd;
	}

	public String getH_btch_timstamp() {
		return h_btch_timstamp;
	}

	public void setH_btch_timstamp(String h_btch_timstamp) {
		this.h_btch_timstamp = h_btch_timstamp;
	}

	public String getH_real_tim_timstamp() {
		return h_real_tim_timstamp;
	}

	public void setH_real_tim_timstamp(String h_real_tim_timstamp) {
		this.h_real_tim_timstamp = h_real_tim_timstamp;
	}

	public String getH_grth_applied_afyp_mtd() {
		return h_grth_applied_afyp_mtd;
	}

	public void setH_grth_applied_afyp_mtd(String h_grth_applied_afyp_mtd) {
		this.h_grth_applied_afyp_mtd = h_grth_applied_afyp_mtd;
	}

	public String getH_prev_applied_afyp_mtd() {
		return h_prev_applied_afyp_mtd;
	}

	public void setH_prev_applied_afyp_mtd(String h_prev_applied_afyp_mtd) {
		this.h_prev_applied_afyp_mtd = h_prev_applied_afyp_mtd;
	}

	public String getH_applied_afyp_mtd() {
		return h_applied_afyp_mtd;
	}

	public void setH_applied_afyp_mtd(String h_applied_afyp_mtd) {
		this.h_applied_afyp_mtd = h_applied_afyp_mtd;
	}

	public String getH_grth_applied_adj_ifyp_mtd() {
		return h_grth_applied_adj_ifyp_mtd;
	}

	public void setH_grth_applied_adj_ifyp_mtd(String h_grth_applied_adj_ifyp_mtd) {
		this.h_grth_applied_adj_ifyp_mtd = h_grth_applied_adj_ifyp_mtd;
	}

	public String getH_applied_adj_ifyp_mtd() {
		return h_applied_adj_ifyp_mtd;
	}

	public void setH_applied_adj_ifyp_mtd(String h_applied_adj_ifyp_mtd) {
		this.h_applied_adj_ifyp_mtd = h_applied_adj_ifyp_mtd;
	}

	public String getH_rpev_applied_adj_ifyp_mtd() {
		return h_rpev_applied_adj_ifyp_mtd;
	}

	public void setH_rpev_applied_adj_ifyp_mtd(String h_rpev_applied_adj_ifyp_mtd) {
		this.h_rpev_applied_adj_ifyp_mtd = h_rpev_applied_adj_ifyp_mtd;
	}

	public String getH_grth_applied_cases_mtd() {
		return h_grth_applied_cases_mtd;
	}

	public void setH_grth_applied_cases_mtd(String h_grth_applied_cases_mtd) {
		this.h_grth_applied_cases_mtd = h_grth_applied_cases_mtd;
	}

	public String getH_applied_cases_mtd() {
		return h_applied_cases_mtd;
	}

	public void setH_applied_cases_mtd(String h_applied_cases_mtd) {
		this.h_applied_cases_mtd = h_applied_cases_mtd;
	}

	public String getH_prev_applied_cases_mtd() {
		return h_prev_applied_cases_mtd;
	}

	public void setH_prev_applied_cases_mtd(String h_prev_applied_cases_mtd) {
		this.h_prev_applied_cases_mtd = h_prev_applied_cases_mtd;
	}

	public String getH_grth_lpc_applied_cases_mtd() {
		return h_grth_lpc_applied_cases_mtd;
	}

	public void setH_grth_lpc_applied_cases_mtd(String h_grth_lpc_applied_cases_mtd) {
		this.h_grth_lpc_applied_cases_mtd = h_grth_lpc_applied_cases_mtd;
	}

	public String getH_lpc_applied_cases_mtd() {
		return h_lpc_applied_cases_mtd;
	}

	public void setH_lpc_applied_cases_mtd(String h_lpc_applied_cases_mtd) {
		this.h_lpc_applied_cases_mtd = h_lpc_applied_cases_mtd;
	}

	public String getH_prev_lpc_applied_cases_mtd() {
		return h_prev_lpc_applied_cases_mtd;
	}

	public void setH_prev_lpc_applied_cases_mtd(String h_prev_lpc_applied_cases_mtd) {
		this.h_prev_lpc_applied_cases_mtd = h_prev_lpc_applied_cases_mtd;
	}

	public String getH_grh_lpc_applied_adj_ifyp_mtd() {
		return h_grh_lpc_applied_adj_ifyp_mtd;
	}

	public void setH_grh_lpc_applied_adj_ifyp_mtd(String h_grh_lpc_applied_adj_ifyp_mtd) {
		this.h_grh_lpc_applied_adj_ifyp_mtd = h_grh_lpc_applied_adj_ifyp_mtd;
	}

	public String getH_lpc_applied_adj_ifyp_mtd() {
		return h_lpc_applied_adj_ifyp_mtd;
	}

	public void setH_lpc_applied_adj_ifyp_mtd(String h_lpc_applied_adj_ifyp_mtd) {
		this.h_lpc_applied_adj_ifyp_mtd = h_lpc_applied_adj_ifyp_mtd;
	}

	public String getH_prv_lpc_applied_adj_ifyp_mtd() {
		return h_prv_lpc_applied_adj_ifyp_mtd;
	}

	public void setH_prv_lpc_applied_adj_ifyp_mtd(String h_prv_lpc_applied_adj_ifyp_mtd) {
		this.h_prv_lpc_applied_adj_ifyp_mtd = h_prv_lpc_applied_adj_ifyp_mtd;
	}

	public String getH_grth_lpc_applied_afyp_mtd() {
		return h_grth_lpc_applied_afyp_mtd;
	}

	public void setH_grth_lpc_applied_afyp_mtd(String h_grth_lpc_applied_afyp_mtd) {
		this.h_grth_lpc_applied_afyp_mtd = h_grth_lpc_applied_afyp_mtd;
	}

	public String getH_curr_lpc_applied_afyp_mtd() {
		return h_curr_lpc_applied_afyp_mtd;
	}

	public void setH_curr_lpc_applied_afyp_mtd(String h_curr_lpc_applied_afyp_mtd) {
		this.h_curr_lpc_applied_afyp_mtd = h_curr_lpc_applied_afyp_mtd;
	}

	public String getH_prev_lpc_applied_afyp_mtd() {
		return h_prev_lpc_applied_afyp_mtd;
	}

	public void setH_prev_lpc_applied_afyp_mtd(String h_prev_lpc_applied_afyp_mtd) {
		this.h_prev_lpc_applied_afyp_mtd = h_prev_lpc_applied_afyp_mtd;
	}

	public String getH_grth_lpc_paid_cases_mtd() {
		return h_grth_lpc_paid_cases_mtd;
	}

	public void setH_grth_lpc_paid_cases_mtd(String h_grth_lpc_paid_cases_mtd) {
		this.h_grth_lpc_paid_cases_mtd = h_grth_lpc_paid_cases_mtd;
	}

	public String getH_lpc_paid_cases_mtd() {
		return h_lpc_paid_cases_mtd;
	}

	public void setH_lpc_paid_cases_mtd(String h_lpc_paid_cases_mtd) {
		this.h_lpc_paid_cases_mtd = h_lpc_paid_cases_mtd;
	}

	public String getH_prev_lpc_paid_cases_mtd() {
		return h_prev_lpc_paid_cases_mtd;
	}

	public void setH_prev_lpc_paid_cases_mtd(String h_prev_lpc_paid_cases_mtd) {
		this.h_prev_lpc_paid_cases_mtd = h_prev_lpc_paid_cases_mtd;
	}

	public String getH_grth_lpc_paid_adj_mfyp_mtd() {
		return h_grth_lpc_paid_adj_mfyp_mtd;
	}

	public void setH_grth_lpc_paid_adj_mfyp_mtd(String h_grth_lpc_paid_adj_mfyp_mtd) {
		this.h_grth_lpc_paid_adj_mfyp_mtd = h_grth_lpc_paid_adj_mfyp_mtd;
	}

	public String getH_lpc_paid_adj_mfyp_mtd() {
		return h_lpc_paid_adj_mfyp_mtd;
	}

	public void setH_lpc_paid_adj_mfyp_mtd(String h_lpc_paid_adj_mfyp_mtd) {
		this.h_lpc_paid_adj_mfyp_mtd = h_lpc_paid_adj_mfyp_mtd;
	}

	public String getH_prev_lpc_paid_adj_mfyp_mtd() {
		return h_prev_lpc_paid_adj_mfyp_mtd;
	}

	public void setH_prev_lpc_paid_adj_mfyp_mtd(String h_prev_lpc_paid_adj_mfyp_mtd) {
		this.h_prev_lpc_paid_adj_mfyp_mtd = h_prev_lpc_paid_adj_mfyp_mtd;
	}

	public String getH_grth_recruitment_mtd() {
		return h_grth_recruitment_mtd;
	}

	public void setH_grth_recruitment_mtd(String h_grth_recruitment_mtd) {
		this.h_grth_recruitment_mtd = h_grth_recruitment_mtd;
	}

	public String getH_recruitment_mtd() {
		return h_recruitment_mtd;
	}

	public void setH_recruitment_mtd(String h_recruitment_mtd) {
		this.h_recruitment_mtd = h_recruitment_mtd;
	}

	public String getH_prev_recruitment_mtd() {
		return h_prev_recruitment_mtd;
	}

	public void setH_prev_recruitment_mtd(String h_prev_recruitment_mtd) {
		this.h_prev_recruitment_mtd = h_prev_recruitment_mtd;
	}

	public String getH_grth_case_size_afyp_mtd() {
		return h_grth_case_size_afyp_mtd;
	}

	public void setH_grth_case_size_afyp_mtd(String h_grth_case_size_afyp_mtd) {
		this.h_grth_case_size_afyp_mtd = h_grth_case_size_afyp_mtd;
	}

	public String getH_case_size_afyp_mtd() {
		return h_case_size_afyp_mtd;
	}

	public void setH_case_size_afyp_mtd(String h_case_size_afyp_mtd) {
		this.h_case_size_afyp_mtd = h_case_size_afyp_mtd;
	}

	public String getH_prev_case_size_afyp_mtd() {
		return h_prev_case_size_afyp_mtd;
	}

	public void setH_prev_case_size_afyp_mtd(String h_prev_case_size_afyp_mtd) {
		this.h_prev_case_size_afyp_mtd = h_prev_case_size_afyp_mtd;
	}

	public String getH_grth_prod_mix_adj_mfyp_mtd() {
		return h_grth_prod_mix_adj_mfyp_mtd;
	}

	public void setH_grth_prod_mix_adj_mfyp_mtd(String h_grth_prod_mix_adj_mfyp_mtd) {
		this.h_grth_prod_mix_adj_mfyp_mtd = h_grth_prod_mix_adj_mfyp_mtd;
	}

	public String getH_prod_mix_adj_mfyp_mtd() {
		return h_prod_mix_adj_mfyp_mtd;
	}

	public void setH_prod_mix_adj_mfyp_mtd(String h_prod_mix_adj_mfyp_mtd) {
		this.h_prod_mix_adj_mfyp_mtd = h_prod_mix_adj_mfyp_mtd;
	}

	public String getH_prev_prod_mix_adj_mfyp_mtd() {
		return h_prev_prod_mix_adj_mfyp_mtd;
	}

	public void setH_prev_prod_mix_adj_mfyp_mtd(String h_prev_prod_mix_adj_mfyp_mtd) {
		this.h_prev_prod_mix_adj_mfyp_mtd = h_prev_prod_mix_adj_mfyp_mtd;
	}

	public String getH_grth_prod_mix_paid_cases_mtd() {
		return h_grth_prod_mix_paid_cases_mtd;
	}

	public void setH_grth_prod_mix_paid_cases_mtd(String h_grth_prod_mix_paid_cases_mtd) {
		this.h_grth_prod_mix_paid_cases_mtd = h_grth_prod_mix_paid_cases_mtd;
	}

	public String getH_prod_mix_paid_cases_mtd() {
		return h_prod_mix_paid_cases_mtd;
	}

	public void setH_prod_mix_paid_cases_mtd(String h_prod_mix_paid_cases_mtd) {
		this.h_prod_mix_paid_cases_mtd = h_prod_mix_paid_cases_mtd;
	}

	public String getH_prev_prod_mix_paid_cases_mtd() {
		return h_prev_prod_mix_paid_cases_mtd;
	}

	public void setH_prev_prod_mix_paid_cases_mtd(String h_prev_prod_mix_paid_cases_mtd) {
		this.h_prev_prod_mix_paid_cases_mtd = h_prev_prod_mix_paid_cases_mtd;
	}

	public String getH_grth_mode_mix_adj_mfyp_mtd() {
		return h_grth_mode_mix_adj_mfyp_mtd;
	}

	public void setH_grth_mode_mix_adj_mfyp_mtd(String h_grth_mode_mix_adj_mfyp_mtd) {
		this.h_grth_mode_mix_adj_mfyp_mtd = h_grth_mode_mix_adj_mfyp_mtd;
	}

	public String getH_mode_mix_adj_mfyp_mtd() {
		return h_mode_mix_adj_mfyp_mtd;
	}

	public void setH_mode_mix_adj_mfyp_mtd(String h_mode_mix_adj_mfyp_mtd) {
		this.h_mode_mix_adj_mfyp_mtd = h_mode_mix_adj_mfyp_mtd;
	}

	public String getH_prev_mode_mix_adj_mfyp_mtd() {
		return h_prev_mode_mix_adj_mfyp_mtd;
	}

	public void setH_prev_mode_mix_adj_mfyp_mtd(String h_prev_mode_mix_adj_mfyp_mtd) {
		this.h_prev_mode_mix_adj_mfyp_mtd = h_prev_mode_mix_adj_mfyp_mtd;
	}

	public String getH_grth_applied_afyp_ytd() {
		return h_grth_applied_afyp_ytd;
	}

	public void setH_grth_applied_afyp_ytd(String h_grth_applied_afyp_ytd) {
		this.h_grth_applied_afyp_ytd = h_grth_applied_afyp_ytd;
	}

	public String getH_prev_applied_afyp_ytd() {
		return h_prev_applied_afyp_ytd;
	}

	public void setH_prev_applied_afyp_ytd(String h_prev_applied_afyp_ytd) {
		this.h_prev_applied_afyp_ytd = h_prev_applied_afyp_ytd;
	}

	public String getH_applied_afyp_ytd() {
		return h_applied_afyp_ytd;
	}

	public void setH_applied_afyp_ytd(String h_applied_afyp_ytd) {
		this.h_applied_afyp_ytd = h_applied_afyp_ytd;
	}

	public String getH_grth_applied_adj_ifyp_ytd() {
		return h_grth_applied_adj_ifyp_ytd;
	}

	public void setH_grth_applied_adj_ifyp_ytd(String h_grth_applied_adj_ifyp_ytd) {
		this.h_grth_applied_adj_ifyp_ytd = h_grth_applied_adj_ifyp_ytd;
	}

	public String getH_applied_adj_ifyp_ytd() {
		return h_applied_adj_ifyp_ytd;
	}

	public void setH_applied_adj_ifyp_ytd(String h_applied_adj_ifyp_ytd) {
		this.h_applied_adj_ifyp_ytd = h_applied_adj_ifyp_ytd;
	}

	public String getH_rpev_applied_adj_ifyp_ytd() {
		return h_rpev_applied_adj_ifyp_ytd;
	}

	public void setH_rpev_applied_adj_ifyp_ytd(String h_rpev_applied_adj_ifyp_ytd) {
		this.h_rpev_applied_adj_ifyp_ytd = h_rpev_applied_adj_ifyp_ytd;
	}

	public String getH_grth_applied_cases_ytd() {
		return h_grth_applied_cases_ytd;
	}

	public void setH_grth_applied_cases_ytd(String h_grth_applied_cases_ytd) {
		this.h_grth_applied_cases_ytd = h_grth_applied_cases_ytd;
	}

	public String getH_applied_cases_ytd() {
		return h_applied_cases_ytd;
	}

	public void setH_applied_cases_ytd(String h_applied_cases_ytd) {
		this.h_applied_cases_ytd = h_applied_cases_ytd;
	}

	public String getH_prev_applied_cases_ytd() {
		return h_prev_applied_cases_ytd;
	}

	public void setH_prev_applied_cases_ytd(String h_prev_applied_cases_ytd) {
		this.h_prev_applied_cases_ytd = h_prev_applied_cases_ytd;
	}

	public String getH_grth_lpc_applied_cases_ytd() {
		return h_grth_lpc_applied_cases_ytd;
	}

	public void setH_grth_lpc_applied_cases_ytd(String h_grth_lpc_applied_cases_ytd) {
		this.h_grth_lpc_applied_cases_ytd = h_grth_lpc_applied_cases_ytd;
	}

	public String getH_lpc_applied_cases_ytd() {
		return h_lpc_applied_cases_ytd;
	}

	public void setH_lpc_applied_cases_ytd(String h_lpc_applied_cases_ytd) {
		this.h_lpc_applied_cases_ytd = h_lpc_applied_cases_ytd;
	}

	public String getH_prev_lpc_applied_cases_ytd() {
		return h_prev_lpc_applied_cases_ytd;
	}

	public void setH_prev_lpc_applied_cases_ytd(String h_prev_lpc_applied_cases_ytd) {
		this.h_prev_lpc_applied_cases_ytd = h_prev_lpc_applied_cases_ytd;
	}

	public String getH_grh_lpc_applied_adj_ifyp_ytd() {
		return h_grh_lpc_applied_adj_ifyp_ytd;
	}

	public void setH_grh_lpc_applied_adj_ifyp_ytd(String h_grh_lpc_applied_adj_ifyp_ytd) {
		this.h_grh_lpc_applied_adj_ifyp_ytd = h_grh_lpc_applied_adj_ifyp_ytd;
	}

	public String getH_lpc_applied_adj_ifyp_ytd() {
		return h_lpc_applied_adj_ifyp_ytd;
	}

	public void setH_lpc_applied_adj_ifyp_ytd(String h_lpc_applied_adj_ifyp_ytd) {
		this.h_lpc_applied_adj_ifyp_ytd = h_lpc_applied_adj_ifyp_ytd;
	}

	public String getH_prv_lpc_applied_adj_ifyp_ytd() {
		return h_prv_lpc_applied_adj_ifyp_ytd;
	}

	public void setH_prv_lpc_applied_adj_ifyp_ytd(String h_prv_lpc_applied_adj_ifyp_ytd) {
		this.h_prv_lpc_applied_adj_ifyp_ytd = h_prv_lpc_applied_adj_ifyp_ytd;
	}

	public String getH_grth_lpc_applied_afyp_ytd() {
		return h_grth_lpc_applied_afyp_ytd;
	}

	public void setH_grth_lpc_applied_afyp_ytd(String h_grth_lpc_applied_afyp_ytd) {
		this.h_grth_lpc_applied_afyp_ytd = h_grth_lpc_applied_afyp_ytd;
	}

	public String getH_curr_lpc_applied_afyp_ytd() {
		return h_curr_lpc_applied_afyp_ytd;
	}

	public void setH_curr_lpc_applied_afyp_ytd(String h_curr_lpc_applied_afyp_ytd) {
		this.h_curr_lpc_applied_afyp_ytd = h_curr_lpc_applied_afyp_ytd;
	}

	public String getH_prev_lpc_applied_afyp_ytd() {
		return h_prev_lpc_applied_afyp_ytd;
	}

	public void setH_prev_lpc_applied_afyp_ytd(String h_prev_lpc_applied_afyp_ytd) {
		this.h_prev_lpc_applied_afyp_ytd = h_prev_lpc_applied_afyp_ytd;
	}

	public String getH_grth_lpc_paid_cases_ytd() {
		return h_grth_lpc_paid_cases_ytd;
	}

	public void setH_grth_lpc_paid_cases_ytd(String h_grth_lpc_paid_cases_ytd) {
		this.h_grth_lpc_paid_cases_ytd = h_grth_lpc_paid_cases_ytd;
	}

	public String getH_lpc_paid_cases_ytd() {
		return h_lpc_paid_cases_ytd;
	}

	public void setH_lpc_paid_cases_ytd(String h_lpc_paid_cases_ytd) {
		this.h_lpc_paid_cases_ytd = h_lpc_paid_cases_ytd;
	}

	public String getH_prev_lpc_paid_cases_ytd() {
		return h_prev_lpc_paid_cases_ytd;
	}

	public void setH_prev_lpc_paid_cases_ytd(String h_prev_lpc_paid_cases_ytd) {
		this.h_prev_lpc_paid_cases_ytd = h_prev_lpc_paid_cases_ytd;
	}

	public String getH_grth_lpc_paid_adj_mfyp_ytd() {
		return h_grth_lpc_paid_adj_mfyp_ytd;
	}

	public void setH_grth_lpc_paid_adj_mfyp_ytd(String h_grth_lpc_paid_adj_mfyp_ytd) {
		this.h_grth_lpc_paid_adj_mfyp_ytd = h_grth_lpc_paid_adj_mfyp_ytd;
	}

	public String getH_lpc_paid_adj_mfyp_ytd() {
		return h_lpc_paid_adj_mfyp_ytd;
	}

	public void setH_lpc_paid_adj_mfyp_ytd(String h_lpc_paid_adj_mfyp_ytd) {
		this.h_lpc_paid_adj_mfyp_ytd = h_lpc_paid_adj_mfyp_ytd;
	}

	public String getH_prev_lpc_paid_adj_mfyp_ytd() {
		return h_prev_lpc_paid_adj_mfyp_ytd;
	}

	public void setH_prev_lpc_paid_adj_mfyp_ytd(String h_prev_lpc_paid_adj_mfyp_ytd) {
		this.h_prev_lpc_paid_adj_mfyp_ytd = h_prev_lpc_paid_adj_mfyp_ytd;
	}

	public String getH_grth_recruitment_ytd() {
		return h_grth_recruitment_ytd;
	}

	public void setH_grth_recruitment_ytd(String h_grth_recruitment_ytd) {
		this.h_grth_recruitment_ytd = h_grth_recruitment_ytd;
	}

	public String getH_recruitment_ytd() {
		return h_recruitment_ytd;
	}

	public void setH_recruitment_ytd(String h_recruitment_ytd) {
		this.h_recruitment_ytd = h_recruitment_ytd;
	}

	public String getH_prev_recruitment_ytd() {
		return h_prev_recruitment_ytd;
	}

	public void setH_prev_recruitment_ytd(String h_prev_recruitment_ytd) {
		this.h_prev_recruitment_ytd = h_prev_recruitment_ytd;
	}

	public String getH_grth_case_size_afyp_ytd() {
		return h_grth_case_size_afyp_ytd;
	}

	public void setH_grth_case_size_afyp_ytd(String h_grth_case_size_afyp_ytd) {
		this.h_grth_case_size_afyp_ytd = h_grth_case_size_afyp_ytd;
	}

	public String getH_case_size_afyp_ytd() {
		return h_case_size_afyp_ytd;
	}

	public void setH_case_size_afyp_ytd(String h_case_size_afyp_ytd) {
		this.h_case_size_afyp_ytd = h_case_size_afyp_ytd;
	}

	public String getH_prev_case_size_afyp_ytd() {
		return h_prev_case_size_afyp_ytd;
	}

	public void setH_prev_case_size_afyp_ytd(String h_prev_case_size_afyp_ytd) {
		this.h_prev_case_size_afyp_ytd = h_prev_case_size_afyp_ytd;
	}

	public String getH_grth_prod_mix_adj_mfyp_ytd() {
		return h_grth_prod_mix_adj_mfyp_ytd;
	}

	public void setH_grth_prod_mix_adj_mfyp_ytd(String h_grth_prod_mix_adj_mfyp_ytd) {
		this.h_grth_prod_mix_adj_mfyp_ytd = h_grth_prod_mix_adj_mfyp_ytd;
	}

	public String getH_prod_mix_adj_mfyp_ytd() {
		return h_prod_mix_adj_mfyp_ytd;
	}

	public void setH_prod_mix_adj_mfyp_ytd(String h_prod_mix_adj_mfyp_ytd) {
		this.h_prod_mix_adj_mfyp_ytd = h_prod_mix_adj_mfyp_ytd;
	}

	public String getH_prev_prod_mix_adj_mfyp_ytd() {
		return h_prev_prod_mix_adj_mfyp_ytd;
	}

	public void setH_prev_prod_mix_adj_mfyp_ytd(String h_prev_prod_mix_adj_mfyp_ytd) {
		this.h_prev_prod_mix_adj_mfyp_ytd = h_prev_prod_mix_adj_mfyp_ytd;
	}

	public String getH_grth_prod_mix_paid_cases_ytd() {
		return h_grth_prod_mix_paid_cases_ytd;
	}

	public void setH_grth_prod_mix_paid_cases_ytd(String h_grth_prod_mix_paid_cases_ytd) {
		this.h_grth_prod_mix_paid_cases_ytd = h_grth_prod_mix_paid_cases_ytd;
	}

	public String getH_prod_mix_paid_cases_ytd() {
		return h_prod_mix_paid_cases_ytd;
	}

	public void setH_prod_mix_paid_cases_ytd(String h_prod_mix_paid_cases_ytd) {
		this.h_prod_mix_paid_cases_ytd = h_prod_mix_paid_cases_ytd;
	}

	public String getH_prev_prod_mix_paid_cases_ytd() {
		return h_prev_prod_mix_paid_cases_ytd;
	}

	public void setH_prev_prod_mix_paid_cases_ytd(String h_prev_prod_mix_paid_cases_ytd) {
		this.h_prev_prod_mix_paid_cases_ytd = h_prev_prod_mix_paid_cases_ytd;
	}

	public String getH_grth_mode_mix_adj_mfyp_ytd() {
		return h_grth_mode_mix_adj_mfyp_ytd;
	}

	public void setH_grth_mode_mix_adj_mfyp_ytd(String h_grth_mode_mix_adj_mfyp_ytd) {
		this.h_grth_mode_mix_adj_mfyp_ytd = h_grth_mode_mix_adj_mfyp_ytd;
	}

	public String getH_mode_mix_adj_mfyp_ytd() {
		return h_mode_mix_adj_mfyp_ytd;
	}

	public void setH_mode_mix_adj_mfyp_ytd(String h_mode_mix_adj_mfyp_ytd) {
		this.h_mode_mix_adj_mfyp_ytd = h_mode_mix_adj_mfyp_ytd;
	}

	public String getH_prev_mode_mix_adj_mfyp_ytd() {
		return h_prev_mode_mix_adj_mfyp_ytd;
	}

	public void setH_prev_mode_mix_adj_mfyp_ytd(String h_prev_mode_mix_adj_mfyp_ytd) {
		this.h_prev_mode_mix_adj_mfyp_ytd = h_prev_mode_mix_adj_mfyp_ytd;
	}

	public String getH_grth_mtd_case_active() {
		return h_grth_mtd_case_active;
	}

	public void setH_grth_mtd_case_active(String h_grth_mtd_case_active) {
		this.h_grth_mtd_case_active = h_grth_mtd_case_active;
	}

	public String getH_mtd_case_active() {
		return h_mtd_case_active;
	}

	public void setH_mtd_case_active(String h_mtd_case_active) {
		this.h_mtd_case_active = h_mtd_case_active;
	}

	public String getH_prev_mtd_case_active() {
		return h_prev_mtd_case_active;
	}

	public void setH_prev_mtd_case_active(String h_prev_mtd_case_active) {
		this.h_prev_mtd_case_active = h_prev_mtd_case_active;
	}

	public String getH_grth_ytd_case_active() {
		return h_grth_ytd_case_active;
	}

	public void setH_grth_ytd_case_active(String h_grth_ytd_case_active) {
		this.h_grth_ytd_case_active = h_grth_ytd_case_active;
	}

	public String getH_ytd_case_active() {
		return h_ytd_case_active;
	}

	public void setH_ytd_case_active(String h_ytd_case_active) {
		this.h_ytd_case_active = h_ytd_case_active;
	}

	public String getH_prev_ytd_case_active() {
		return h_prev_ytd_case_active;
	}

	public void setH_prev_ytd_case_active(String h_prev_ytd_case_active) {
		this.h_prev_ytd_case_active = h_prev_ytd_case_active;
	}

	public String getH_grth_proactive_agents_mtd() {
		return h_grth_proactive_agents_mtd;
	}

	public void setH_grth_proactive_agents_mtd(String h_grth_proactive_agents_mtd) {
		this.h_grth_proactive_agents_mtd = h_grth_proactive_agents_mtd;
	}

	public String getH_proactive_agents_mtd() {
		return h_proactive_agents_mtd;
	}

	public void setH_proactive_agents_mtd(String h_proactive_agents_mtd) {
		this.h_proactive_agents_mtd = h_proactive_agents_mtd;
	}

	public String getH_prev_proactive_agents_mtd() {
		return h_prev_proactive_agents_mtd;
	}

	public void setH_prev_proactive_agents_mtd(String h_prev_proactive_agents_mtd) {
		this.h_prev_proactive_agents_mtd = h_prev_proactive_agents_mtd;
	}

	public String getH_grth_proactive_agents_ytd() {
		return h_grth_proactive_agents_ytd;
	}

	public void setH_grth_proactive_agents_ytd(String h_grth_proactive_agents_ytd) {
		this.h_grth_proactive_agents_ytd = h_grth_proactive_agents_ytd;
	}

	public String getH_proactive_agents_ytd() {
		return h_proactive_agents_ytd;
	}

	public void setH_proactive_agents_ytd(String h_proactive_agents_ytd) {
		this.h_proactive_agents_ytd = h_proactive_agents_ytd;
	}

	public String getH_prev_proactive_agents_ytd() {
		return h_prev_proactive_agents_ytd;
	}

	public void setH_prev_proactive_agents_ytd(String h_prev_proactive_agents_ytd) {
		this.h_prev_proactive_agents_ytd = h_prev_proactive_agents_ytd;
	}

	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}

	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
