package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class PolicyPack 
{
	@Autowired
	private Bean bean;
	public String policyPackIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		else
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		System.out.println("PolicyPack--"+ finalresponse);
		return finalresponse;
	}
}
