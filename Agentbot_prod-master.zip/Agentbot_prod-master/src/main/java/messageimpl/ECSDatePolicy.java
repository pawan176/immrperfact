package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class ECSDatePolicy 
{
	@Autowired
	private Bean bean;
	public String eCSDatePolicyIntent(String policyNumber)
	{
		String finalresponse="";
		if("0".equalsIgnoreCase(bean.getPolicy_ecs_dt()))
		{
			finalresponse="This is not an ECSPolicy";
		}
		else if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		else
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		
		System.out.println("ECSDatePolicy--"+ finalresponse);
		return finalresponse;
	}
}
