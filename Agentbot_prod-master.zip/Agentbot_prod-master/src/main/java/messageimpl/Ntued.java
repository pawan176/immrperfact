package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class Ntued 
{
	@Autowired
	private Bean bean;
	public String ntuedIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		else
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		System.out.println("Ntued--"+ finalresponse);
		return finalresponse;
	}
}
