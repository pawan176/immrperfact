package JsonImpl;

import org.json.JSONObject;

import DataBean.ProtectionBean;

public class Protection {

	
	public ProtectionBean Protectionmethod(JSONObject object)
	{
		ProtectionBean protectionBean = new ProtectionBean();
		try{
			protectionBean.setProtec_ho_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_ho_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_go_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_go_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_it_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_it_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_fin_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_fin_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_misc_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_misc_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_welcome_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_welcome_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_total_wip_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_total_wip_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_ho_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_ho_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_go_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_go_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_it_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_it_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_fin_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_fin_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_misc_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_misc_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_welcome_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_welcome_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_total_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_total_wip_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_daily_pol_cnt(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_daily_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_daily_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_daily_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_paid_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_daily_applied_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_daily_applied_afyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_daily_applied_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_daily_applied_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_mtd_applied_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_mtd_applied_afyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_mtd_applied_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_mtd_applied_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_ytd_applied_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_ytd_applied_afyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_ytd_applied_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_ytd_applied_count").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_mtd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_mtd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_ytd_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_ytd_applied_adj_ifyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setProtec_daily_applied_adj_ifyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_daily_applied_adj_ifyp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setBtch_timstamp(object.getJSONObject("payload").getJSONObject("protectionDto").get("btch_timstamp").toString());
		}catch(Exception e){}
		
		try{
			protectionBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("protectionDto").get("real_tim_timstamp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_daily_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_daily_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_mtd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_ytd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_plan_paid_mtd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_plan_paid_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paln_paid_ytd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paln_paid_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_plan_paid_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_plan_paid_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_plan_paid_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_plan_paid_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_plan_paid_mtd_pol_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_plan_paid_mtd_pol_count").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_plan_paid_ytd_pol_count(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_plan_paid_ytd_pol_count").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_mtd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_ytd_afyp(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_mtd_nop(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_mtd_nop").toString());
		}catch(Exception e){}
		try{
			protectionBean.setProtec_paid_achv_ytd_nop(object.getJSONObject("payload").getJSONObject("protectionDto").get("protec_paid_achv_ytd_nop").toString());
		}catch(Exception e){}
		return protectionBean;
	}
}
