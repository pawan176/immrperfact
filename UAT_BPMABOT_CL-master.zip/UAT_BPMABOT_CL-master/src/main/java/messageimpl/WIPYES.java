package messageimpl;
import java.text.DecimalFormat;
public class WIPYES 
{
	public static String wipyesIntent(String channel, String msgChannel, String convertsum3, String convertsum4, double hoWIPAFYP,
			double ho_wip_count, double goWIPAFYP, double go_wip_count, double itWIPAFYP, double it_wip_count, double finWIPAFYP, 
			double fin_wip_count, double miscWIPAFYP, double misc_wip_count, double welcomeWIPAFYP, double welcome_wip_count,
			double ho_wip_adj_mfyp, double go_wip_adj_mfyp, double it_wip_adj_mfyp, double fin_wip_adj_mfyp, 
			double misc_wip_adj_mfyp, double welcome_wip_adj_mfyp, String LacsCr)
	{
		DecimalFormat df = new DecimalFormat("####");
		String finalresponse="";
		if(!"".equalsIgnoreCase(channel))
		{
			finalresponse="WIP for "+msgChannel+" Adj MFYP :" +convertsum3+" " + LacsCr +". and Policies "+convertsum4+" "
					+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(ho_wip_count)+" "
					+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(go_wip_count)+" "
					+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(it_wip_count)+" "
					+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(fin_wip_count)+" "
					+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(misc_wip_count)+" "
					+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(welcome_wip_count)+"";
		}
		else
		{
			finalresponse="WIP AdjMFYP: " +convertsum3+" " + LacsCr +"."
					+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +".";
		}
		return finalresponse.toString();
	}

}
