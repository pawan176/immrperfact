package messageimpl;

public class Lpcappadjafyp {

	public static String lpcAppAdjAfypIntent(String channel, String period, String user_region, String user_circle, String userzone , String real_tim_timstamp,
			String lpc_applied_afyp_mtd, String lpc_applied_afyp_ytd, String subchannel, String user_clusters, String user_go, String LacsCr)
	{
		String finalresponse = "";
		if("Agency".equalsIgnoreCase(channel))
		{
			if("MLI".equalsIgnoreCase(channel))
			{channel="";}
			if("Monthly".equalsIgnoreCase(period))
			{period="";}
			else
			{
				if("FTD".equalsIgnoreCase(period))
				{
					period="MTD";
				}else
				{
					period=period.toUpperCase();
				}
			}
			if(!"".equalsIgnoreCase(user_circle))
			{user_region="Circle "+user_circle;}
			if(!"".equalsIgnoreCase(user_go))
			{
				user_clusters="Circle "+user_go;
			}
			if(!"".equalsIgnoreCase(subchannel))
			{
				channel = subchannel;
			}
			if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			   && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for MLI is "
						+lpc_applied_afyp_mtd+" " + LacsCr +". LPC Applied Business AFYP YTD for MLI is "+lpc_applied_afyp_ytd+ 
						" " + LacsCr +". If you want to see the channel wise business numbers, please specify the same.";
			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				if("Agency".equalsIgnoreCase(channel))
				{
					finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+channel+
							" is "+lpc_applied_afyp_mtd+" " + LacsCr +". LPC Applied Business AFYP YTD for "+channel+" is "+lpc_applied_afyp_ytd
							+" If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
				}
				else{
					finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+channel+
							" is "+lpc_applied_afyp_mtd+" " + LacsCr +". LPC Applied Business AFYP YTD for "+channel+" is "+lpc_applied_afyp_ytd+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+userzone+" zone is "
						+lpc_applied_afyp_mtd+" " + LacsCr +". LPC Applied Business AFYP YTD for "+userzone+" zone is " +lpc_applied_afyp_ytd+
						" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";
			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+user_region+ " is " 
						+lpc_applied_afyp_mtd+ " " + LacsCr +". LPC Applied Business AFYP YTD for "+user_region+" is "+ lpc_applied_afyp_ytd+" " + LacsCr +".";

			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+user_clusters+ " is " 
						+lpc_applied_afyp_mtd+ " " + LacsCr +". LPC Applied Business AFYP YTD for "+user_clusters+" is "+ lpc_applied_afyp_ytd+" " + LacsCr +".";

			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(period) && !"".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+user_clusters+ " is " 
						+lpc_applied_afyp_mtd+ " " + LacsCr +". LPC Applied Business AFYP YTD for "+user_clusters+" is "+ lpc_applied_afyp_ytd+" " + LacsCr +".";

			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+user_clusters+ " is " 
						+lpc_applied_afyp_mtd+ " " + LacsCr +". LPC Applied Business AFYP YTD for "+user_clusters+" is "+ lpc_applied_afyp_ytd+" " + LacsCr +".";

			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				finalresponse= "As of "+real_tim_timstamp+" LPC Applied Business AFYP MTD for "+user_region+ " is " 
						+lpc_applied_afyp_mtd+ " " + LacsCr +". LPC Applied Business AFYP YTD for "+user_region+" is "+ lpc_applied_afyp_ytd+" " + LacsCr +".";

			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+channel+ " is "+lpc_applied_afyp_ytd+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of " +real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+channel+ " is "+lpc_applied_afyp_mtd+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+ " for "+userzone+" is "+lpc_applied_afyp_ytd+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+ " for "+userzone+" is "+lpc_applied_afyp_mtd+
							" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";	
				}
			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_region+ " is "+lpc_applied_afyp_ytd+" " + LacsCr +".";
				}
				else
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_region+ " is "+lpc_applied_afyp_mtd+" " + LacsCr +".";	
				}
			}
			else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_clusters+ " is "+lpc_applied_afyp_ytd+" " + LacsCr +".";
				}
				else
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_clusters+ " is "+lpc_applied_afyp_mtd+" " + LacsCr +".";	
				}
			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_region+ " is "+lpc_applied_afyp_ytd+" " + LacsCr +".";
				}
				else
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_region+ " is "+lpc_applied_afyp_mtd+" " + LacsCr +".";	
				}
			}
			else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_clusters+ " is "+lpc_applied_afyp_ytd+" " + LacsCr +".";
				}
				else
				{
					finalresponse=" As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for "+ user_clusters+ " is "+lpc_applied_afyp_mtd+" " + LacsCr +".";	
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for MLI is "+lpc_applied_afyp_ytd+
							" " + LacsCr +". If you want to see the channel wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+" LPC Applied Business AFYP "+period+" for MLI is "+lpc_applied_afyp_mtd+
							" " + LacsCr +". If you want to see the channel wise business numbers, please specify the same.";	
				}
			}
		}
		else
		{
			finalresponse="Invalid Channel For LPC";
		}
		return finalresponse.toString();
	}
}
