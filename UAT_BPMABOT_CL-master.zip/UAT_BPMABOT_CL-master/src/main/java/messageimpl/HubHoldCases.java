package messageimpl;
import DataBean.HubHoldBean;
public class HubHoldCases 
{
	public static String hubHoldIntent(String channel, String period, String userzone, String user_region, 
			 String user_circle, String subchannel, String user_clusters, String user_go, String LacsCr, HubHoldBean hubHoldBean)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{user_region="Circle "+user_circle;}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{channel = subchannel;}
		
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for MLI is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+channel+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +".";
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse=finalresponse+" If you want to see the data for sub-channels, please enter sub-channel name – Defence, Office within office.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+userzone+" Zone is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+user_region+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+user_clusters+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+user_clusters+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+user_clusters+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases for "+user_region+" is "+hubHoldBean.getTotal_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getTotal_hub_hold_adj_mfyp()+" " + LacsCr +"."; 

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			 && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
				
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
					+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +".";  
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		/*--------------------------------------Channel & GO------start----------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +".";  
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		/*--------------------------------------Channel & GO----------end------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		/*-----------------------------------------start----------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
			else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		/*-------------------------------------------end--------------------------------------------------------------------------*/
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getYtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getYtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getMtd_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getMtd_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}else
			{
				finalresponse= "As of "+hubHoldBean.getReal_tim_timstamp()+" the total Hub hold cases "+period+" for "+channel+" is "+hubHoldBean.getDaily_hub_hold_cases()+" "
						+ "with adj.MFYP "+hubHoldBean.getDaily_hub_hold_adj_mfyp()+" " + LacsCr +"."; 
			}
		}
		return finalresponse.toString();
	}
}
