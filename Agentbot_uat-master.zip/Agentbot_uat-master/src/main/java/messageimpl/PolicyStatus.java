package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class PolicyStatus 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String policyStatusIntent(String policyNumber, String customerName)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse=" The current status of Policy No. "+policyNumber+
					" - "+bean.getPolicy_status_desc();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse=" The current status of Policy No. "+policyNumber+
					" - "+bean.getPolicy_status_desc();
		}else
		{
			finalresponse=" The current status of Policy No. "+policyNumber+
					" - "+bean.getPolicy_status_desc();
		}
		System.out.println("PolicyStatus --"+finalresponse);
		return finalresponse;
	}
}
