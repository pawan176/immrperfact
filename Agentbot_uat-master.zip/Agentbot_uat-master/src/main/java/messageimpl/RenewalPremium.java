package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class RenewalPremium 
{
	@Autowired
	private Bean bean;
	public String renewalPremiumIntent(String policyNumber)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		else
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		System.out.println("RenewalPremium--"+ finalresponse);
		return finalresponse;
	}
}
