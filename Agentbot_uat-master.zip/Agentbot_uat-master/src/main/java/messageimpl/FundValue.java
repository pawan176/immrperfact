package messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Bean;

@Service
public class FundValue 
{
	@Autowired
	private Bean bean;
	
	public String fundValueIntent(String policyNumber)
	{
		String finalresponse="";
		if("TRAD".equalsIgnoreCase(bean.getBTCH_TIMSTAMP()))
		{
			finalresponse="Fund Value is not applicable for this policy.";
		}
		else if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		System.out.println("AdjMFYPIntent--"+ finalresponse);
		return finalresponse;
	}
}
