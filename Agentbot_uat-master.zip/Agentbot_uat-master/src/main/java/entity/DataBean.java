package entity;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class DataBean 
{
	@Autowired
	private Bean bean;
	public String getDatafromJsonObject(String splitIntent, JSONObject object)
	{
		String finalresponse="true";
		switch(splitIntent)
		{
		case "ADJMFYP":
		{
			try	
			{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("channel").toString());
			}
			catch(Exception ex){}
			try	
			{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	
			{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("adjMFYP").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_ftd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setAdj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_qtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAdj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "PAIDCASES":
		{
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("paidcase").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("paidcase").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("paidcase").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_ftd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setInforced_mtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_qtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setInforced_ytd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WTGMFYP":
		{
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWtg_mfyp_mtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_MTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setWtg_mfyp_qtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWtg_mfyp_ytd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYSTATUS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatus").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatus").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatus").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatus").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatus").get("policy_STATUS_DESC")+"");
			}
			catch(Exception ex)	{}
			try	{
				bean.setPol_due_date(object.getJSONObject("payload").getJSONObject("policyStatus").get("pol_DUE_DATE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYSTATUSDOBPAN":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_owner_dob(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_DOB").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPol_owner_pan(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_PAN").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_STATUS_DESC").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "RENEWALPREMIUM":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("renewalPremium").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("renewalPremium").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_renewal_prm(object.getJSONObject("payload").getJSONObject("renewalPremium").get("pol_RENEWAL_PRM").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "PREMIUMDUE":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("premiumDue").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("premiumDue").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("premiumDue").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setDue_policy_count(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setDue_policy_mfyp(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "COLLECTION":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("collection").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("collection").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("collection").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setTotal_collection_amt(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_AMT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setTotal_collection_mfyp(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "ROLLINGCOLLECTION":
		{   
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("rollingCollection").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRolling_collection_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_COLLECTION_12MTH").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setRolling_mfyp_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_MFYP_12MTH").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "NTUED":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ntued").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ntued").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ntued").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNtu_policy_count(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setNtu_policy_afyp(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_AFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "NOMINEEDETAILS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setNominee_name(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_NAME")+"");
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_dob(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_DOB").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_relationship(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_RELATIONSHIP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setNominee_share(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_SHARE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "POLICYPACK":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("policyPack").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyPack").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyPack").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyPack").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_pack_delvry_dt(object.getJSONObject("payload").getJSONObject("policyPack").get("pol_PACK_DELVRY_DT").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "MEDICALCATEGORY":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("medicalCategory").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("medicalCategory").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_med_category(object.getJSONObject("payload").getJSONObject("medicalCategory").get("pol_MED_CATEGORY").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "FUNDVALUE":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("fundValue").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("fundValue").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("fundValue").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("fundValue").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_fund_value(object.getJSONObject("payload").getJSONObject("fundValue").get("pol_FUND_VALUE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "ECSDATEPOLICY":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ecsdate").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ecsdate").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ecsdate").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPolicy_ecs_dt(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_ECS_DT").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WELCOMECALLINGSTATUS":
		{  
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_welcom_call_status(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("pol_WELCOM_CALL_STATUS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "REASONWELCOMECALLSTATUS":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("policy_NUMBER").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setPol_welcom_call_region(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("pol_WELCOM_CALL_REGION").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "MPERSISTENCY":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("mpersistency").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("mpersistency").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("mpersistency").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setTotal_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("total_BASE_13M_PERS").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setUnpaid_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("unpaid_BASE_13M_PERS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setAchievement_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("achievement_13M_PERS").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "WIPCASES":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("wipCases").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wipCases").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wipCases").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_count(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_COUNT").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setWip_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_afyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_AFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_adj_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_ADJ_MFYP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setWip_stage(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_STAGE").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "APPLIEDCASES":
		case "APPLIEDFYP":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("appliedCases").get("channel").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("appliedCases").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("appliedCases").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_FTD").toString());
			}
			catch(Exception ex){}
			try	{
				bean.setApplied_total_afyp_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_total_afyp_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_FTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_MTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_QTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setApplied_count_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_YTD").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	{}
		}
		break;
		case "AXISBANK":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("axisBank").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("axisBank").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("axisBank").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setActivisa_mtd_active(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_ACTIVE").toString());
			}
			catch(Exception ex)
			{
				bean.setActivisa_mtd_active("N/A");
			}
			try	{
				bean.setPerform_15th_month_pers_qtd_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_15TH_MONTH_PERS_QTD_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_15th_month_pers_qtd_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setGpa_score(object.getJSONObject("payload").getJSONObject("axisBank").get("gpa_SCORE").toString());
			}
			catch(Exception ex)	
			{
				bean.setGpa_score("N/A");
			}
			try	{
				bean.setActivisa_mtd_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_prcntg("N/A");
			}
			try	{
				bean.setActivisa_mtd_manmonth(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_manmonth("N/A");
			}
			try	{
				bean.setMtd_activa_act_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_ACT_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_act_ach_prcntg("N/A");
			}
			try	{
				bean.setPerform_adj_mfyp_plan_ach_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_ADJ_MFYP_PLAN_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_adj_mfyp_plan_ach_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setMtd_activa_plan_manmonth(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_manmonth("N/A");
			}
			try	{
				bean.setMtd_activa_plan_active(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_ACTIVE").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_active("N/A");
			}
			try	{
				bean.setMtd_activa_plan_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_ach_prcntg("N/A");
			}
			try	{
				bean.setPerform_activation_ach_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_ACTIVATION_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_activation_ach_p("N/A");
			}
			/* DB team Added after development------------------------------------------------------------------------*/
			try	{
				bean.setPrmtn_shrtfl_adj_mfyp_pln_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_ADJ_MFYP_PLN_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_adj_mfyp_pln_ach("N/A");
			}
			try	{
				bean.setPrmtn_shrtfl_actvn_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_ACTVN_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_actvn_ach("N/A");
			}
			try	{
				bean.setPrmtn_shrtfl_15m_pers_qtd_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_15M_PERS_QTD_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_15m_pers_qtd_ach("N/A");
			}
			/*------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("axisBank").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("axisBank").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "CAT":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("cat").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("cat").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("cat").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT_6M").toString());
			}
			catch(Exception ex)
			{
				bean.setPromo_wtg_fyp_act_6m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_6M").toString());
			}
			catch(Exception ex)
			{
				bean.setPromo_wtg_fyp_ach_p_6m("N/A");
			}
			try	{
				bean.setPromo_nop_act_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act_6m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_6m("N/A");
			}
			try	{
				bean.setPromo_collection_ach_p(object.getJSONObject("payload").getJSONObject("cat").get("promo_COLLECTION_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_collection_ach_p("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act_9m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_ach_p_9m("N/A");
			}
			try	{
				bean.setPromo_nop_act_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act_9m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_9m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act12m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_ach_p_12m("N/A");
			}
			try	{
				bean.setPromo_nop_act12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act12m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_12m("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("ytd_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("ytd_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("cat").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("cat").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "Agency":
		{ 

			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("agency").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("agency").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("agency").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setAdm_tot_gpa_scor_extra_credit(object.getJSONObject("payload").getJSONObject("agency").get("adm_TOT_GPA_SCOR_EXTRA_CREDIT").toString());
			}
			catch(Exception ex)
			{
				bean.setAdm_tot_gpa_scor_extra_credit("N/A");
			}
			try	{
				bean.setRecruitment_mtd(object.getJSONObject("payload").getJSONObject("agency").get("recruitment_MTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setRecruitment_mtd("N/A");
			}
			try	{
				bean.setRecruitment_ytd(object.getJSONObject("payload").getJSONObject("agency").get("recruitment_YTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setRecruitment_ytd("N/A");
			}
			try	{
				bean.setQua_recruit_extra_cr_actual(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_EXTRA_CR_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_extra_cr_actual("N/A");
			}
			try	{
				bean.setQua_recruit_ach_percntg(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_ACH_PERCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_ach_percntg("N/A");
			}
			try	{
				bean.setNat_count_ftd(object.getJSONObject("payload").getJSONObject("agency").get("nat_COUNT_FTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setNat_count_ftd("N/A");
			}
			try	{
				bean.setNat_count_mtd(object.getJSONObject("payload").getJSONObject("agency").get("nat_COUNT_MTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setNat_count_mtd("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_in_lac_act(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_IN_LAC_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_in_lac_act("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_in_lac_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_IN_LAC_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_in_lac_ach_p("N/A");
			}
			try	{
				bean.setQua_recruit_with_extra_cre_act(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_WITH_EXTRA_CRE_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_with_extra_cre_act("N/A");
			}
			try	{
				bean.setQua_recruit_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_ach_p("N/A");
			}
			try	{
				bean.setTot_proac_agt_mm_wit_extr_cred(object.getJSONObject("payload").getJSONObject("agency").get("tot_PROAC_AGT_MM_WIT_EXTR_CRED").toString());
			}
			catch(Exception ex)	
			{
				bean.setTot_proac_agt_mm_wit_extr_cred("N/A");
			}
			try	{
				bean.setTot_proac_agt_mm_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("tot_PROAC_AGT_MM_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setTot_proac_agt_mm_ach_p("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_6m(object.getJSONObject("payload").getJSONObject("agency").get("promo_WTG_FYP_ACT_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act_6m("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("agency").get("ytd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("agency").get("ytd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("agency").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("agency").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "YBL":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ybl").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ybl").get("sub_CHANNEL").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ybl").get("ra_ADM_AGT_ID").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setActivisa_mtd_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_PRCNTG").toString());
			}
			catch(Exception ex)
			{
				bean.setActivisa_mtd_prcntg("N/A");
			}
			try	{
				bean.setActivisa_mtd_manmonth(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_manmonth("N/A");
			}
			try	{
				bean.setActivisa_mtd_active(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_ACTIVE").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_active("N/A");
			}
			try	{
				bean.setActivisa_mtd_plan_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_PLAN_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_plan_prcntg("N/A");
			}
			try	{
				bean.setPromo_adj_p_mfyp_in_lacs_act(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_act("N/A");
			}
			try	{
				bean.setPromo_adj_p_mfyp_in_lacs_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_p("N/A");
			}
			try	{
				bean.setPromo_paid_cases_act(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_act("N/A");
			}
			try	{
				bean.setPromo_paid_cases_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_p("N/A");
			}
			try	{
				bean.setPromo_15m_pers_in_lacs_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_15M_PERS_IN_LACS_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_15m_pers_in_lacs_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_plan("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_actual("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try{
				bean.setQtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_plan("N/A");
			}
			try{
				bean.setQtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_actual("N/A");
			}
			try{
				bean.setYtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try{
				bean.setYtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_actual("N/A");
			}
			/*-------------------------------------------------------------------------------------------------------------------------*/
			try{
				bean.setPromo_adj_p_mfyp_in_lacs_srtfl(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_SRTFL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_srtfl("N/A");
			}
			try{
				bean.setPromo_paid_cases_shortfall(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_SHORTFALL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_shortfall("N/A");
			}
			try{
				bean.setPromo_15m_pers_shortfall(object.getJSONObject("payload").getJSONObject("ybl").get("promo_15M_PERS_SHORTFALL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_15m_pers_shortfall("N/A");
			}
			try	{
				bean.setGpa_score(object.getJSONObject("payload").getJSONObject("ybl").get("gpa_SCORE").toString());
			}
			catch(Exception ex)	
			{
				bean.setGpa_score("N/A");
			}
			/*------------------------------------------------------------------------------*/
			try{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ybl").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ybl").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		default :
			finalresponse="No Action Matched";
		}
		return finalresponse;
	}
}

